var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    weShareId:{
       type: Number
    },
    firstName: {
        type: String
    },
    lastName: {
        type: String
    },
    contact: {
        type: Number
    },
    email:{
        type: String
    },
    state: {
        type: String
    },
    city:{
        type: String
    },
    pinCode:{
        type: Number
    }    
});
var User = mongoose.model('User', userSchema);

module.exports  = User;