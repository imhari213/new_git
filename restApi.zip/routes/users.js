var express = require('express');
var router = express.Router();
var userModel = require('../models/user.model');
var otpModel = require('../models/otp.model');
var db = require('../connection');
var sendEmail = require('../services/mail.service');
const { response } = require('express');
var connectionObj = db.getDb();
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/validateOtp',(req,res)=>{
  otpModel.findOne({"contact":req.body.contact})
  .then(result => {
    if(result){
    if(result.otp == req.body.otp){
      res.send({"status":"success","message":"successfully validated"})
    }else{
      res.send({"status":"fail","message":"invalid otp"})
    }
  }else{
    res.send({"status":"fail","message":"otp not found"})
  }
  },(error)=>{
    res.send({"status":"fail","message":"otp expired please generate new one","error":error})
  })
})

router.post('/getOtp',(req,res)=>{
  userModel.findOne({"contact":req.body.contact})
  .then(result => {
    console.log(result);
    var otpNumber = Math.floor(Math.random() * (1000 - 9999 + 1)) + 9999; 
   sendEmail(result.email,otpNumber)
   .then((response)=>{
     console.log(response,"*******");
     var otpData = new otpModel({
      weShareId:result.weShareId,
      otp:otpNumber,
      contact:result.contact
     })
     otpData.save((err,result)=>{
      if(err){      
        res.send({"status":"Fail","message":"error while saving otp","err":err});
      }else{
        console.log(result);
        res.send({"status":"success","message":"OTP sent successfully"});
      }
    })    
   },(error)=>{
     console.log(error,"error")
     res.send({"status":"Fail","message":"error occured while sednig email","error":error})
   })
  },
  (err)=>{
    res.send({"status":"Fail","error":"error occured while fetching data","error":err})
   })

})

router.post("/register",(req,res)=>{ 

  console.log(typeof(req.body));

  var user = new userModel({
    weShareId:Math.floor(Math.random() * 10),
    firstName:req.body.firstName,
    lastName:req.body.lastName,
    contact:req.body.contact,
    email:req.body.email,
    state:req.body.state,
    city:req.body.city,
    pinCode:req.body.pinCode,

  })

  user.save((err,result)=>{
    if(err){      
      res.send({"status":"Fail","err":err});
    }else{
      console.log(result);
      res.send({"status":"success"});
    }
  })

})

module.exports = router;
