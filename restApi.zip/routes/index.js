var express = require('express');
var router = express.Router();
var db = require('../connection');
var connectionObj = db.getDb();
/* GET home page. */
router.get('/', function(req, res, next) { 
  rowData = [
    { name: 'John', title: 'Software Engineer', number: 123456, date: 'March 02, 2016' },
    { name: 'Jane', title: 'Senior Software Engineer', number: 123451, date: 'April 01, 2014' },
    { name: 'Richard', title: 'Software Engineer', number: 123452, date: 'January 02, 2015' },
    { name: 'Janie', title: 'Software Engineer', number: 123453, date: 'March 23, 2016' },
    { name: 'Johnny', title: 'Senior Software Engineer', number: 123454, date: 'September 01, 2017' }
];
  res.send(rowData); 
  // res.render('index', { title: 'Express' });
});

module.exports = router;
