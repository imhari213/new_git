"use strict";
const nodemailer = require("nodemailer");
module.exports = async function sendEmail(emailId,otp) {
 console.log(emailId,"--->");

 
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: "weshareteamforyou@gmail.com", // generated ethereal user
      pass: "H@ri3296!", // generated ethereal password
    },
  });

  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: '"Team WeShare 👻" <weshareteamforyou@gmail.com>', // sender address
    to: emailId, // list of receivers
    subject: "Welcome to WeShare", // Subject line
    text: "OTP for login :" + otp
    //html: "<b>Hello world?</b>", // html body
  });

  

  console.log("Message sent: %s", info.messageId);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

  // Preview only available when sending through an Ethereal account
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
  return info.messageId;
}

//sendEmail().catch(console.error);