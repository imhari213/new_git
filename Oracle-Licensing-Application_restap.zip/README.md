# Oracle Licensing Application

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.0.3.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

To Deploy we need to change our application into a deployable state from a development state. We have two options to deploy: 

* Option 1: 2 seperate apps (Node Rest API, Angular) 
* Option 2: 1 combined app (Node REST API which renders Angular too) 

### Option 1 

#### Restful API (Backend) Server 

* **Move the 'server.js' file into the *backend* folder**, so all backend related files are together.
* **Update routes**, because we have moved *server.js*.
 * In *package.json* update route for field `"start:server"` to `nodemon ./backend/server.js`.
 * In `server.js` update the line: `const app = require("./backend/app");` to `const app = require("./app");`
 * In *file.js* change the cb routes from `backend/images` to `images`
 * In *app.js* change route `backend/images` in `app.use('/images'... path.join('backend/images'))` to `images`, do the same for file path.
* **Copy 'package.json'** into the *backend* folder, the backend will also need certain dependancies.
 * **Remove all angular related scripts, dependancies and dev dependancies** i.e. *ng, rxjs, zone.js, core-js, @angular*
* The backend server is now in a deployable state, go into your *backend* folder, select all files and compress into a .zip for deployment onto your cloud server of choice.

### Angular (Frontend) Server

* **Update 'enviroment.prod.ts'** to have field `api:Url` set to `location_of_clod_server/api`.
* **Run ng build --prod**, this will create a new folder `/dist`.
* Deploy contents of `/dist/oracle-licensing-application`, select all files and compress into a .zip for deployment onto your cloud server of choice.

#### Angular Deployment Congfig 

* Choose a static host to deploy Angular, i.e. Oracle Cloud Object Storage, Amazon S3.
* Make sure bucket has public access i.e. *Read Only Permission to an Anonymous User*.
* Index document: `index.html`.
* Error document: `index.html`.
* Block new public ACLs: false.
* Remove public access granted through public ACLs: false.
* Block new public bucket policies: false.
* Block public cross-account access if bucket has public polices: false.
 
### Option 2 

If you have cloned the repo from one of the branches you will need to `npm install` before you start the steps beneath.

* In *environmnet.prod.ts* add `apiUrl: 'http://localhost:3000/api'`. Potentially replace localhost with IP address of the server being uploaded i.e. `'http://172.18.4.94:3000/api'`
* In *angular.json* update the field `outputPath` to `backend/angular` or any alternative path that does not exist.
* Run `ng build --prod`. This will build the angular app into a subfolder in the 'backend' folder, the path will be the same as `outputPath`.
* *Make sure all backend paths and frontend paths are unique, otherwise a frontend path may never be reached as the backend routes are handled first*.
* In *app.js* we have to set up a path to direct routes to angular. Redirect all requests not targeted for our API routes to the absolute path of index.html, by adding:  

 `app.use((req, res, next) => {
 res.sendFile(path.join(__dirname, "angular", "index.html"));
 });`

* To allow scripts to run we need to allow static access to the *angular* folder,make sure you add this underneath `app.use('/files...` in *app.js* add:

 `
 app.use("/", express.static(path.join(__dirname, "angular")));
 `
 
**Move the 'server.js' file into the *backend* folder**, so all backend related files are together.

* **Update routes**, because we have moved *server.js*.
 * In `server.js` update the line: `const app = require("./backend/app");` to `const app = require("./app");`
 * In *app.js* change the cb routes from `backend/images` to `images`
 * In *app.js* change route `backend/images` in `app.use('/images'... path.join('backend/images'))` to `images`, do the same for file path.
* **Copy 'package.json'** into the *backend* folder, the backend will also need certain dependancies.
 * **Remove all angular related scripts, dependancies and dev dependancies** i.e. *ng, rxjs, zone.js, core-js, @angular*
  * In *package.json* update route for field `"start"` to `node server.js`.
  
#### Creating a .env file

* **Download the dotenv package** via npm, command can be found here [dotenv](https://www.npmjs.com/package/dotenv)
* **Import in app.js**, add `require('dotenv').config()` to the last line of imports in `app.js`
* **Add a .env file** to the root folder.This file contains all the enviromental variables for the backend i.e. MongoDB credentials and any public or private keys. Similar to `Nodemon.js` but for deployment, in this format:

```
MONGO_USER=user
PRIVATE_KEY=key
```

* In the terminal navigate into the backend folder and type `npm run start` and navigate in your browser to `localhost:3000` to check the application is now working as a combined application 
* The application is now in a deployable state, go into your *backend* folder, select all files and compress into a .zip for deployment onto your cloud server of choice. 

### General Deploy Config

* Use Node Command `node server.js`.
* Add Enviromental Variables from *nodemon.js*.
* Add Cloud server Ip to mongoDb Ip whitelist.Best Practice, build new mongoDb cluster for deployment.
* If build fails due to `bcrypt.js`, install and use `bcryptjs` instead as it is precompiled. 

## Containerizing the Application 

* Option 1: 2 seperate apps (Node Rest API, Angular) 
* Option 2: 1 combined app (Node REST API with precompiled Angular App)

### Option One 

### Adjusting up the Backend 

#### Adjusting the folder strutcure

* **Move the 'server.js' file into the *backend* folder**, so all backend related files are together.
* **Update routes**, because we have moved *server.js*.
  * In *package.json* update route for field `"start:server"` to `nodemon ./backend/server.js`.
  * In `server.js` update the line: `const app = require("./backend/app");` to `const app = require("./app");`
  * In *app.js* change the cb routes from `backend/images` to `images`
  * In *app.js* change route `backend/images` in `app.use('/images'... path.join('backend/images'))` to `images`, do the same for file path.
* **Copy 'package.json'** into the *backend* folder, the backend will also need certain dependancies.
  * **Remove all angular related scripts, dependancies and dev dependancies** i.e. *ng, rxjs, zone.js, core-js, @angular*
  * **Run** `"npm install"` to install all backend dependancies.

#### Setting up the Backend Docker Files

* **Add a .dockerignore file** into the root folder. 

```
node_modules
npm-debug.log
```

* **Add a Dockerfile** into the root folder

```Dockerfile
FROM node:12 as builder

# Create app directory
WORKDIR /usr/src/app

# Install app dependencies
COPY package*.json ./

# Install any needed packages
RUN npm install

# Bundle app source
COPY . .

# Stage 2 build for creating smaller image
FROM node:12-alpine

WORKDIR /usr/src/app

COPY --from=builder /usr/src/app .

EXPOSE 3000

CMD [ "npm", "start" ]
```

* **Add a .env file** to the root folder.This file contains all the enviromental variables for the backend i.e. MongoDB credentials and any public or private keys. Similar to `Nodemon.js` but for deployment, in this format:

```
MONGO_USER=user
PRIVATE_KEY=key
```

* **Update the MongoDb Connection** in `app.js`. As we are connecting to another container we have to point to it, as the container is within our cluster we point to it by using its name `database` within the uri string. 

```js
const uri = process.env.MONGO_URL || 'mongodb://database/ola-app'
```

### Adjusting up the Frontend 

#### Adjusting the folder strutcure

* **Create a frontend folder** in the root directory and move everything into so your root directoy just contains two sub folders `backend` and `frontend`. If you have troubles with node_modules while moving it, delete it and navigate into the frontend folder and run `npm install` again to fix it.
* **Adjust package.json**, to make the angular app accessible from outside the Docker container we need to tell it to run on 0.0.0.0 instead of localhost by going to `package.json`  and setting the `"start"` variable in `scripts` to `"start": "ng serve --host 0.0.0.0",`
* **Adjust enviroment.ts** to get our frontend to point to our backend we need to update the `apiUrl` variable in `enviroment.ts`, if you're building with production flag then change it in `enviroment.prod.ts` too. In our case set it as `apiUrl: 'http://127.0.0.1:3000/api'`

#### Setting up the Frontend Docker Files

* **Add a .dockerignore file** into the root folder. 

```
node_modules
npm-debug.log
```

* **Add a Dockerfile** into the root folder

```dockerfile
FROM node:12-alpine

WORKDIR /usr/src/app

# Install app dependencies
COPY package*.json .

# Install any needed packages
RUN npm install

# Bundle app source
COPY . .

EXPOSE 4200

CMD [ "npm", "start" ]
```

### Setting up Docker Compose 

Now that all the parts are setup we specify how the different images should be build and run using docker-compose. We create a docker-compose file in the root folder of oracle-licensing-application containing a service for the angular app, the node server and the Mongo DB as shown below: 

```yml
version: '3' # specify docker-compose version

# Define the services/containers to be run
services:
 frontend:
   build: ./frontend
   ports:
     - "4200:4200"
 backend: # name of the first service
   build: ./backend # specify the directory of the Dockerfile
   env_file:
    - backend/.env
   ports:
     - "3000:3000"
   environment:
     - MONGO_URL=mongodb://database/ola-app
   links:
     - database
   depends_on:
     - database
 database: # name of the third service
   image: mongo # specify image to build container from
   volumes:
     - "~/data:/data/db"
   ports:
     - "27017:27017" # specify port forewarding
```

In this file we specify: 

* the dockerfile locations for the backend and frontend.
* map the ports for the containers to run on.
* link the containers together by using `links:` and `depends_on:`
* set the volumes used for the database.

We run our application by running `docker-compose up` which builds the images and starts the containers. If you want to rebuild it after changing code run `docker-compose build` which will rebuild the image, then type `docker-compose up` to restart the containers.

To see your images and containers type `docker images ` and `docker container ls -a` respectively.

### Option 2

#### Adjusting the folder strutcure

* **Follow steps outlined in Build Option 2**,
* **Move the 'server.js' file into the *backend* folder**, so all backend related files are together.
* **Update routes**, because we have moved *server.js*.
  * In *package.json* update route for field `"start"` to `node server.js`.
  * In `server.js` update the line: `const app = require("./backend/app");` to `const app = require("./app");`
  * In *app.js* change the cb routes from `backend/images` to `images`
  * In *app.js* change route `backend/images` in `app.use('/images'... path.join('backend/images'))` to `images`, do the same for file path.
* **Copy 'package.json'** into the *backend* folder, the backend will also need certain dependancies.
  * **Remove all angular related scripts, dependancies and dev dependancies** i.e. *ng, rxjs, zone.js, core-js, @angular*
  * **Run** `"npm install"` to install all backend dependancies.
* ****

#### Creating a .env file

* **Download the dotenv package** via npm, command can be found here [dotenv](https://www.npmjs.com/package/dotenv)
* **Import in app.js**, add `require('dotenv').config()` to the last line of imports in `app.js`
* **Add a .env file** to the root folder.This file contains all the enviromental variables for the backend i.e. MongoDB credentials and any public or private keys. Similar to `Nodemon.js` but for deployment, in this format:

```
MONGO_USER=user
PRIVATE_KEY=key
```

#### Setting up the Backend Docker Files

* **Add a .dockerignore file** into the root folder. 

```
node_modules
npm-debug.log
```

* **Add a Dockerfile** into the root backend folder

```dockerfile
FROM node:12 as builder

# Create app directory
WORKDIR /usr/src/app

# Install app dependencies
COPY package*.json ./

# Install any needed packages
RUN npm install

# Bundle app source
COPY . .

# Stage 2 build for creating smaller image
FROM node:12-alpine

WORKDIR /usr/src/app

COPY --from=builder /usr/src/app .

EXPOSE 3000

CMD [ "npm", "start" ]
```

### Setting up Docker Compose 

Now that all the parts are setup we specify how the image should be built and run using docker-compose. We create a docker-compose file in the root folder of oracle-licensing-application containing a service for the backend app:

```yml
version: '3' # specify docker-compose version

# Define the services/containers to be run
services:
 olaapp: # name of the first service
   build: ./backend # specify the directory of the Dockerfile
   env_file:
    - backend/.env
   ports:
     - "3000:3000"
   restart: always
```

We run our application by running `docker-compose up` which builds the image and starts the container. If you want to rebuild it after changing code run `docker-compose build` which will rebuild the image, then type `docker-compose up` to restart the container.

To see your images and containers type `docker images ` and `docker container ls -a` respectively.

### DockerHub 

To store the images we use DockerHub, a remote repository for Docker images.

* **Create a dockerhub** account here,[dockerhub](https://hub.docker.com/signup)
* **Become a Collaborator** if you are trying to access a repository belonging to another individual or organisation.
* **Open a terminal** as we push and pull images to the DockerHub via a command line interface.
* **Finding the commands**, you can find the commands in your DockerHub account under `repositories/tags`, contact the repository owner if you do not own the repository.  

#### Adding an Image to a repository

Before we can push an image to the repository, we need to tag the image we want to push, this is to distinguish the image as you can have multiple copies of images with the same name and Image ID.
Type `docker images ` to view your images to find the image_id of the image you want to push.

* **Tagging an Image**: `docker tag <IMAGE_ID> <dockerhub_namespace>/<repository_name>:<image_tag_name>`
* **Pushing an Image**: `docker push <dockerhub_namespace>/<repository_name>:<image_tag_name>`

#### Pulling an Image from a respository

To pull an image you either have to be owner of the repository or a collaborator.

* **Pulling an Image**:`docker pull <dockerhub_namespace>/<repository_name>:<image_tag_name>`

#### OLA Images 

* **Option 1**: 2 seperate apps (Node Rest API, Angular)
  * This includes three images, one for the Node.js backend, one for Angular.js frontend and another for a priavte MongoDB server.
  * Alternatively you can run this setup without the MongoDB image and use a cloud cluster for this. Files needed to be chnaged for this docker-compose.yml and app.js
  * **To Run**, navigate in terminal to the location of the docker-compose.yml file. Can be found in bitbucket in the docker-cluster-format branch. We run our application by running `docker-compose up`.
 
* **Option 2**: 1 combined app (Node REST API with precompiled Angular App)
  * This includes one image of the Node.js server with a precompiled Angular frontend within
  * **To Run**, can use the docker-comose.yml file or by typing `docker run -dp 3000:3000 <dockerhub_namespace>/<repository_name>:<image_tag_name>`
 
## How to Install locally

### Installing IDE, Source Control and Node 

* **Install Visual Studio Code** Download can be found here, [vscode](https://code.visualstudio.com/)
* **Install git** Download can be found here, [git](https://git-scm.com/downloads)
* **Install node.js** Download can be found here, [node](https://nodejs.org/en/download/)

### Setting up Source Control in Visual Studio

* Navigate to [BitBucket](https://bitbucket.org/product) and signin to your account. 
* Navigate to the repository *oracle-licensing-application*, the default branch is the *master* branch with stable code or change to *develop* branch for the latest features in development
* Click the *Clone* button, copy the git command to your clipboard
* Back in Visual Studio Code, click *Terminal* in the toolbar, then click *New Terminal*, paste the git command into the terminal and click enter
* A popup should appear, Login to with your Bitbucket credentials 
* The application folder has now been downloaded onto your computer, on a PC navigate to *This PC > Users > (Your Account)*
* Locate the folder *oracle-licensing-application*, left click and select *Open in Visual Studio*

### Installing dependencies in Visual Studio Code Terminal 

* Type *npm install* into a terminal 
* Type *npm install -g @angular/cli* into a terminal
* Type *npm install -g nodemon* into a terminal

### Setting up a local MondoDB Connection if needed

 * **Install MongoDb Community Server** Download can be found here, [MongoDB Community Server](https://www.mongodb.com/download-center/community) and video for help here, [Installing MongoDB Locally](https://www.youtube.com/watch?v=wLNL2HTvcVw&list=PL4cUxeGkcC9jpvoYriLI0bY8DOgWZfi6u&index=2)
 * **Connecting to MongoDb** video for instructions can be found here, [Connecting to MongoDB](https://www.youtube.com/watch?v=oT2HOw3fWp4&list=PL4cUxeGkcC9jpvoYriLI0bY8DOgWZfi6u&index=3)

### To run the application 
* Type *ng serve* into one terminal to run the (frontend) server
* Type *nodemon server* in another terminal to run the (backend) server
* Navigate to *http://localhost:4200* to view the Oracle Licensing Application

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
