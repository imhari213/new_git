export const environment = {
  production: true,
   apiUrl: 'http://51.132.243.239:3000/api',
   appDomain : 'http://51.132.243.239:3000'
  //apiUrl: 'http://localhost:3000/api' 
};
