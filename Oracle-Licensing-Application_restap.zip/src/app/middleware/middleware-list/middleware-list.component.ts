// angular
import { Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { PageEvent, MatTableDataSource, MatDialog } from '@angular/material';

// models
import { Middleware, ComponentsInstalled } from '../middleware.model';
import { OptionsInUse, ManagementPack } from 'src/app/config/config.model';
import { Hardware } from 'src/app/hardware/hardware.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { CompanyService } from 'src/app/companies/companies.service';
import { OptionsService } from 'src/app/options.service';
import { MiddlewareService } from '../middleware.service';

// components
import { OptionsInUseDialogComponent } from 'src/app/databases/options-in-use-dialog/options-in-use-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { ComponentsDialogComponent } from '../components-dialog/components-dialog.component';
import { ManagmentPacksDialogComponent } from 'src/app/databases/managment-packs-dialog/managment-packs-dialog.component';

// misc
import { Subscription } from 'rxjs';
import { HwService } from 'src/app/hardware/hardware.service';

@Component({
  selector: 'app-middleware-list',
  templateUrl: './middleware-list.component.html',
  styleUrls: ['./middleware-list.component.css'],
})

export class MiddlewareListComponent implements OnInit, OnDestroy {
  serverName: any;

  constructor(private authService: AuthService, private router: Router, private optionsService: OptionsService,
    private middlewareService: MiddlewareService, private dialog: MatDialog, private companyService: CompanyService,
    private hardwareService: HwService) {}

  userIsAuthenticated: Boolean;
  userRole = 'read';
  isLoading = false;
  checkedHeader;

  displayedColumnsComponents: string[] = ['component', 'location', 'edit'];
  optonsColumnsToDisplay: String[] = ['option', 'start', 'end', 'edit'];
  managementPacksColumnstoDisplay: String[] = ['Management Pack', 'Start Date', 'End Date', 'edit'];
  dataSourceComponentsInstalled: MatTableDataSource<ComponentsInstalled>;
  optionsDataSource: MatTableDataSource<any>;
  managementDataSource: MatTableDataSource<any>;

  middlewares: Middleware[];
  middlewareCount: Number = 0;
  middlewarePerPage = 20;
  pageSizeOptions = [20, 50, 100];
  currentPage = 1;

  companyId;
  searchParam;
  sortType;
  middleware: Middleware;
  optionsInUse: OptionsInUse[];
  managementPacks: ManagementPack[];
  hardware: Hardware;

  authStatusSub: Subscription;
  headerOptionSub: Subscription;
  middlewareSub: Subscription;

  completeMiddlewareColumns = [
    // {name: 'Product Name', modelName: 'product'},
    {name: 'Company', modelName: 'company'},
    {name: 'Environment Usage', modelName: 'environment_usage'},
    {name: 'Physical Server', modelName: 'physical_server'},
    // {name: 'Licensable Product', modelName: 'licensable_product'},
    // {name: 'Product Version', modelName: 'product_version'},
    {name: 'Virtual Server', modelName: 'virtual_server_for_failover_dr_backup_testing'}
  ];

  currentMiddlewareColumns = [
  // {name: 'Product Name', modelName: 'product'},
  // {name: 'Licensable Product', modelName: 'licensable_product'},
 // {name: 'Product Version', modelName: 'product_version'},
  {name: 'Environment Usage', modelName: 'environment_usage'},
  {name: 'Physical Server', modelName: 'physical_server'},
];

  ngOnInit() {
    this.isLoading = true;

    if (localStorage.getItem('compId') !== 'null') { this.companyId = localStorage.getItem('compId'); }

    this.getAuth();
    this.getMiddleware();

    this.checkedHeader = this.optionsService.getHeaderOption();
    this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
    });
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }

  }

  getMiddleware() {
    this.middlewareService.searchMiddleware(this.companyId, this.searchParam, this.sortType, this.middlewarePerPage, this.currentPage);
    this.middlewareSub = this.middlewareService.getMiddlewareUpdateListener()
    .subscribe((middlewareData: {middlewares: Middleware[]; middlewareCount: Number}) => {
      this.middlewareCount = middlewareData.middlewareCount;
      this.middlewares = middlewareData.middlewares;
      this.isLoading = false;
      console.log(middlewareData.middlewares);
    });
  }

  onChangePage(pageData: PageEvent) {

    this.currentPage = pageData.pageIndex + 1;
    this.middlewarePerPage = pageData.pageSize;
    this.getMiddleware();

  }

  onSearch(toSearch) {
    this.searchParam = toSearch;
    this.getMiddleware();
  }

  setSortType(type) {
    this.sortType = type;
    this.getMiddleware();
  }

  addMiddleware() {
    this.router.navigate(['/add-middleware']);
  }

  backToCompanies() {
    this.companyService.getCompany(this.companyId).subscribe(data => {
      this.router.navigate(['/company-details/' + data.company_name]);
    });
  }

  backToContracts() {
    this.router.navigate(['/list-contract']);
  }

  backToHardware() {
    this.router.navigate(['/list-hardware']);
  }

  backToDatabases() {
    this.router.navigate(['list-database']);
  }

  backToVCenters() {
    this.router.navigate(['/list-vcenter']);
  }

  backToDeclarations() {
    this.router.navigate(['/list-declarations']);
  }

  onExpand(middleware) {
    this.serverName = null;
    if (middleware.physical_server) { this.serverName = middleware.physical_server.server_name; }
    // if (middleware.physical_server) {this.setHardwareName(middleware.physical_server); }
    this.middleware = middleware;
    this.optionsInUse = middleware.options_in_use;
    this.managementPacks = middleware.managements_in_use;
    this.hardware = middleware.physical_server;
    this.dataSourceComponentsInstalled = new MatTableDataSource(middleware.components_installed);
    this.optionsDataSource = new MatTableDataSource(this.optionsInUse);
    this.managementDataSource = new MatTableDataSource(this.managementPacks);
  }

  getCheckedBoolean(column) {
   return this.currentMiddlewareColumns.find(object => object['name'] === column.name);
  }

  getColumnsClicked(option, event) {
    if (event === true) {
      this.currentMiddlewareColumns.push(option);
      if (option.name === 'Physical Server') {
        for (let i = 0;  i < this.middlewares.length; i++) {
          if (this.middlewares[i].physical_server) {
             this.setHardwareName(this.middlewares[i].physical_server).then(result => {
              this.middlewares[i].physical_server = result.toString();
             });
          }
        }
      } else if (option.name === 'Virtual Server') {
        for (let i = 0;  i < this.middlewares.length; i++) {
          if (this.middlewares[i].virtual_server_for_failover_dr_backup_testing) {
           this.middlewares[i].virtual_server_for_failover_dr_backup_testing =
           this.getVirtName(this.middlewares[i].virtual_server_for_failover_dr_backup_testing);
          }
        }
      }
    } else {
      const index = this.currentMiddlewareColumns.indexOf(option);
      this.currentMiddlewareColumns.splice(index, 1);
    }
  }

  setHardwareName(serverId) {
    if (!serverId || serverId.includes('.')) {
      this.serverName = serverId;
      return;
    } // includes('.') is a catch if serverId has been retreived with column change
    return new Promise(resolve => {
      this.hardwareService.getHardwareName(serverId).subscribe(result => {
        this.serverName = result.serverName;
        resolve(result.serverName);
      });
    });
  }

  componentDialog(element, index): void {

    const dialogRef = this.dialog.open(ComponentsDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (element) {
        data._id = element._id;
        this.middleware.components_installed.splice(index, 1, data);
      } else {
        this.middleware.components_installed.push(data);
      }
      this.middlewareService.updateMiddleware(this.middleware).subscribe(returnData => {
        this.onExpand(returnData.middleware);
      });
    });
  }

  componentDelete(element, index) {
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.component_installed, pageViewName: 'Component'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.middleware.components_installed.splice(index, 1);
        this.middlewareService.updateMiddleware(this.middleware).subscribe(data => {
          this.onExpand(data.middleware);
        });
      } else {
        console.log('closed');
      }
    });
  }

  optionsDialog(element, index): void {

    const dialogRef = this.dialog.open(OptionsInUseDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {option: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.middleware.options_in_use.splice(index, 1, data);
        } else {
          this.middleware.options_in_use.push(data);
        }

        this.middlewareService.updateMiddleware(this.middleware).subscribe(returnData => {
          this.onExpand(returnData.middleware);
        });
      } else {
        console.log('close');
      }
    });
  }

  deleteOption(element, index) {
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.option_in_use, pageViewName: 'Option'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.middleware.options_in_use.splice(index, 1);
        this.middlewareService.updateMiddleware(this.middleware).subscribe(returnData => {
          this.onExpand(returnData.middleware);
        });
      } else {
        console.log('closed');
      }
    });
  }

  openManagmentDialog(element, index): void {

    const dialogRef = this.dialog.open(ManagmentPacksDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {management_pack: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.middleware.managements_in_use.splice(index, 1, data);
        } else {
          this.middleware.managements_in_use.push(data);
        }

        this.middlewareService.updateMiddleware(this.middleware).subscribe(returnData => {
          this.onExpand(returnData.middleware);
        });
      } else {
        console.log('closed');
      }
    });

  }

  deleteManagementPack(element, index) {
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.management_in_use, pageViewName: 'Management Pack'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.middleware.managements_in_use.splice(index, 1);
        this.middlewareService.updateMiddleware(this.middleware).subscribe(returnData => {
          this.onExpand(returnData.middleware);
        });
      } else {
        console.log('closed');
      }
    });
  }

  getVirtName(virtId) {
    let virtName = 'Not Found';
    try { virtName = this.hardware.ibm_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { virtName = this.hardware.ovm_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { virtName = this.hardware.xen_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { virtName = this.hardware.vmware_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { virtName = this.hardware.solaris_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { virtName = this.hardware.kvm_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { virtName = this.hardware.hp_ux_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    return virtName;
  }

  onDelete(event: Event, middleware) {
    event.stopPropagation();
    this.middlewareService.deleteMiddleware(middleware._id).subscribe(() => {
      this.getMiddleware();
    });
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    this.headerOptionSub.unsubscribe();
    this.middlewareSub.unsubscribe();
  }

}
