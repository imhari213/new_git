// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Middleware } from './middleware.model';

// misc

import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';

const BACKEND_URL = environment.apiUrl + '/middleware/';

@Injectable({providedIn: 'root'})

export class MiddlewareService {

  constructor(private http: HttpClient) {}

  middlewares;
  middlewareCount: number;
  middlewaresUpdated = new Subject<{middlewares: Middleware[], middlewareCount: number}>();

  getMiddlewareUpdateListener() {
    return this.middlewaresUpdated.asObservable();
  }

  addMiddleware(value: any) {
    return this.http.post<{message: string, middleware: Middleware}>(BACKEND_URL, value);
  }

  updateMiddleware(middleware: Middleware) {
    return this.http.put<{message: string, middleware: Middleware}>(BACKEND_URL + middleware._id, middleware);
  }

  searchMiddleware(company: String, searchParam: string, sortType: string, mwPerPage: number, currentPage: number) {
    const queryParams = `?pagesize=${mwPerPage}&page=${currentPage}&company=${company}&searchparam=${searchParam}&sort=${sortType}`;
    this.http.get<{message: string, middlewares: any, maxMiddlewares: number}>(BACKEND_URL + queryParams).subscribe(data => {
      this.middlewares = data.middlewares;
      this.middlewareCount = data.maxMiddlewares;
      this.middlewaresUpdated.next({middlewares: [...this.middlewares], middlewareCount: this.middlewareCount});
    });
  }

  deleteMiddleware(middlewareId: string) {
    return this.http.delete<{message: string}>(BACKEND_URL + middlewareId);
  }

  getMiddlewareById(middlewareId: string) {
    return this.http.get<{message: string, middleware: Middleware}>(BACKEND_URL + middlewareId);
  }

}
