// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { MiddlewareService } from '../middleware.service';
import { CompanyService } from 'src/app/companies/companies.service';
import { HwService } from 'src/app/hardware/hardware.service';
import { ConfigService } from 'src/app/config/config.service';

// models
import { ComponentsInstalled, Middleware } from '../middleware.model';
import { EnviromentalUsage } from 'src/app/config/config.model';
import { Company } from 'src/app/companies/company.model';
import { Hardware } from 'src/app/hardware/hardware.model';

// components
import { OptionsInUseDialogComponent } from 'src/app/databases/options-in-use-dialog/options-in-use-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { ManagmentPacksDialogComponent } from 'src/app/databases/managment-packs-dialog/managment-packs-dialog.component';
import { ComponentsDialogComponent } from '../components-dialog/components-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-middleware-list',
  templateUrl: './middleware-create.component.html',
  styleUrls: ['./middleware-create.component.css'],
  providers: [{provide: STEPPER_GLOBAL_OPTIONS,
    useValue: { displayDefaultIndicatorType: false }}]
})

export class MiddlewareCreateComponent implements OnInit, OnDestroy {

  constructor(private authService: AuthService, private router: Router, private companyService: CompanyService,
              private dialog: MatDialog, private middlewareService: MiddlewareService, private hardwareService: HwService,
              private route: ActivatedRoute, private config: ConfigService) {}

  form: FormGroup;
  dataSourceComponents;
  optionsDataSource;
  managementDataSource;
  displayedColumnsComponents: string[] = ['Component', 'Location of Evidence', 'edit'];
  optionsColumns: String[] = ['option', 'start', 'end', 'edit'];
  managementColumns: String[] = ['Management Packs In Use', 'Start Date', 'End Date', 'edit'];
  companies: Company[];
  companyId: string;
  hardwares: Hardware[];
  hardwareId;
  hardware: Hardware;
  environmentalUsageList = [];
  middleware;
  virtList = <any>[];
  virtId;

  optionsInUseList = <any>[];
  managementPacksList = <any>[];
  componentsList: ComponentsInstalled[] = [];

  userIsAuthenticated: Boolean;
  userRole = 'read';
  mode = 'create';

  authStatusSub: Subscription;
  companySub: Subscription;
  hardwareSub: Subscription;
  enviromentalUsageSub: Subscription;

  ngOnInit() {
    this.getAuth();
    this.createForm();
    this.getCompanies();

    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('middlewareId')) {
        this.mode = 'edit';
        this.middlewareService.getMiddlewareById(paramMap.get('middlewareId')).subscribe(data => {
          this.fillForm(data.middleware);
          this.middleware = data.middleware;
          this.companyId = data.middleware.company._id;
          this.getHardwares(this.companyId);
          this.form.controls['company'].disable();
        });
      } else if (localStorage.getItem('compId')) {
        this.companyId = localStorage.getItem('compId');
        this.form.patchValue({'company': this.companyId});
        this.getHardwares(this.companyId);
      }
    });

    this.config.getEnviromentalUsages();
    this.enviromentalUsageSub = this.config.getEnviromentalUsagesListener()
    .subscribe((enviromentalUsageData: {enviromentalUsages: EnviromentalUsage[]}) => {
      this.environmentalUsageList = enviromentalUsageData.enviromentalUsages;
    });

  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  createForm() {
    this.form = new FormGroup({
      '_id': new FormControl(undefined),
      // 'product': new FormControl(null, {validators: [Validators.required]}),
      'components_installed': new FormControl(null),
      // 'licensable_product': new FormControl(null),
      // 'product_version': new FormControl(null),
      'environment_usage': new FormControl(null),
      'physical_server': new FormControl(null),
      // 'primary_server_for_failover_dr_backup_testing': new FormControl(null),
      'virtual_server_for_failover_dr_backup_testing': new FormControl(null),
      'managements_in_use': new FormControl(null),
      'options_in_use': new FormControl(null),
      'company': new FormControl(null)
    });
  }

  fillForm(middleware: Middleware) {
    this.form.patchValue(middleware);
    this.form.patchValue({company: middleware.company._id});
      // primary_server_for_failover_dr_backup_testing: middleware.primary_server_for_failover_dr_backup_testing._id});

    this.componentsList = middleware.components_installed;
    this.optionsInUseList = middleware.options_in_use;
    this.managementPacksList = middleware.managements_in_use;

    this.dataSourceComponents = new MatTableDataSource(this.componentsList);
    this.optionsDataSource = new MatTableDataSource(this.optionsInUseList);
    this.managementDataSource = new MatTableDataSource(this.managementPacksList);
    }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  getHardwares(compId) {
    this.hardwareService.searchHardwares(compId, undefined, undefined, undefined, null, null, null, null, null);
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
    .subscribe((hardwareData: {hardwares: Hardware[]; hardwareCount: Number}) => {
      this.hardwares = hardwareData.hardwares;
      if (this.mode === 'edit') {
        // this.setHardware(this.middleware.primary_server_for_failover_dr_backup_testing._id);
      }
    });
  }

  setDetails(compId) {
    this.getHardwares(compId);
   // this.form.patchValue({ 'primary_server_for_failover_dr_backup_testing': null});
  }

  setHardware(hardwareId) {
    this.hardware = this.hardwares.find(hw => hw._id === hardwareId);
    this.hardwareId = hardwareId;
    this.setVirtList();
  }

  setVirtual(virtId) {
    this.virtId = virtId;
  }

  setVirtList() {
    const hw = this.hardware;
    if (hw.ibm_virt && hw.ibm_virt.length > 0) { this.virtList = hw.ibm_virt; }
    if (hw.ovm_virt && hw.ovm_virt.length > 0) { this.virtList = hw.ovm_virt; }
    if (hw.xen_virt && hw.xen_virt.length > 0) { this.virtList = hw.xen_virt; }
    if (hw.vmware_virt && hw.vmware_virt.length > 0) { this.virtList = hw.vmware_virt; }
    if (hw.solaris_virt && hw.solaris_virt.length > 0) { this.virtList = hw.solaris_virt; }
    if (hw.kvm_virt &&  hw.kvm_virt.length > 0) { this.virtList = hw.kvm_virt; }
  }

  onSaveMiddleware() {
    this.form.patchValue({
      components_installed: this.componentsList,
      options_in_use: this.optionsInUseList,
      managements_in_use: this.managementPacksList
    });

    if (this.mode === 'create') {
      this.middlewareService.addMiddleware(this.form.value).subscribe(() => {
        this.router.navigate(['/list-middleware']);
      });
    }

    if (this.mode === 'edit') {
      this.middlewareService.updateMiddleware(this.form.value).subscribe(() => {
        this.router.navigate(['/list-middleware']);
      });
    }
  }

  onCancel() {
    this.router.navigate(['/list-middleware']);
  }

  componentsDialog(element): void {

    let index;
    if (element) { index = this.componentsList.indexOf(element); }
    const dialogRef = this.dialog.open(ComponentsDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          this.componentsList[index] = data;
        } else {
           this.componentsList.push(data);
        }
        this.dataSourceComponents = new MatTableDataSource(this.componentsList);
      }

    });
  }

  deleteComponent(element): void {
    const index = this.componentsList.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.component_installed, pageViewName: 'Component'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.componentsList.splice(index, 1);
        this.dataSourceComponents = new MatTableDataSource(this.componentsList);
      } else {
        console.log('closed');
      }
    });
  }

  optionsDialog(element): void {
    let index;
    if (element) { index = this.optionsInUseList.indexOf(element); }

    const dialogRef = this.dialog.open(OptionsInUseDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {option: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.optionsInUseList.splice(index, 1, data);
        } else {
          this.optionsInUseList.push(data);
        }
        this.optionsDataSource = new MatTableDataSource(this.optionsInUseList);
      } else {
        console.log('closed');
      }
    });
  }

  deleteOption(element) {
    const index = this.optionsInUseList.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.option_in_use, pageViewName: 'Option'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.optionsInUseList.splice(index, 1);
        this.optionsDataSource = new MatTableDataSource(this.optionsInUseList);
      } else {
        console.log('closed');
      }
    });
  }

  managementDialog(element): void {

    let index;

    if (element) { index = this.managementPacksList.indexOf(element); }

    const dialogRef = this.dialog.open(ManagmentPacksDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {management_pack: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.managementPacksList.splice(index, 1, data);
        } else {
          this.managementPacksList.push(data);
        }
        this.managementDataSource = new MatTableDataSource(this.managementPacksList);
      } else {
        console.log('closed');
      }
    });

  }

  deleteManagement(element) {
    const index = this.managementPacksList.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.management_in_use, pageViewName: 'Managment Pack'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.managementPacksList.splice(index, 1);
        this.managementDataSource = new MatTableDataSource(this.managementPacksList);
      } else {
        console.log('closed');
      }
    });
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    this.companySub.unsubscribe();
    try {this.hardwareSub.unsubscribe(); } catch {}
    this.enviromentalUsageSub.unsubscribe();
  }


}
