// angular
import { OnInit, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';

// services
import { ThemeService } from 'src/app/theme.service';

@Component({
  selector: 'app-components-dialog',
  templateUrl: './components-dialog.component.html',
  styleUrls: ['./components-dialog.component.css'],
  providers: [ThemeService]
})

export class ComponentsDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ComponentsDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {}

  form: FormGroup;

  ngOnInit() {
    this.createForm();
    if (this.data.element) {
      this.fillForm();
    }
  }

  createForm() {
    this.form = new FormGroup({
      'component_installed': new FormControl(null),
      'location_of_evidence': new FormControl(null)
    });
  }

  fillForm() {
    this.form.patchValue(this.data.element);
  }

  save() {
    const checkString = this.form.value.location_of_evidence.replace(/\\/g, '/');
    this.form.patchValue({location_of_evidence: checkString});
    this.dialogRef.close(this.form.value);
  }
}
