import { Options, Managements } from '../databases/databases.model';
import { Hardware } from '../hardware/hardware.model';
import { Company } from '../companies/company.model';


export interface ComponentsInstalled {
  component_installed: string;
  location_of_evidence: string;
}

export interface Middleware {
  _id: string;
  // product: string;
  company: Company;
  components_installed: [ComponentsInstalled];
  // licensable_product: string;
  // product_version: string;
  environment_usage: string;
  // primary_server_for_failover_dr_backup_testing: Hardware;
  physical_server: string;
  virtual_server_for_failover_dr_backup_testing: string;
  managements_in_use: [Managements];
  options_in_use: [Options];
}
