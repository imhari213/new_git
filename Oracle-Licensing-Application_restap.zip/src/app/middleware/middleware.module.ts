// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';

// components
import { MiddlewareListComponent } from './middleware-list/middleware-list.component';
import { MiddlewareCreateComponent } from './middleware-create/middleware-create.component';
import { OptionsInUseDialogComponent } from '../databases/options-in-use-dialog/options-in-use-dialog.component';
import { DeleteConfirmationComponent } from '../deletePopUp/delete-confirmation-dialog.component';
import { ComponentsDialogComponent } from './components-dialog/components-dialog.component';

@NgModule({
  declarations: [
    MiddlewareListComponent,
    MiddlewareCreateComponent,
    ComponentsDialogComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
  ],
  entryComponents: [OptionsInUseDialogComponent, DeleteConfirmationComponent, ComponentsDialogComponent]
})

export class MiddlewareModule {}
