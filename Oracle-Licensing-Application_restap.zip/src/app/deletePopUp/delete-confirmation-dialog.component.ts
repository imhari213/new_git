// angular
import { OnInit, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

// services
import { ThemeService } from '../theme.service';

@Component({
    selector: 'app-delete-confirmation-dialog',
    templateUrl: './delete-confirmation-dialog.component.html',
    styleUrls: ['./delete-confirmation-dialog.component.css'],
    providers: [ThemeService]
  })
  export class DeleteConfirmationComponent implements OnInit {
    constructor(
        public dialogRef: MatDialogRef<DeleteConfirmationComponent>,
        private themeService: ThemeService,
        @Inject(MAT_DIALOG_DATA) public data: any) {}

      ngOnInit() {
        if (this.themeService.getThemeSelected() === true ) {
          this.dialogRef.addPanelClass('dark-theme');
        }
      }

      confirmationYes() {
        this.dialogRef.close('yes');
      }

  }
