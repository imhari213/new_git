// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';

// components
import { DeclarationListComponent } from './declaration-list/declaration-list.component';
import { DeclarationCreateComponent } from './declaration-create/declaration-create.component';

@NgModule({
  declarations: [
    DeclarationListComponent,
    DeclarationCreateComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
  ],
  entryComponents: []
})

export class DeclarationsModule {}
