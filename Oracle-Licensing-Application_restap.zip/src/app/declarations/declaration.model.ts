
export interface AdditionalOracleProducts {
  _id: string;
  product: string;
  license_metric: string;
  existing_license_level: string;
  customer_support_identifier: string;
  license_grant: number;
  declared_usage: number;
  additional_comments: string;
  company: string;
}
