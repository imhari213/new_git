// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

// models
import { AdditionalOracleProducts } from './declaration.model';

// misc
import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';

const BACKEND_URL = environment.apiUrl  + '/declarations/';

@Injectable({providedIn: 'root'})
export class DeclarationService {

    private declarationsUpdated = new Subject<{declarations: AdditionalOracleProducts[], declarationCount: any}>();

    declarations: any;
    declarationCount: any;

    constructor(private http: HttpClient, private router: Router) {}

    addDeclaration(declarationObj) {
        return this.http.post<{message: String}>(BACKEND_URL, declarationObj);
    }

    updateDeclaration(declarationObj) {
        const declarationId = declarationObj._id;
        return this.http.put<{message: String}>(BACKEND_URL + 'update/' + declarationId, declarationObj);
    }

    getDeclarations(compId: String, searchParam, declarationsPerPage, currentPage, sortType) {
        const queryParams = `?pagesize=${declarationsPerPage}&page=${currentPage}&company=${compId}&sort=${sortType}`;
        this.http.get<{message: string, declarations: any, declarationCount: any}>
        (BACKEND_URL + 'search/' + searchParam + '/' + queryParams).subscribe(result => {
            this.declarations = result.declarations;
            this.declarationCount = result.declarationCount;
            this.declarationsUpdated.next({declarations: [...this.declarations], declarationCount: this.declarationCount});
        });
    }

    getDeclarationsListener() {
        return this.declarationsUpdated.asObservable();
    }

    getDeclaration(declarationId) {
        return this.http.get<{messgae: String, declaration: any}>(BACKEND_URL + '/declaration/' + declarationId);
    }

    deleteDeclaration(declarationId) {
        this.http.delete<{message: string, declarations: any, declarationCount: any}>
        (BACKEND_URL + 'delete/' + declarationId).subscribe(result => {
            this.declarations = result.declarations;
            this.declarationCount = result.declarationCount;
            this.declarationsUpdated.next({declarations: [...this.declarations], declarationCount: this.declarationCount});
        });
    }
}
