// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PageEvent } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';

// models
import { Company } from 'src/app/companies/company.model';

// services
import { DeclarationService } from '../declaration-service';
import { CompanyService } from '../../companies/companies.service';
import { AuthService } from 'src/app/auth/auth.service';
import { OptionsService } from '../../options.service';

// components
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-declaration-list',
  templateUrl: './declaration-list.component.html',
  styleUrls: ['./declaration-list.component.css']
})
export class DeclarationListComponent implements OnInit, OnDestroy {

  declarations: any;
  companies: Company[];
  compName: string;
  companyId: string;

  totalDeclarations = 0;
  declarationsPerPage = 20;
  pageSizeOptions = [20, 50, 100];
  currentPage = 1;
  searchParam: any;
  sortType: any;
  userIsAuthenticated: boolean;
  userRole = 'read';
  isLoading = false;
  checkedHeader;

  private authStatusSub: Subscription;
  private companySub: Subscription;
  private headerOptionSub: Subscription;

  constructor(private declarationService: DeclarationService, private companyService: CompanyService,
    private optionsService: OptionsService, private route: ActivatedRoute, private authService: AuthService,
    private router: Router, private dialog: MatDialog) {}

  ngOnInit() {
    this.getAuth();
    this.getCompanies();
    if (localStorage.getItem('compId')) {
      this.companyId = localStorage.getItem('compId');
    }
    this.route.paramMap.subscribe(paramMap => {
      if (paramMap.has('companyId')) {
        this.companyId = paramMap.get('companyId');
      }
    });
    this.getDeclarations();
    this.checkedHeader = this.optionsService.getHeaderOption();
    this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
    });
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  getDeclarations() {
    this.declarationService.getDeclarations(this.companyId, this.searchParam, this.declarationsPerPage, this.currentPage, this.sortType);
    this.declarationService.getDeclarationsListener().subscribe(result => {
      this.declarations = result.declarations;
      this.totalDeclarations = result.declarationCount;
      this.isLoading = false;
    });
  }

  onSearch(search: string) {
    if (search === '') {
      this.searchParam = undefined;
    } else {
      this.searchParam = search;
    }
    this.getDeclarations();
  }

  deleteDeclaration(event, declaration) {
    event.stopPropagation();

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: declaration.customer_support_identifier , pageViewName: 'declaration'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.declarationService.deleteDeclaration(declaration._id);
        this.declarationService.getDeclarationsListener().subscribe(result => {
          this.declarations = result.declarations;
        });
      }
    });
  }

  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    this.declarationsPerPage = pageData.pageSize;
    this.getDeclarations();
  }

  setSortType(type) {
    this.sortType = type;
    this.getDeclarations();
  }

  onExpand(declaration) {
    this.compName = this.companies.find(comp => comp._id === declaration.company).company_name;
  }

  ngOnDestroy() {
    this.companySub.unsubscribe();
    this.authStatusSub.unsubscribe();
    this.headerOptionSub.unsubscribe();
  }

}
