// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ParamMap, ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// models
import { Company } from '../../companies/company.model';
import { AdditionalOracleProducts } from '../declaration.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { CompanyService } from '../../companies/companies.service';
import { DeclarationService } from '../declaration-service';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-declaration-create',
  templateUrl: './declaration-create.component.html',
  styleUrls: ['./declaration-create.component.css'],
  providers: [{provide: STEPPER_GLOBAL_OPTIONS,
    useValue: { displayDefaultIndicatorType: false }}]
})
export class DeclarationCreateComponent implements OnInit, OnDestroy {

  companies: Company[];
  companyId: string;
  mode: string;
  declarationId: string;
  form: FormGroup;
  userIsAuthenticated: boolean;
  userRole = 'read';

  private companySub: Subscription;
  private authStatusSub: Subscription;

  constructor(private location: Location, private companyService: CompanyService,
    private declarationService: DeclarationService, private route: ActivatedRoute,
    private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.getAuth();
    this.createForm();

    if (localStorage.getItem('compId') !== 'null') {
      this.companyId = localStorage.getItem('compId');
      this.form.patchValue({company: this.companyId});
    }
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('companyId')) {
        this.companyId = paramMap.get('companyId');
        this.form.patchValue({company_name: this.companyId});
      }


      if (paramMap.has('declarationId')) {
        this.mode = 'edit';
        this.declarationId = paramMap.get('declarationId');
        this.declarationService.getDeclaration(this.declarationId).subscribe(result=> {
          this.fillForm(result.declaration);
        });
      } else {
        this.mode = 'create';
      }
    });
    this.getCompanies();
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  fillForm(declarationObj: AdditionalOracleProducts) {
    this.form.addControl('_id', new FormControl(null));
    this.form.patchValue({
      ...declarationObj
    });
  }

  createForm() {
    this.form = new FormGroup ({
      'product': new FormControl (null, {validators: [Validators.required]
      }),
      'license_metric': new FormControl (null, {validators: [Validators.required]
      }),
      'existing_license_level': new FormControl (null, {validators: [Validators.required]
      }),
      'customer_support_identifier': new FormControl (null, {validators: [Validators.required]
      }),
      'license_grant': new FormControl (null, {validators: [Validators.required]
      }),
      'declared_usage': new FormControl (null, {validators: [Validators.required]
      }),
      'additional_comments': new FormControl (null
      ),
      'company': new FormControl( null, {validators: [Validators.required]
      })
    });
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  addDeclaration() {
    if (this.form.invalid) {
      return;
    } else {
      if (this.mode === 'edit') {
        this.declarationService.updateDeclaration(this.form.value).subscribe(result => {
          this.router.navigate(['/list-declarations/']);
      });
      } else {
        this.declarationService.addDeclaration(this.form.value).subscribe(result => {
            this.router.navigate(['/list-declarations/']);
        });
      }
    }

  }

  onCancel() {
    this.location.back();
  }

  ngOnDestroy() {
    this.companySub.unsubscribe();
    this.authStatusSub.unsubscribe();
  }

}
