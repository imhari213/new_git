// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

// misc
import { Subject, of as observableOf } from 'rxjs';
import { environment } from '../environments/environment';

let themeSelected;

const USER_URL = environment.apiUrl  + '/user/';

@Injectable()

export class ThemeService {

  constructor(private http: HttpClient) {}

  private _darkTheme: Subject<boolean> = new Subject<boolean>();
  isDarkTheme = this._darkTheme.asObservable();

  setDarkTheme(isDarkTheme: boolean) {
    this._darkTheme.next(isDarkTheme);
    themeSelected = isDarkTheme;
  }

  darkThemeListener() {
    return this.isDarkTheme = this._darkTheme.asObservable();
  }

  updateUserThemeSelected(form: any) {
    this.http.put<{message: string, user: any}>(USER_URL + '/updateUserTheme/' + localStorage.getItem('userId'), form)
    .subscribe();
  }

  getUserThemeSelected() {
      this.http.get<{message: string, darkmode: any}>( USER_URL + '/getTheme/' + localStorage.getItem('userId')).subscribe(response => {
        themeSelected = response.darkmode;
        this.setDarkTheme(response.darkmode);
       });
  }

  getThemeSelected() {
    return themeSelected;
  }
}
