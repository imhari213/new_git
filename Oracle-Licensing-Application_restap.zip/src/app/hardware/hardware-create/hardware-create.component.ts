// angular
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ParamMap, ActivatedRoute } from '@angular/router';
import { MatDialog, MatTableDataSource, MatBottomSheet,
  MAT_DATE_FORMATS, MatSlideToggleChange, MatTabChangeEvent, MatTable } from '@angular/material';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { Location } from '@angular/common';

// models
import { Company } from '../../companies/company.model';
import { Contract } from '../../contracts/contract.model';
import { Hardware, Licenses } from '../hardware.model';
import { VCenter } from 'src/app/vcenter/vcenter.model';

// services
import { CompanyService } from 'src/app/companies/companies.service';
import { ContractService } from 'src/app/contracts/contracts.service';
import { HwService } from '../hardware.service';
import { AuthService } from 'src/app/auth/auth.service';
import { AuditService } from 'src/app/audit/audit.service';
import { VCenterService } from 'src/app/vcenter/vcenter.service';

// components

import { LicensesAllocatedComponent } from '../licenses-allocated-dialog/licenses-allocated-dialog.component';
import { VirtualisationComponent } from '../virtualisation-dialog/virtualisation-dialog.component';
import { CloudComponent } from '../cloud-dialog/cloud-dialog.component';
import { ServerDetailsBottomSheetComponent } from '../server-details-bottomsheet/server-details-bottom-sheet.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { CheckAddLicencesDialogComponent } from '../check-add-licences-dialog/check-add-licences-dialog.component';

// misc
import { Subscription } from 'rxjs';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

@Component({
  selector: 'app-hardware-create',
  templateUrl: './hardware-create.component.html',
  styleUrls: ['./hardware-create.component.css'],
  providers: [{provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
              {provide: STEPPER_GLOBAL_OPTIONS,
              useValue: { displayDefaultIndicatorType: false }}],
})

export class HardwareCreateComponent implements OnInit, OnDestroy {

  form: FormGroup;
  userIsAuthenticated: boolean;
  userRole: string;
  mode = 'create';
  hardwareId: string;

  isVirtualisationChecked = false;
  isCloudChecked = false;
  cloudOptions = ['AWS', 'Azure', 'Oracle Cloud', 'DI Cloud', 'Other'];
  virtualisationOptions = ['VMWare', 'IBM LPAR', 'OVM', 'Xen', 'Solaris', 'KVM', 'HP UX', 'Other'];
  otherChecked = false;
  licenseColumns: String[] = ['virtual', 'contract', 'product', 'metric', 'number', 'restricted', 'edit'];
  licenseDataSource = <any>[];

  companyId: string;
  virtType: string;
  cloudType: any;
  tableArray: string[];
  virtualisationSource: MatTableDataSource<any>;
  vcenterSource: MatTableDataSource<any>;
  dcSource: MatTableDataSource<any>;
  clusterSource: MatTableDataSource<any>;
  cloudTable: any[];
  virtualisationTable: string[];
  virtualisationColumns;
  vcTableArray = ['vcenter_server_name', 'vcenter_version'];
  vcenterColumns = ['Vcenter Server Name', 'Vcenter Version', 'next'];
  dcTableArray = ['data_center'];
  dcColumns = ['Data Center', 'next'];
  clusterTableArray = ['cluster'];
  clusterColumns = ['Cluster Name', 'select'];
  clusterBoolArray = [];
  toggle = 'open';

  virtArray = <any>[];
  vmIndex: number;
  dataCenterArray;
  clusterArray;
  vcenterId;
  dataCenterId;
  vcenterindex: number;
  dataCenters: any;
  checkedIndex: any;
  checkedCluster: any;
  clusterInfo: any;

  hardware: Hardware;
  licensesAdded: Licenses[] = [];
  contracts: Contract[];
  companies: Company[];
  vcenters: VCenter[];

  authStatusSub: Subscription;
  companySub: Subscription;
  vcenterSub: Subscription;
  contractSub: Subscription;

  @ViewChild('vcenterTable') vcenterTable: MatTable<any>;
  @ViewChild('dataCenterTable') dataCenterTable: MatTable<any>;
  @ViewChild('clusterTable') clusterTable: MatTable<any>;
  contractsForAllocation: any;

  constructor(private hardwareService: HwService, private authService: AuthService, private companyService: CompanyService,
              private vCenterService: VCenterService, private dialog: MatDialog, private router: Router,
              private route: ActivatedRoute, private contractService: ContractService, private location: Location,
              private bottomSheet: MatBottomSheet, private auditService: AuditService) {}

  ngOnInit() {

    this.getAuth();
    this.createForm();

    if (localStorage.getItem('compId') !== 'null') {
      this.companyId = localStorage.getItem('compId');
      this.form.patchValue({company_name: this.companyId});
      this.getVCenters();
    }

    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('companyId')) {
        this.companyId = paramMap.get('companyId');
        this.form.patchValue({company_name: this.companyId});
        this.getVCenters();
      }


      if (paramMap.has('hardwareId')) {
        this.mode = 'edit';
        this.hardwareId = paramMap.get('hardwareId');
        this.hardwareService.getHardware(this.hardwareId).subscribe(hardwareData => {
          this.form.controls['company_name'].disable();
          this.hardware = hardwareData;
          this.companyId = this.hardware.company;
          this.fillForm();
          this.getContracts();
        });
      }
    });
    this.getCompanies();
  }

  reloadData() {
    this.hardwareService.getHardware(this.hardwareId).subscribe(hardwareData => {
      this.hardware = hardwareData;
      this.companyId = this.hardware.company;
      this.fillForm();
    });
  }

  ngOnDestroy() {}

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  createForm() {
    this.form = new FormGroup({
      'company_name': new FormControl(null, {validators: [Validators.required]
      }),
      'server_name': new FormControl(null, {validators: [Validators.required]
      }),
      'server_model': new FormControl(null, {validators: [Validators.required]
      }),
      'cluster_id': new FormControl(null
      ),
      'virtualisation_name': new FormControl(null
      ),
      'other_virt': new FormControl(null
      ),
      'virtual_server_name': new FormControl(null
      ),
      'virtualisation_description': new FormControl(null
      ),
      'operating_system': new FormControl(null
      ),
      'processor_model': new FormControl(null, {validators: [Validators.required]
      }),
      'processors': new FormControl(null, {validators: [Validators.required]
      }),
      'cores_per_processor': new FormControl(null
      ),
      'total_physical_cores': new FormControl(null
      ),
      'cores_enabled': new FormControl(null
      ),
      'threads_per_core': new FormControl(null
      ),
      'multi_core_chip_or_multi_chip_model': new FormControl(null
      ),
      'processor_speed': new FormControl(null
      ),
      'server_purchase_date': new FormControl(null
      ),
      'server_location': new FormControl(null
      ),
      'commission_date': new FormControl(null
      ),
      'decommission_date': new FormControl(null
      ),
      'hardware_refresh_term_or_date': new FormControl(null
      ),
      'license_allocated_to_server': new FormControl(null
      ),
      'vs_type': new FormControl(null
      ),
      'ibm_virt': new FormControl(null
      ),
      'ovm_virt': new FormControl(null
      ),
      'xen_virt': new FormControl(null
      ),
      'vmware_virt': new FormControl(null
      ),
      'solaris_virt': new FormControl(null
      ),
      'kvm_virt': new FormControl(null
      ),
      'hp_ux_virt': new FormControl(null
      ),
      'cloud_type': new FormControl(null
      ),
      'aws_cloud': new FormControl(null
      ),
      'azure_cloud': new FormControl(null
      ),
      'oracle_cloud': new FormControl(null
      ),
      'di_cloud': new FormControl(null
      ),
      'other_cloud': new FormControl(null
      ),
    });
  }

  fillForm() {

    this.form.patchValue({
      ...this.hardware,
      'company_name': this.hardware.company,
      'server_name': this.hardware.server_name,
    });

    if (this.hardware.license_allocated_to_server && this.hardware.license_allocated_to_server.length > 0) {
      this.licensesAdded = this.hardware.license_allocated_to_server;
    }
    this.licenseDataSource = new MatTableDataSource(this.licensesAdded);

    if (this.hardware.ibm_virt && this.hardware.ibm_virt.length > 0) {
      this.virtArray = this.hardware.ibm_virt;
      this.virtType = 'IBM LPAR';
    } else if (this.hardware.ovm_virt && this.hardware.ovm_virt.length > 0) {
      this.virtArray = this.hardware.ovm_virt;
      this.virtType = 'OVM';
    } else if (this.hardware.xen_virt && this.hardware.xen_virt.length > 0) {
      this.virtArray = this.hardware.xen_virt;
      this.virtType = 'XEN';
    } else if (this.hardware.cluster_id) {
      this.clusterInfo = this.hardware.cluster_id;
      if (this.hardware.vmware_virt && this.hardware.vmware_virt.length > 0) {
        this.virtArray = this.hardware.vmware_virt;
      } else {
        this.virtArray = [];
      }
      this.virtType = 'VMWare';
    } else if (this.hardware.solaris_virt && this.hardware.solaris_virt.length > 0) {
      this.virtArray = this.hardware.solaris_virt;
      this.virtType = 'Solaris';
    } else if (this.hardware.kvm_virt && this.hardware.kvm_virt.length > 0) {
      this.virtArray = this.hardware.kvm_virt;
      this.virtType = 'KVM';
    } else if (this.hardware.hp_ux_virt && this.hardware.hp_ux_virt.length > 0) {
      this.virtArray = this.hardware.hp_ux_virt;
      this.virtType = 'HP UX';
    } else if (this.hardware.aws_cloud && this.hardware.aws_cloud.length > 0) {
      this.virtArray = this.hardware.aws_cloud;
      this.cloudType = 'AWS';
    } else if (this.hardware.azure_cloud && this.hardware.azure_cloud.length > 0) {
      this.virtArray = this.hardware.azure_cloud;
      this.cloudType = 'Azure';
    } else if (this.hardware.oracle_cloud && this.hardware.oracle_cloud.length > 0) {
      this.virtArray = this.hardware.oracle_cloud;
      this.cloudType = 'Oracle Cloud';
    } else if (this.hardware.di_cloud && this.hardware.di_cloud.length > 0) {
      this.virtArray = this.hardware.di_cloud;
      this.cloudType = 'DI Cloud';
    }

    if (this.virtType) { this.isVirtualisationChecked = true; this.form.patchValue({vs_type: this.virtType}); }
    if (this.cloudType) { this.isCloudChecked = true; this.form.patchValue({cloud_type: this.cloudType}); }

    if (this.virtType || this.cloudType) {
      this.addingTab();
      this.virtualisationSource = new MatTableDataSource(this.virtArray);
    }

  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  getContracts() {
    this.contractService.searchValidContacts(this.companyId).subscribe(result => {
      this.contractsForAllocation = result.contracts;
    });
    /*
    this.contractService.searchContract(this.companyId, null, null, null);
    this.contractSub = this.contractService.getAllContractsUpdateListener()
    .subscribe((contractData: {contracts: Contract[], contractCount: Number}) => {
      this.contracts = contractData.contracts;
    });*/
  }

  setCompId() {
    this.companyId = this.form.value.company_name;
  }

  slider(event: MatSlideToggleChange, type: String) {

    this.otherChecked = false;
    this.form.patchValue({other_virt: null, other_cloud: null});

    if (event.checked === true && type === 'virt') {
      this.isVirtualisationChecked = true;
      this.isCloudChecked = false;
    }

    if (event.checked === true && type === 'cloud') {
      this.isVirtualisationChecked = false;
      this.isCloudChecked = true;

      this.virtType = null;
      this.form.patchValue({'vs_type': null});
    }

    if (event.checked === false) {
      this.isVirtualisationChecked = false;
      this.isCloudChecked = false;

      this.virtType = null;
      this.form.patchValue({'vs_type': null});
    }

  }

  addingTab() {
    this.virtType = this.form.value.vs_type;
    this.cloudType = this.form.value.cloud_type;

    if (this.virtType === 'VMWare') {
      this.getVCenters();
      if (this.mode === 'edit') {
        this.vmIndex = 3;

      }
    } else {
      if (this.virtType === 'Other' || this.cloudType === 'Other') {
        this.otherChecked = true;
      } else {
        this.otherChecked = false;
      }
      this.cloudTable = [this.cloudType];
      this.virtualisationTable = [this.virtType];
      this.setTable();
    }

  }

  getVCenters() {

    this.vCenterService.getVCenters('company', this.companyId, null, null);
    this.vcenterSub = this.vCenterService.getVCenterUpdateListener()
    .subscribe((vcenterData: {vcenters: VCenter[]; vcenterCount: Number}) => {
      this.vcenters = vcenterData.vcenters;
      this.vcenterSource = new MatTableDataSource(this.vcenters);
      this.setTable();

      if (this.clusterInfo) {
        this.vcenters.forEach(vc => {
          vc.dataCenters.forEach(dc => {
            dc.clusters.forEach(cluster => {
              if (cluster._id === this.clusterInfo) {
                this.vcenterId = vc._id;
                this.dataCenterId = this.vcenterId;
                this.dataCenters = vc.dataCenters;
                this.clusterArray = dc.clusters;

                this.clusterArray.forEach(cl => {
                  const newObj = {_id: cl._id, cluster: cl.cluster, selected: false};
                  if (cl._id === this.clusterInfo) { newObj.selected = true; }
                  this.clusterBoolArray.push(newObj);
                });

                this.clusterSource = new MatTableDataSource(this.clusterBoolArray);
                this.dcSource = new MatTableDataSource(this.dataCenters);

              }
            });
          });
        });
      }
    });

  }

  setTable() {

    this.tableArray = [];
    this.virtualisationColumns = [];

    if (this.virtType === 'IBM LPAR') {
      this.tableArray = ['virtual_server_name', 'machine_serial_number', 'partition_name', 'partion_type', 'mode'];
      this.virtualisationColumns = ['Virtual Server Name', 'Machine Serial Number', 'Partition Name', 'Partition Type', 'Mode', 'edit'];
    }
    if (this.virtType === 'OVM') {
      this.tableArray = ['virtual_server_name', 'uuid', 'max_vcpus', 'vcpus', 'cpu_affinity', 'total_cpus'];
      this.virtualisationColumns = ['Basic Name', 'UUID', 'Max vCpus', 'vCPUs', 'CPU Affinity', 'Total CPUs', 'edit'];
    }
    if (this.virtType === 'Xen') {
      this.tableArray = ['virtual_server_name', 'cpu_affinity', 'vcpus', 'dedicated_vcpus', 'notes'];
      this.virtualisationColumns = ['Virtual Server Name', 'CPU Affinity', 'vCPUs', 'Dedicated CPUs', 'Notes', 'edit'];
    }
    if (this.virtType === 'Solaris') {
      this.tableArray = ['virtual_server_name', 'type_of_solaris_partitioning', 'notes'];
      this.virtualisationColumns = ['Virtual Server Name', 'Type', 'Notes', 'edit'];
    }
    if (this.virtType === 'KVM') {
      this.tableArray = ['virtual_server_name', 'vcpus', 'cpu_affinity', 'total_cpus', 'pinned'];
      this.virtualisationColumns = ['Virtual Server Name', 'vCPUs', 'CPU Affinity', 'Total CPUs', 'Pinned', 'edit'];
    }

    if (this.virtType === 'VMWare') {
      this.tableArray = ['vm_host_name', 'virtual_server_name', 'vm_guest_host_name', 'vm_guest_os', 'vm_ip_address'],
      this.virtualisationColumns = ['Host', 'Virtual Server Name', 'Guest Host', 'Guest OS', 'IP Address', 'edit'];
    }

    if (this.virtType === 'HP UX') {
      this.tableArray = ['virtual_server_name'];
      // 'number_of_sockets', 'cores_per_socket', 'logical_processors', 'lcpu_attribute', 'complex_name', 'complex_serial_number',
      // 'complex_product_order_number', 'complex_id_number', 'total_core_usage_rights', 'committed_core_usage_rights',
      // 'available_core_usage_rights', 'number_of_partitions_present', 'npar_id', 'npar_name', 'npar_state', 'npar_has_vpars',
      // 'npar_intended_active', 'npar_total_cores', 'npar_actual_active', 'npar_assigned_cores', 'vpar_id', 'vpar_name', 'vpar_state',
      // 'vpar_assigned_cores',  'vpar_actual_active', 'vpar_committed_rights', 'capped', 'cpu_min', 'cpu_max', 'licensable_cores',
      // 'cpu_entitlements_fss', 'cpu_entitlements_pset', 'srp_name', 'prm_id', 'pset', 'prm_licensable_cores', 'notes' ];
      // this.virtualisationColumns = ['Server Name', 'No of Sockets', 'Cores per Socket', 'Logical Processors', 'LCPU Attribute',
      // 'Complex Name', 'Complex Serial NUmber', 'Complex Product Order No', 'Complex ID Number',
      // 'Total Core Usage Rights', 'Committed Core Usage Rights', 'Available Core Usage Rights', 'No of Partitions Present',
      // 'NPAR ID', 'NPAR Name', 'NPAR State', 'NPAR has VPARS', 'NPAR Intended Active', 'NPAR total Cores', 'NPAR Actual Active',
      //            'NPAR Assigned Cores',
      // 'VPAR ID', 'VPAR Name', 'VPAR State', 'VPAR Assigned Cores', 'VPAR Actual Active', 'VPAR Committed Rights',
      // 'Capped', 'CPU Min', 'CPU Max', 'Licensable Cores',
      // 'CPU Entitlements', 'CPU Entitlements PSET', 'SRP Name', 'PRM ID', 'PSET', 'PRM Licensable Cores', 'Notes', 'edit'];
      this.virtualisationColumns = ['Virtual Server Name', 'LCPU Attribute', 'Complex Name', 'Total Core Usage Rights', 'No of Partitions Present', 'NPAR ID', 'NPAR Name', 'VPAR ID', 'VPAR Name', 'Capped', 'CPU Entitlements', 'Notes', 'edit'];
    }


    if (this.cloudType) {
      this.tableArray = ['virtual_server_name', 'description', 'instance_type', 'vcpus', 'hyperthreaded', 'license_method'];
      this.virtualisationColumns = ['Server Name', 'Description', 'Type', 'vCPUs', 'Hyper Threaded?', 'Method', 'edit'];
    }

    this.virtualisationSource = new MatTableDataSource(this.virtArray);
  }

  getElement(i, index) {
    return i[this.tableArray[index]];
  }

  addHw() {



    // this.sortVirtObj();

    if (this.virtType === 'IBM LPAR' || this.virtType === 'IBM') { this.form.patchValue({ibm_virt: this.virtArray}); }
    if (this.virtType === 'OVM') { this.form.patchValue({ovm_virt: this.virtArray}); }
    if (this.virtType === 'XEN') { this.form.patchValue({xen_virt: this.virtArray}); }
    if (this.virtType === 'VMWare') {
      this.form.patchValue({vmware_virt: this.virtArray});
      this.form.patchValue({cluster_id: this.clusterInfo}); }
    if (this.virtType === 'Solaris') { this.form.patchValue({solaris_virt: this.virtArray}); }
    if (this.virtType === 'KVM') { this.form.patchValue({kvm_virt: this.virtArray}); }
    if (this.virtType === 'HP UX') { this.form.patchValue({hp_ux_virt: this.virtArray}); }
    if (this.cloudType === 'AWS') { this.form.patchValue({aws_cloud: this.virtArray}); }
    if (this.cloudType === 'Azure') { this.form.patchValue({azure_cloud: this.virtArray}); }
    if (this.cloudType === 'Oracle Cloud') { this.form.patchValue({oracle_cloud: this.virtArray}); }
    if (this.cloudType === 'DI Cloud') { this.form.patchValue({di_cloud: this.virtArray}); }

    if (this.mode === 'create') {
      const dialogRef = this.dialog.open(CheckAddLicencesDialogComponent, {
        width: '50%'
      });
      dialogRef.afterClosed().subscribe(updateData => {
        this.sortVirtObj();
        this.bottomSheet.dismiss();

        if (updateData === 'Yes') {
        this.hardwareService.quicksave(this.form.value).subscribe(returnData => {

        this.router.navigate(['/edit-hardware/' + returnData.id]);
      });
        } else {
          this.hardwareService.addHw(this.form.value).subscribe(returnDate => {
            this.router.navigate(['/list-hardware/']);
          });
        }
      });
    } else {
      this.licensesAdded.forEach(lic => {
        const contractLinked = this.contractsForAllocation.find(con => con._id === lic.contract_linked);
        this.contractService.updateContract(contractLinked._id, contractLinked);
      });

      this.form.patchValue({license_allocated_to_server: this.licensesAdded.filter(lic => lic.number_of_licenses_in_use > 0)});

      this.hardwareService.updateHardware(this.hardware._id, this.form.value).subscribe(returnData => {
        this.hardwareService.getHardware(this.hardwareId).subscribe(hardwareData => {
          this.form.controls['company_name'].disable();
          this.hardware = hardwareData;
          this.companyId = this.hardware.company;
          this.fillForm();
          this.getContracts();
        });
        this.router.navigate(['/list-hardware/']);
      });
    }

  }

  sortVirtObj() {}

  deleteVirtData(element) {

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'virtualisation', name: element.virtual_server_name }
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        const index = this.virtArray.indexOf(element);
        this.virtArray.splice(index, 1);
        this.virtualisationSource = new MatTableDataSource(this.virtArray);
      }
    });

  }

  onCancel() {

    this.bottomSheet.dismiss();
    if (this.companyId) {
      this.router.navigate(['/list-hardware/']);
    } else {
      this.router.navigate(['/list-hardware/']);
    }
  }

  sortSolarisObj(data) {
    const newSolObj = {
      _id: data._id,
      virtual_server_name: data.virtual_server_name,
      type_of_solaris_partitioning: data.type_of_solaris_partitioning,
      notes: data.notes,
      pool_type: null,
      local_zone_type: null,
      ovm_for_sparc_type: null
    };

    if (data.type_of_solaris_partitioning === 'Pool') {
      newSolObj.pool_type = {
        pool_name: data.pool_name,
        pset_value_for_zone_from_physical: data.pset_value_for_zone_from_physical,
        pset_value_for_zone_from_virtual: data.pset_value_for_zone_from_virtual,
        total_count_core_id: data.total_count_core_id
      };
    }

    if (data.type_of_solaris_partitioning === 'Local Zone') {
      newSolObj.local_zone_type = {
        dedicated_cpu: data.dedicated_cpu,
        capped_cpus: data.capped_cpus,
        ncpus: data.ncpus,
      };
    }

    if (data.type_of_solaris_partitioning === 'OVM for Sparc') {
      newSolObj.ovm_for_sparc_type = {
        constraint: data.constraint,
        whole_core: data.whole_core,
        max_cores: data.max_cores,
        pinned: data.pinned,
      };
    }
    return newSolObj;
  }

  addVirtData(index) {

    let current_virt;
    try { current_virt = this.virtArray[index]; } catch { current_virt = null; }

    const dialogRef = this.dialog.open(VirtualisationComponent, {
      disableClose: true,
      width: '50%',
      data: { type: this.virtType,  virt: current_virt }
    });

    dialogRef.afterClosed().subscribe(updateData => {
      this.bottomSheet.dismiss();
      if (updateData) {
        let data = updateData.data;

        if (this.virtType === 'Solaris') {
          data = this.sortSolarisObj(data);
        }
        if (current_virt) {
          data._id = current_virt._id;
          this.virtArray[index] = data;
        } else {
          this.virtArray.push(data);
        }
        this.virtualisationSource = new MatTableDataSource(this.virtArray);
      }
    });

  }

  addCloudData(index) {

    let current_virt;

    try { current_virt = this.virtArray[index]; } catch { current_virt = null; }

    const dialogRef = this.dialog.open(CloudComponent, {
      disableClose: true,
      width: '50%',
      data: {type: this.cloudType, cloud: current_virt}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        const data = updateData;
        if (current_virt) {
          data._id = current_virt._id;
          this.virtArray[index] = data;
        } else {
          this.virtArray.push(data);
        }
        this.virtualisationSource = new MatTableDataSource(this.virtArray);
      } else {
        console.log('closed');
      }
    });

  }

  setVMwareTabIndex(event: MatTabChangeEvent) {
    if (event.tab.textLabel === 'Virtual Center') {
      this.vmIndex = 0;
    } else if (event.tab.textLabel === 'Data Centers') {
      this.vmIndex = 1;
    } else if (event.tab.textLabel === 'Clusters') {
      this.vmIndex = 2;
    } else if (event.tab.textLabel === 'VMWare') {
        this.vmIndex = 3;
    }
  }

  checkCluster(event, index, cluster) {
    this.clusterInfo = cluster._id;
    this.clusterBoolArray.forEach(clust => {
      clust.selected = false;
    });
    this.clusterBoolArray[index].selected = event.checked;
  }




  changeTab(vcenter, section: string) {
    // this.vcenterindex = 1;
    if (section === 'vCenters') {
      this.vcenterId = vcenter._id;
      this.dataCenters = vcenter.dataCenters;
      this.vmIndex = 1;
      this.dcSource = new MatTableDataSource(this.dataCenters);
    } else if (section === 'dataCenters') {
      // this.vcenterindex = 3;
      this.clusterArray = this.dataCenters.find(dc => dc === vcenter).clusters;
      this.dataCenterId = this.vcenterId;
      this.vmIndex = 2;
      this.clusterBoolArray = [];
      this.clusterArray.forEach(cluster => {
        const newObj = {cluster: cluster.cluster, selected: false, _id: cluster._id};
        this.clusterBoolArray.push(newObj);
      });
      this.clusterSource = new MatTableDataSource(this.clusterBoolArray);
    }
  }

  openBottomSheet(): void {
    this.toggle = 'close';
    const bottomSheetRef = this.bottomSheet.open(ServerDetailsBottomSheetComponent, {
      hasBackdrop: false,
      panelClass: ['custom-width'],
      data: {Physical: this.form.value},
    });
    bottomSheetRef.afterDismissed().subscribe(() => {
      this.toggle = 'open';
    });
  }

  toggleBottomsheet() {
    if (this.toggle === 'open') {
      this.openBottomSheet();
    } else {
      this.bottomSheet.dismiss();
    }
  }

  virtualisationLinked(element) {
    const virtId = element.virtualisation_linked;
    let virt;
    try {
      if (virtId === this.hardwareId) { virt = '*' + this.hardware.server_name; }
      if (!virt) { virt = this.virtArray.find(v => v._id === virtId).virtual_server_name; }
    } catch {
      virt = 'unknown';
    }
    return virt;
  }

  contractLinked(element) {
    let contract;
    try {
      contract = this.contractsForAllocation.find(con => con._id === element.contract_linked).customer_support_identifier;
    } catch {
      contract = 'unknown';
    }
    return contract;
  }

  productLicensed(element) {
    let product;
    try {
      const oracle_licenses = this.contractsForAllocation.find(con => con._id === element.contract_linked).oracle_licenses;
      product = oracle_licenses.find(lic => lic._id === element.product_licensed).product_name;
    } catch {
      product = 'unknown';
    }

    return product;
  }

  openLicenseDialog(element) {

    let index;

    if (element) { index = this.licensesAdded.indexOf(element); }

    const dialogRef = this.dialog.open(LicensesAllocatedComponent, {
      disableClose: true,
      width: '50%',
      data: {contracts: this.contractsForAllocation,
        hardware: this.hardware,
        virtType: this.virtType,
        virtList: this.virtArray.filter(virt => virt._id),
        license: element
      }
    });

    dialogRef.afterClosed().subscribe(newLicenseData => {
      if (newLicenseData) {
        const data = newLicenseData.data;
        let diff = 0;

        if (element) {
          diff = element.number_of_licenses_in_use;
          data._id = element._id;
          this.licensesAdded[index] = data;
        } else {
          this.licensesAdded.push(data);
        }

        const oracle_licenses = this.contractsForAllocation.find(con => con._id === data.contract_linked).oracle_licenses;
        const product = oracle_licenses.find(prod => prod._id === data.product_licensed);
        product.allocated = product.allocated - diff + data.number_of_licenses_in_use;
        product.allowed = product.allowed + diff - data.number_of_licenses_in_use;

        this.licenseDataSource = new MatTableDataSource(this.licensesAdded);
      } else {
        console.log('closed');
      }
    });

  }

  getLicenses() {
    const filtered = this.licensesAdded.filter(lic => lic.number_of_licenses_in_use > 0);
    return new MatTableDataSource(filtered);
  }

  onDeleteOracleLicence(element) {

    const oracle_licenses = this.contractsForAllocation.find(con => con._id === element.contract_linked).oracle_licenses;
    const product = oracle_licenses.find(lic => lic._id === element.product_licensed);

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'license', name: product.product_name }
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        product.allocated -= element.number_of_licenses_in_use;
        product.allowed += element.number_of_licenses_in_use;

        element.number_of_licenses_in_use = 0;
        // this.licensesAdded.splice(index, 1);

        this.licenseDataSource = new MatTableDataSource(this.licensesAdded);
      }
    });

  }

}
