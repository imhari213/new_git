// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// services
import { ThemeService } from '../../theme.service';
import { ActProcCount, ComplexInfo, CoreUsageDets, HPUX, NPartitionSumm, SecureResourcepartition, VirtualPartSumm, VPartitionSumm } from '../hardware.model';

@Component({
  selector: 'app-virtualisation-dialog',
  templateUrl: './virtualisation-dialog.component.html',
  styleUrls: ['./virtualisation-dialog.component.css'],
  providers: [ThemeService]
})

export class VirtualisationComponent implements OnInit {

  form: FormGroup;
  mode = 'create';

  virtType;
  virt;
  solarisOption = '';
  migrationSelected: any;
  availabilitySelected: any;
  solarisOptions = ['Pool', 'Local Zone', 'OVM for Sparc'];
  pinnedSelected: any;
  isStandalone = false;
  hasVpars = false;
  intendedActive = false;
  capped = false;

  constructor(private themeService: ThemeService, public dialogRef: MatDialogRef<VirtualisationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {

    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }

    this.virtType = this.data.type;
    if (this.data.virt) { this.mode = 'edit'; this.virt = this.data.virt; }

    if (this.virtType === 'Solaris') { this.setSolaris(); } else
    if (this.virtType === 'IBM' || this.virtType === 'IBM LPAR') { this.setIBM(); } else
    if (this.virtType === 'OVM') { this.setOVM(); } else
    if (this.virtType === 'KVM') { this.setKVM(); } else
    if (this.virtType === 'Xen') { this.setXEN(); } else
    if (this.virtType === 'VMWare') { this.setVMWare(); } else
    if (this.virtType === 'HP UX') { this.setHPUX(); }

  }


  setSolaris() {
    this.form = new FormGroup({
      '_id': new FormControl(null),
      'virtual_server_name': new FormControl(null, {validators: [Validators.required]}),
      'type_of_solaris_partitioning': new FormControl(null),
      'pool_name': new FormControl(null),
      'pset_value_for_zone_from_physical': new FormControl(null),
      'pset_value_for_zone_from_virtual': new FormControl(null),
      'total_count_core_id': new FormControl(null),
      'dedicated_cpu': new FormControl(null),
      'capped_cpus': new FormControl(null),
      'ncpus': new FormControl(null),
      'constraint': new FormControl(null),
      'whole_core': new FormControl(null),
      'max_cores': new FormControl(null),
      'pinned': new FormControl(null),
      'notes': new FormControl(null)
    });

    if (this.virt) {
      this.form.patchValue({
        '_id': this.virt._id,
        'virtual_server_name': this.virt.virtual_server_name,
        'type_of_solaris_partitioning': this.virt.type_of_solaris_partitioning,
        'notes': this.virt.notes
      });
      this.setSolarisOption();
      if (this.solarisOption === 'Pool') {
        this.form.patchValue({'pool_name': this.virt.pool_type.pool_name,
                              'pset_value_for_zone_from_physical': this.virt.pool_type.pset_value_for_zone_from_physical,
                              'pset_value_for_zone_from_virtual': this.virt.pool_type.pset_value_for_zone_from_virtual,
                              'total_count_core_id': this.virt.pool_type.total_count_core_id});
      }
      if (this.solarisOption === 'Local Zone') {
        this.form.patchValue({'dedicated_cpu': this.virt.local_zone_type.dedicated_cpu,
                              'capped_cpus': this.virt.local_zone_type.capped_cpus,
                              'ncpus': this.virt.local_zone_type.ncpus});
      }
      if (this.solarisOption === 'OVM for Sparc') {
        this.form.patchValue({'constraint': this.virt.ovm_for_sparc_type.constraint,
                              'whole_core': this.virt.ovm_for_sparc_type.whole_core,
                              'max_cores': this.virt.ovm_for_sparc_type.max_cores,
                              'pinned': this.virt.ovm_for_sparc_type.pinned});
      }
    }
  }

  setHPUX() {
    this.form = new FormGroup({
      '_id': new FormControl(null),
      'virtual_server_name': new FormControl(null),

      'number_of_sockets': new FormControl(null),
      'cores_per_socket': new FormControl(null),
      'logical_processors': new FormControl(null),
      'lcpu_attribute': new FormControl(null),

      'complex_name': new FormControl(null),
      'complex_serial_number': new FormControl(null),
      'complex_product_order_number': new FormControl(null),
      'complex_id_number': new FormControl(null),

      'total_core_usage_rights': new FormControl(null),
      'committed_core_usage_rights': new FormControl(null),
      'available_core_usage_rights': new FormControl(null),
      'number_of_partitions_present': new FormControl(null),

      'npar_id': new FormControl(null),
      'npar_name': new FormControl(null),
      'npar_state': new FormControl(null),
      'npar_has_vpars': new FormControl(null),
      'npar_intended_active': new FormControl(null),
      'npar_total_cores': new FormControl(null),
      'npar_actual_active': new FormControl(null),
      'npar_assigned_cores': new FormControl(null),

      'vpar_id': new FormControl(null),
      'vpar_name': new FormControl(null),
      'vpar_state': new FormControl(null),
      'vpar_assigned_cores': new FormControl(null),
      'vpar_actual_active': new FormControl(null),
      'vpar_committed_rights': new FormControl(null),

      'capped': new FormControl(null),
      'cpu_min': new FormControl(null),
      'cpu_max': new FormControl(null),
      'licensable_cores': new FormControl(null),

      'cpu_entitlements_fss': new FormControl(null),
      'cpu_entitlements_pset': new FormControl(null),
      'srp_name': new FormControl(null),
      'prm_id': new FormControl(null),
      'pset': new FormControl(null),
      'licensables_cores': new FormControl(null),
      'notes': new FormControl(null),

    });

    if (this.virt) {
      this.form.patchValue({
        '_id': this.virt._id,
        'virtual_server_name': this.virt.virtual_server_name,

        'number_of_sockets': this.virt.active_processor_count.number_of_sockets,
        'cores_per_socket': this.virt.active_processor_count.cores_per_socket,
        'logical_processors': this.virt.active_processor_count.logical_processors,
        'lcpu_attribute': this.virt.active_processor_count.lcpu_attribute,

        'complex_name': this.virt.complex_information.complex_name,
        'complex_serial_number': this.virt.complex_information.complex_serial_number,
        'complex_product_order_number': this.virt.complex_information.complex_product_order_number,
        'complex_id_number': this.virt.complex_information.complex_id_number,

        'total_core_usage_rights': this.virt.core_usage_right_details.total_core_usage_rights,
        'committed_core_usage_rights': this.virt.core_usage_right_details.committed_core_usage_rights,
        'available_core_usage_rights': this.virt.core_usage_right_details.available_core_usage_rights,
        'number_of_partitions_present': this.virt.core_usage_right_details.number_of_partitions_present,

        'npar_id': this.virt.npartition_resource_summary.npar_id,
        'npar_name': this.virt.npartition_resource_summary.npar_name,
        'npar_state': this.virt.npartition_resource_summary.npar_state,
        // 'npar_has_vpars': this.virt.npartition_resource_summary._npar_has_vparsid,
        // 'npar_intended_active': this.virt.npartition_resource_summary.npar_intended_active,
        'npar_total_cores': this.virt.npartition_resource_summary.npar_total_cores,
        'npar_actual_active': this.virt.npartition_resource_summary.npar_actual_active,
        'npar_assigned_cores': this.virt.npartition_resource_summary.npar_assigned_cores,

        'vpar_id': this.virt.vpartition_resource_summary.vpar_id,
        'vpar_name': this.virt.vpartition_resource_summary.vpar_name,
        'vpar_state': this.virt.vpartition_resource_summary.vpar_state,
        'vpar_assigned_cores': this.virt.vpartition_resource_summary.vpar_assigned_cores,
        'vpar_actual_active': this.virt.vpartition_resource_summary.vpar_actual_active,
        'vpar_committed_rights': this.virt.vpartition_resource_summary.vpar_committed_rights,

        // 'capped': this.virt.virtual_partition_resource_summary.capped,
        'cpu_min': this.virt.virtual_partition_resource_summary.cpu_min,
        'cpu_max': this.virt.virtual_partition_resource_summary.cpu_max,
        'licensable_cores': this.virt.virtual_partition_resource_summary.licensable_cores,

        'cpu_entitlements_fss': this.virt.secure_resource_partitions.cpu_entitlements_fss,
        'cpu_entitlements_pset': this.virt.secure_resource_partitions.cpu_entitlements_pset,
        'srp_name': this.virt.secure_resource_partitions.srp_name,
        'prm_id': this.virt.secure_resource_partitions.prm_id,
        'pset': this.virt.secure_resource_partitions.pset,
        'licensables_cores': this.virt.secure_resource_partitions.licensables_cores,
        'notes': this.virt.secure_resource_partitions.notes
      });

      this.hasVpars = this.virt.npartition_resource_summary.npar_has_vpars;
      this.intendedActive = this.virt.npartition_resource_summary.npar_intended_active;
      this.capped = this.virt.virtual_partition_resource_summary.capped;
    }
  }

  setIBM() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'virtual_server_name': new FormControl(null, {validators: [Validators.required]
      }),
      'machine_serial_number': new FormControl(null
      ),
      'partition_name': new FormControl(null
      ),
      'partition_number': new FormControl(null
      ),
      'partition_type': new FormControl(null
      ),
      'mode': new FormControl(null
      ),
      'entitled_capacity': new FormControl(null
      ),
      'shared_pool_id': new FormControl(null
      ),
      'online_virtual_cpus': new FormControl(null
      ),
      'maximum_physical_cpus_in_system': new FormControl(null
      ),
      'active_physical_cpus_in_system': new FormControl(null
      ),
      'shared_physical_cpus_in_system': new FormControl(null
      ),
      'notes': new FormControl(null
      ),
    });

    if (this.virt) {
      this.form.patchValue({
                            '_id': this.virt._id,
                            'virtual_server_name': this.virt.virtual_server_name,
                            'machine_serial_number': this.virt.machine_serial_number,
                            'partition_name': this.virt.partition_name,
                            'partition_number': this.virt.partition_number,
                            'partition_type': this.virt.partition_type,
                            'mode': this.virt.mode,
                            'entitled_capacity': this.virt.entitled_capacity,
                            'shared_pool_id': this.virt.shared_pool_id,
                            'online_virtual_cpus': this.virt.online_virtual_cpus,
                            'maximum_physical_cpus_in_system': this.virt.maximum_physical_cpus_in_system,
                            'active_physical_cpus_in_system': this.virt.active_physical_cpus_in_system,
                            'shared_physical_cpus_in_system': this.virt.shared_physical_cpus_in_system,
                            'notes': this.virt.notes});
    }
  }

  setOVM() {
    this.form = new FormGroup({
      '_id': new FormControl(null),
      'virtual_server_name': new FormControl(null, {validators: [Validators.required]}),
      'uuid': new FormControl(null),
      'max_vcpus': new FormControl(null),
      'vcpus': new FormControl(null ),
      'cpu_affinity': new FormControl(null),
      'total_cpus': new FormControl(null),
      'live_migration': new FormControl(null),
      'ovm_high_availability': new FormControl(null),
      'notes': new FormControl(null),
      'dom0_max_vcpus': new FormControl(null),
      'dom0_cpu_affinity': new FormControl(null),
      'ovm_ha': new FormControl(null),
      'cpus': new FormControl(null),
      'physical_server_mapping': new FormControl(null),
      'total_threads': new FormControl(null),
      'threads_per_core': new FormControl(null),
      'licensable_cores': new FormControl(null),
      'same_pool_procs': new FormControl(null),
      'virtual_procs': new FormControl(null),
    });
    if (this.virt) {
      this.migrationSelected = this.virt.live_migration;
      this.availabilitySelected = this.virt.ovm_high_availability;
      this.form.patchValue({
                            'virtual_server_name': this.virt.virtual_server_name,
                            'uuid': this.virt.uuid,
                            'max_vcpus': this.virt.max_vcpus,
                            'vcpus': this.virt.vcpus,
                            'cpu_affinity': this.virt.cpu_affinity,
                            'total_cpus': this.virt.total_cpus,
                            'live_migration': this.virt.live_migration,
                            'ovm_high_availability': this.virt.ovm_high_availability,
                            'notes': this.virt.notes,
                            'dom0_max_vcpus': this.virt.dom0_max_vcpus,
                            'dom0_cpu_affinity': this.virt.dom0_cpu_affinity,
                            'ovm_ha': this.virt.ovm_ha,
                            'cpus': this.virt.cpus,
                            'physical_server_mapping': this.virt.physical_server_mapping,
                            'total_threads': this.virt.total_threads,
                            'threads_per_core': this.virt.threads_per_core,
                            'licensable_cores': this.virt.licensable_cores,
                            'same_pool_procs': this.virt.same_pool_procs,
                            'virtual_procs': this.virt.virtual_procs,
                          });
    }
  }

  setKVM() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'virtual_server_name': new FormControl(null, {validators: [Validators.required]
      }),
      'vcpus': new FormControl(null
      ),
      'cpu_affinity': new FormControl(null, {validators: [Validators.required]
      }),
      'total_cpus': new FormControl(null
      ),
      'pinned': new FormControl(null
      ),
    });
    if (this.virt) {
      this.pinnedSelected = this.virt.pinned;
      this.form.patchValue({
                            '_id': this.virt._id,
                            'virtual_server_name': this.virt.virtual_server_name,
                            'vcpus': this.virt.vcpus,
                            'cpu_affinity': this.virt.cpu_affinity,
                            'total_cpus': this.virt.total_cpus,
                            'pinned': this.virt.pinned});
    }
  }

  setXEN() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'virtual_server_name': new FormControl(null, {validators: [Validators.required]
      }),
      'cpu_affinity': new FormControl(null,
      ),
      'vcpus': new FormControl(null
      ),
      'dedicated_vcpus': new FormControl(null
      ),
      'notes': new FormControl(null
      ),
    });

    if (this.virt) {
      this.form.patchValue({
                            '_id': this.virt._id,
                            'virtual_server_name': this.virt.virtual_server_name,
                            'cpu_affinity': this.virt.cpu_affinity,
                            'vcpus': this.virt.vcpus,
                            'dedicated_vcpus': this.virt.vcpus,
                            'notes': this.virt.notes});
    }
  }

  setVMWare() {
    this.form = new FormGroup({
      '_id': new FormControl(null),
      'vm_host_name': new FormControl(null),
      'virtual_server_name': new FormControl(null),
      'vm_guest_host_name': new FormControl(null),
      'vm_guest_os': new FormControl(null),
      'vm_ip_address': new FormControl(null),
      'is_stand_alone': new FormControl(null),
      'data_center': new FormControl(null),
      'cluster': new FormControl(null),
      'full_name': new FormControl(null),
      'version': new FormControl(null),
      'power_state': new FormControl(null),
      'connection_state_datastores': new FormControl(null),
      'managed_by_server': new FormControl(null),
      'vcenter_server_name': new FormControl(null),
      'vendor': new FormControl(null),
      'esx_version': new FormControl(null),
      'connection_state': new FormControl(null),
      'datastores': new FormControl(null),
    });

    if (this.virt) {
      this.form.patchValue({
        ...this.virt,
        '_id': this.virt._id,
        vm_host_name: this.virt.vm_host_name,
        virtual_server_name: this.virt.virtual_server_name,
      });

      this.isStandalone = this.virt.is_standalone;
    }
  }


setSolarisOption() {
  const virt_name = this.form.value.virtual_server_name;
  const notes = this.form.value.notes;
  this.solarisOption = this.form.value.type_of_solaris_partitioning;

  this.form.reset();
  this.form.patchValue({'virtual_server_name': virt_name,
                        'notes': notes, 'type_of_solaris_partitioning': this.solarisOption});
}

toggleSwitch(event: boolean, switchName: string) {
  switch (switchName) {
    case 'isStandalone':
      this.isStandalone = event;
      break;
    case 'hasVpars':
      this.hasVpars = event;
      break;
    case 'intendedActive':
      this.intendedActive = event;
      break;
    case 'capped':
      this.capped = event;
      break;
  }

}

  add() {
    if (this.virtType === 'VMWare') {
      this.form.patchValue({is_stand_alone: this.isStandalone});
    }
    if (this.virtType === 'HP UX') {
      const active_processor_count: ActProcCount = {
                                                    number_of_sockets: this.form.value.number_of_sockets,
                                                    cores_per_socket: this.form.value.cores_per_socket,
                                                    logical_processors: this.form.value.logical_processors,
                                                    lcpu_attribute: this.form.value.lcpu_attribute
                                                  };
      const complex_information: ComplexInfo = {
                                                complex_name: this.form.value.complex_name,
                                                complex_serial_number: this.form.value.complex_serial_number,
                                                complex_product_order_number: this.form.value.complex_product_order_number,
                                                complex_id_number: this.form.value.complex_id_number
                                              };
      const core_usage_right_details: CoreUsageDets = {
                                                       total_core_usage_rights: this.form.value.total_core_usage_rights,
                                                       committed_core_usage_rights: this.form.value.committed_core_usage_rights,
                                                       available_core_usage_rights: this.form.value.available_core_usage_rights,
                                                       number_of_partitions_present: this.form.value.number_of_partitions_present
                                                      };
      const npartition_resource_summary: NPartitionSumm = {
                                                          npar_id: this.form.value.npar_id,
                                                          npar_name: this.form.value.npar_name,
                                                          npar_state: this.form.value.npar_state,
                                                          npar_has_vpars: this.hasVpars,
                                                          npar_intended_active: this.intendedActive,
                                                          npar_total_cores: this.form.value.npar_total_cores,
                                                          npar_actual_active: this.form.value.npar_actual_active,
                                                          npar_assigned_cores: this.form.value.npar_assigned_cores
                                                        };
      const vpartition_resource_summary: VPartitionSumm = {
                                                          vpar_id: this.form.value.vpar_id,
                                                          vpar_name: this.form.value.vpar_name,
                                                          vpar_state: this.form.value.vpar_state,
                                                          vpar_assigned_cores: this.form.value.vpar_assigned_cores,
                                                          vpar_actual_active: this.form.value.vpar_actual_active,
                                                          vpar_committed_rights: this.form.value.vpar_committed_rights
                                                        };
      const virtual_partition_resource_summary: VirtualPartSumm = {
                                                                  capped: this.capped,
                                                                  cpu_min: this.form.value.cpu_min,
                                                                  cpu_max: this.form.value.cpu_max,
                                                                  licensable_cores: this.form.value.licensable_cores,
                                                                };
      const secure_resource_partitions: SecureResourcepartition = {
        cpu_entitlements_fss: this.form.value.cpu_entitlements_fss,
        cpu_entitlements_pset: this.form.value.cpu_entitlements_pset,
        srp_name: this.form.value.srp_name,
        prm_id: this.form.value.prm_id,
        pset: this.form.value.pset,
        licensables_cores: this.form.value.licensables_cores,
        notes: this.form.value.notes
      };


      const data: HPUX = {
                          _id: this.form.value._id,
                          virtual_server_name: this.form.value.virtual_server_name,
                          active_processor_count: active_processor_count,
                          complex_information: complex_information,
                          core_usage_right_details: core_usage_right_details,
                          npartition_resource_summary: npartition_resource_summary,
                          vpartition_resource_summary: vpartition_resource_summary,
                          virtual_partition_resource_summary: virtual_partition_resource_summary,
                          secure_resource_partitions: secure_resource_partitions
                        };

      this.dialogRef.close({data: data});
    } else {
      this.dialogRef.close({data: this.form.value});
    }

  }

}
