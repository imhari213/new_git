// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

// services
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-decommission-check-dialog',
  templateUrl: './decommission-check-dialog.component.html',
  styleUrls: ['./decommission-check-dialog.component.css'],
  providers: [ThemeService]
})

export class DecommissionCheckDialogComponent implements OnInit {

  constructor(private themeService: ThemeService, private dialogRef: MatDialogRef<DecommissionCheckDialogComponent>,
     @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
  }

  confirmation(conf) {
    this.dialogRef.close(conf);
  }
}
