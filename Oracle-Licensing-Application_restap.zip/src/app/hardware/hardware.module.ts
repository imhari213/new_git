// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

// components
import { LicensesAllocatedComponent } from './licenses-allocated-dialog/licenses-allocated-dialog.component';
import { HardwareListComponent } from './hardware-list/hardware-list.component';
import { HardwareCreateComponent } from './hardware-create/hardware-create.component';
import { VirtualisationComponent } from './virtualisation-dialog/virtualisation-dialog.component';
import { ServerDetailsBottomSheetComponent } from './server-details-bottomsheet/server-details-bottom-sheet.component';
import { CloudComponent } from './cloud-dialog/cloud-dialog.component';
import { CheckAddLicencesDialogComponent } from './check-add-licences-dialog/check-add-licences-dialog.component';
import { DecommissionCheckDialogComponent } from './decommission-check-dialog/decommission-check-dialog.component';

@NgModule({
  declarations: [
    HardwareCreateComponent,
    HardwareListComponent,
    LicensesAllocatedComponent,
    VirtualisationComponent,
    ServerDetailsBottomSheetComponent,
    CloudComponent,
    CheckAddLicencesDialogComponent,
    DecommissionCheckDialogComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule
  ],
  entryComponents: [
    LicensesAllocatedComponent,
    VirtualisationComponent,
    ServerDetailsBottomSheetComponent,
    CloudComponent,
    CheckAddLicencesDialogComponent,
    DecommissionCheckDialogComponent
  ]
})

export class HardwareModule {}
