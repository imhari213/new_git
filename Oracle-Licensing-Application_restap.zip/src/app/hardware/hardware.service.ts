// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

// models
import { Hardware, Vcenter } from './hardware.model';

// services
import { AuditService } from '../audit/audit.service';

// misc
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

const BACKEND_URL = environment.apiUrl + '/hardware/';

@Injectable({providedIn: 'root'})

export class HwService {

  constructor(private http: HttpClient, private auditService: AuditService) {}

  private hardwares: Hardware[] = [];
  private hardwareCount;
  private hardwaresUpdated = new Subject<{hardwares: Hardware[], hardwareCount: Number}>();

  getServerNameList(compId) {
    return this.http.get<{message: string, serverNameList: any}>(BACKEND_URL + 'serverNameList/' + compId);
  }

  getHardwareUpdateListener() {
    return this.hardwaresUpdated.asObservable();
  }

  getHardwareName(serverId) {
    return this.http.get<{serverName: string, message: string}>(BACKEND_URL + 'hardwareByServerName/' + serverId);
  }

  getHardwares(hardwarePerPage: number, currentPage: number) {
    const queryParams = `?pagesize=${hardwarePerPage}&page=${currentPage}`;
    this.http.get<{message: string, hardwares: any, maxHardwares: number}>(BACKEND_URL + '/' + queryParams)
    .pipe(map((hardwareData) => {
      return { hardwares: hardwareData.hardwares.map(hardwares => {
        return hardwares;
      }), maxHardwares: hardwareData.maxHardwares};
    })).subscribe((transformedData) => {
      this.hardwares = transformedData.hardwares,
      this.hardwareCount = transformedData.maxHardwares;
      this.hardwaresUpdated.next({hardwares: [...this.hardwares], hardwareCount: this.hardwareCount});
    });
  }

  searchHardwares(
    companyId: string, contractId: string, clusterId: string, searchParam: string, hwPerPage: number, currentPage: number,
    sortType: string, pageChosen: string, compareHardwareId: string
  ) {
      const queryParams =
      `?pagesize=${hwPerPage}&page=${currentPage}&company=${companyId}&contract=${contractId}&cluster=${clusterId}&sort=${sortType}&pageChosen=${pageChosen}&compareHardwareId=${compareHardwareId}`;
      this.http.get<{message: string, hardwares: any, maxHardwares: number}>
      (BACKEND_URL + 'search/' + searchParam + '/' + queryParams)
      .pipe(map((hardwareData) => {
        return { hardwares: hardwareData.hardwares.map(hardware => {
          return {
            ...hardware,
            server_name: hardware.server_name,
          };
        }), maxHardwares: hardwareData.maxHardwares
      };
      }))
      .subscribe((transformedHardwareData) => {
        this.hardwares = transformedHardwareData.hardwares;
        this.hardwareCount = transformedHardwareData.maxHardwares;
        this.hardwaresUpdated.next({hardwares: [...this.hardwares], hardwareCount: this.hardwareCount});
      });
  }

  updateHardware(id: string, value: any) {
    let hardwareData: Hardware | FormData;
    hardwareData = new FormData();
    hardwareData = {
      ...value,
      id: id,
      company: value.company
    };
    return this.http.put<{message: string, hardware: any}>(BACKEND_URL + 'update/' + id, hardwareData);
  }

  getHardware(id: string) {
    return this.http.get<Hardware>(BACKEND_URL + id);
  }

  deleteHardware(hardwareId: String) {
    return this.http.delete(BACKEND_URL + hardwareId);
  }

  quicksave(Value: any) {
    return this.http.post<{messsage: string, hardware: Hardware, id: string}>(BACKEND_URL, Value);
  }

  addHw(value: any) {
    return this.http.post<{messsage: string, hardware: Hardware}>(BACKEND_URL, value);
  }

  migrateLicOnHW(newLicense: any, oldLicense: any, newContractId: string) {
    const objectParse = {newLicense: newLicense, oldLicense: oldLicense, newContract: newContractId};
    return this.http.put<{message: string}>(BACKEND_URL + 'update_allocations/', objectParse);
  }

}
