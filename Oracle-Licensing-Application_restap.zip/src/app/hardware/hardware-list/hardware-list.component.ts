// angular
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PageEvent, MatTable, MatDialog, MatTableDataSource } from '@angular/material';

// models
import { Company } from '../../companies/company.model';
import { Contract } from '../../contracts/contract.model';
import { Hardware, Vcenter } from '../hardware.model';
import { VCenter } from 'src/app/vcenter/vcenter.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { CompanyService } from 'src/app/companies/companies.service';
import { ContractService } from 'src/app/contracts/contracts.service';
import { HwService } from '../hardware.service';
import { VCenterService } from 'src/app/vcenter/vcenter.service';
import { OptionsService } from '../../options.service';
import { AuditService } from 'src/app/audit/audit.service';

// components
import { LicensesAllocatedComponent } from '../licenses-allocated-dialog/licenses-allocated-dialog.component';
import { VirtualisationComponent } from '../virtualisation-dialog/virtualisation-dialog.component';
import { CloudComponent } from '../cloud-dialog/cloud-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { DecommissionCheckDialogComponent } from '../decommission-check-dialog/decommission-check-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-hardware-list',
  templateUrl: './hardware-list.component.html',
  styleUrls: ['./hardware-list.component.css'],
})

export class HardwareListComponent implements OnInit, OnDestroy {

  userIsAuthenticated: boolean;
  userRole = 'read';
  isLoading = false;

  hardwaresPerPage = 20;
  currentPage = 1;
  pageSizeOptions = [20, 50, 100];
  sortType;

  hardwareCount = 0;
  hardwares: Hardware[];
  companies: Company[];
  contracts: Contract[];
  contractsForAllocation: any;
  currentHardware: Hardware;
  licensesAllocated = <any>[];
  searchParam;

  vcenters: Vcenter[];
  clusters = <any>[];

  currentHardwareCompany;

  virtualisationType;
  virtList = <any>[];
  virtualisationSource;
  tableArray: string[];
  virtualisationColumns = <any>[];

  cloudType;

  contractId;
  companyId;
  clusterId;
  contractName;

  checkedHeader;

  authStatusSub: Subscription;
  hardwareSub: Subscription;
  companySub: Subscription;
  contractSub: Subscription;
  vcenterSub: Subscription;
  headerOptionSub: Subscription;

  @ViewChild(MatTable) table: MatTable<any>;

  licenseColumns: String[] = ['virtualisation', 'contract', 'product', 'metric', 'number', 'restricted', 'edit'];
  licenseDataSource;
  pageChosen = null;
  changePageSize = false;
  compareHardwareId = null;

  completeHardwareColumns = [
    {name: 'Cluster', modelName: 'cluster_id'},
    {name: 'Company', modelName: 'company'},
    {name: 'Server Name', modelName: 'server_name'},
    {name: 'Server Model', modelName: 'server_model'},
    {name: 'Purchase Date', modelName: 'server_purchase_date'},
    {name: 'Licences Allocated', modelName: 'license_allocated_to_server'},
    {name: 'Operating System', modelName: 'operating_system'},
    {name: 'Processor Model', modelName: 'processor_model'},
    {name: 'Processors', modelName: 'processors'},
    {name: 'Cores per Processor', modelName: 'cores_per_processor'},
    {name: 'Total Physical Cores', modelName: 'total_physical_cores'},
    {name: 'Cores Enabled', modelName: 'cores_enabled'},
    {name: 'Threads per Core', modelName: 'threads_per_core'},
    {name: 'Multi Core/Multi Chip Model', modelName: 'multi_core_chip_or_multi_chip_model'},
    {name: 'Processor Speed', modelName: 'processor_speed'},
    {name: 'Server Location', modelName: 'server_location'},
    {name: 'Commission Date', modelName: 'commission_date'},
    {name: 'Decommission Date', modelName: 'decommission_date'},
    {name: 'Hardware Refresh Term', modelName: 'hardware_refresh_term_or_date'},
  ];

  currentHardwareColumns = [
    {name: 'Server Name', modelName: 'server_name'},
    {name: 'Server Model', modelName: 'server_model'},
    {name: 'Purchase Date', modelName: 'server_purchase_date'},
    {name: 'Licences Allocated', modelName: 'license_allocated_to_server'},
  ];

  constructor(private authService: AuthService, private hardwareService: HwService, private router: Router,
              private companyService: CompanyService, private contractService: ContractService, private dialog: MatDialog,
              private route: ActivatedRoute, private vcenterService: VCenterService, private auditService: AuditService,
              private optionsService: OptionsService) {}

  ngOnInit() {
    this.isLoading = true;
    this.pageChosen = 'FIRST';
    this.getAuth();

    if (localStorage.getItem('compId') !== 'null') { this.companyId = localStorage.getItem('compId'); }
    if (localStorage.getItem('contractId') && localStorage.getItem('contractId') !== 'null') {
       this.contractId = localStorage.getItem('contractId'); this.getContractName();
      }
    if (localStorage.getItem('clusterId') !== 'null') { this.clusterId = localStorage.getItem('clusterId'); }

    (async () => { this.getCompanies(); })();
    (async () => { this.getHardwares(); })();
    // this.getCompanies();
    // this.getHardwares();
    this.checkedHeader = this.optionsService.getHeaderOption();
    this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
    });

  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }

    if (this.userRole === 'read') {
      this.licenseColumns = ['virtualisation', 'contract', 'product', 'metric', 'number', 'restricted'];
      this.virtualisationColumns = ['Vcenter Server Name', 'Vcenter Version'];
    }

  }

  getHardwares() {
    this.hardwareService.searchHardwares(
      this.companyId, this.contractId, this.clusterId,
      this.searchParam, this.hardwaresPerPage, this.currentPage, this.sortType,
      this.pageChosen, this.compareHardwareId
    );
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
    .subscribe((hardwareData: {hardwares: Hardware[]; hardwareCount: number}) => {
      this.hardwareCount = hardwareData.hardwareCount;
      this.hardwares = hardwareData.hardwares;
      this.changePageSize = false;
      this.pageChosen = null;
      this.compareHardwareId = null;
      this.isLoading = false;
    });
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
        this.companies = companyData.companies;
      });
  }

  getContracts(hardware) {
    this.contractService.searchValidContacts(hardware.company).subscribe(result => {
      this.contractsForAllocation = result.contracts;

      // To ensure that licenses allocated are attached to existing contracts.
      // probably better to update all relevent hardware when deleting contract.
      const id_list = [];
      result.contracts.forEach(con => id_list.push(con._id));
      const checked_lics = hardware.license_allocated_to_server.filter(lic => {
        if (id_list.includes(lic.contract_linked)) { return true; } else { return false; }
      });
      this.currentHardware.license_allocated_to_server = checked_lics;
      this.hardwareService.updateHardware(hardware._id, this.currentHardware).subscribe(() => {
        this.hardwareService.getHardware(hardware._id).subscribe(hw => {
          this.currentHardware = hw;
          this.licensesAllocated = hw.license_allocated_to_server;
          this.licenseDataSource = new MatTableDataSource(this.licensesAllocated);
        });
      });
    });
    /*
    this.contractService.searchContract(compId, null, null, null);
    this.contractSub = this.contractService.getAllContractsUpdateListener()
    .subscribe((contractData: {contracts: Contract[]; contractCount: number, hardwareCount: any}) => {
      this.contracts = contractData.contracts.filter(con => !con.contract_terminated);
    });*/
  }

  getContractName() {
    this.contractService.getContract(this.contractId).subscribe(returnData => {
      this.contractName = returnData.contract.customer_support_identifier;
    });
  }

  getClusters(company) {
    if (!company) { company = this.currentHardware.company; }
    this.vcenterService.getVCenters('company', company, null, null);
    this.vcenterSub = this.vcenterService.getVCenterUpdateListener()
    .subscribe((vcenterData: {vcenters: VCenter[], vcenterCount: Number}) => {
      vcenterData.vcenters.forEach(vc => {
        vc.dataCenters.forEach(dc => {
          this.clusters = this.clusters.concat(dc.clusters);
        });
      });
    });
  }

  setSortType(type) {
    this.pageChosen = 'FIRST';
    this.sortType = type;
    this.getHardwares();
  }


  ngOnDestroy() {
    localStorage.removeItem('clusterId');
    this.authStatusSub.unsubscribe();
    this.hardwareSub.unsubscribe();
    try {
      this.companySub.unsubscribe();
    } catch {}
    try {
      this.contractSub.unsubscribe();
    } catch {}

  }

  selectName(hardware) {
    if (hardware.virtualisation_name) { return hardware.virtualisation_name; } else { return hardware.server_name; }
  }

  getColumnsClicked(option, event) {
    if (event === true) {
      this.currentHardwareColumns.push(option);
    } else {
      const index = this.currentHardwareColumns.indexOf(option);
      this.currentHardwareColumns.splice(index, 1);
    }
  }

  getCheckedBoolean(column) {
    return this.currentHardwareColumns.find(object => object['name'] === column.name);
   }

  onExpand(hardware) {
    this.getContracts(hardware);
    this.getClusters(hardware.company);

    if (hardware.decommission_date) {
      this.licenseColumns = ['virtualisation', 'contract', 'product', 'metric', 'number', 'restricted'];
    } else {
      this.licenseColumns = ['virtualisation', 'contract', 'product', 'metric', 'number', 'restricted', 'edit'];
    }

    this.currentHardware = hardware;
    this.currentHardwareCompany = this.getCompanyName(hardware.company);
    // this.licensesAllocated = hardware.license_allocated_to_server;
    // this.licenseDataSource = new MatTableDataSource(this.licensesAllocated);

    if (hardware.ibm_virt && hardware.ibm_virt.length > 0) {
      this.virtualisationType = 'IBM';
      this.virtList = hardware.ibm_virt;
      this.tableArray = ['virtual_server_name', 'machine_serial_number', 'partition_name', 'partition_type', 'mode'];
      this.virtualisationColumns = ['Virtual Server Name', 'Machine Serial Number', 'Partition Name', 'Partition Type', 'Mode', 'edit'];
    } else if (hardware.ovm_virt && hardware.ovm_virt.length > 0) {
      this.virtualisationType = 'OVM';
      this.virtList = hardware.ovm_virt;
      this.tableArray = ['virtual_server_name', 'uuid', 'max_vcpus', 'vcpus', 'cpu_affinity', 'total_cpus'];
      this.virtualisationColumns = ['Virtual Server Name', 'UUID', 'Max VCPUs', 'VCPUs', 'CPU Affinnity', 'Total CPUs', 'edit'];
    } else if (hardware.kvm_virt && hardware.kvm_virt.length > 0) {
      this.virtualisationType = 'KVM';
      this.virtList = hardware.kvm_virt;
      this.tableArray = ['virtual_server_name', 'vcpus', 'cpu_affinity', 'total_cpus', 'pinned'];
      this.virtualisationColumns = ['Virtual Server Name', 'VCPUs', 'CPU Affinity', 'Total CPUs', 'Pinned', 'edit'];
    } else if (hardware.xen_virt && hardware.xen_virt.length > 0) {
      this.virtualisationType = 'XEN';
      this.virtList = hardware.xen_virt;
      this.tableArray = ['virtual_server_name', 'cpu_affinity', 'vcpus', 'dedicated_vcpus', 'notes'];
      this.virtualisationColumns = ['Virtual Server Name', 'CPU Affinity', 'VCPUs', 'Dedicated VCPUs', 'Notes', 'edit'];
    } else if (hardware.solaris_virt && hardware.solaris_virt.length > 0 ) {
      this.virtualisationType = 'Solaris';
      this.virtList = hardware.solaris_virt;
      this.tableArray = ['virtual_server_name', 'type_of_solaris_partitioning', 'notes'];
      this.virtualisationColumns = ['Virtual Server Name', 'Type of Partitioning', 'Notes', 'edit'];
    } else if (hardware.vmware_virt && hardware.vmware_virt.length > 0 ) {
      this.virtualisationType = 'VMWare';
      this.virtList = hardware.vmware_virt;
      this.tableArray = ['virtual_server_name', 'vm_host_name', 'vm_guest_host_name', 'vm_guest_os', 'vm_ip_address'];
      this.virtualisationColumns = ['Virtual Server Name', 'Host Name', 'Guest Host', 'Guest OS', 'IP Address', 'edit'];
    } else if (hardware.hp_ux_virt && hardware.hp_ux_virt.length > 0) {
      this.virtualisationType = 'HP UX';
      this.virtList = hardware.hp_ux_virt;
      this.tableArray = ['virtual_server_name'];
      this.virtualisationColumns = ['Virtual Server Name', 'edit'];
    }  else if (hardware.aws_cloud && hardware.aws_cloud.length > 0 ) {
      this.cloudType = 'AWS';
      this.virtList = hardware.aws_cloud;
      this.tableArray = ['virtual_server_name', 'description', 'instance_type', 'vcpus', 'hyperthreaded', 'license_method', 'edit'];
      this.virtualisationColumns = ['Virtual Server Name', 'Description', 'Instance Type',
                                    'VCPUs', 'Hyperthreaded', 'License Method', 'edit'];
    } else if (hardware.azure_cloud && hardware.azure_cloud.length > 0 ) {
      this.cloudType = 'Azure';
      this.virtList = hardware.azure_cloud;
      this.tableArray = ['virtual_server_name', 'description', 'instance_type', 'vcpus', 'hyperthreaded', 'license_method'];
      this.virtualisationColumns = ['Virtual Server Name', 'Description', 'Instance Type',
                                    'VCPUs', 'Hyperthreaded', 'License Method', 'edit'];
    } else if (hardware.oracle_cloud && hardware.oracle_cloud.length > 0 ) {
      this.cloudType = 'Oracle Cloud';
      this.virtList = hardware.oracle_cloud;
      this.tableArray = ['virtual_server_name', 'description', 'instance_type', 'vcpus', 'hyperthreaded', 'license_method'];
      this.virtualisationColumns = ['Virtual Server Name', 'Description', 'Instance Type',
                                    'VCPUs', 'Hyperthreaded', 'License Method', 'edit'];
    } else if (hardware.di_cloud && hardware.di_cloud.length > 0 ) {
      this.cloudType = 'DI Cloud';
      this.virtList = hardware.di_cloud;
      this.tableArray = ['virtual_server_name', 'description', 'instance_type', 'vcpus', 'hyperthreaded', 'license_method'];
      this.virtualisationColumns = ['Virtual Server Name', 'Description', 'Instance Type',
                                    'VCPUs', 'Hyperthreaded', 'License Method', 'edit'];
    } else {
      this.virtualisationType = null;
      this.virtList = undefined;
      this.tableArray = [];
    }

    if (!((this.userRole === 'admin') || (this.userRole === 'master'))) {
      this.virtualisationColumns = this.virtualisationColumns.slice(0, -1);
    }

    this.virtualisationSource = new MatTableDataSource(this.virtList);

  }

  getElement(element, index) {
    return element[this.tableArray[index]];
  }

  getClusterName(clusterId) {
    let clusterName = clusterId;
    try { clusterName = this.clusters.find(cluster => cluster._id === clusterId).cluster; } catch {}
    return clusterName;
  }

  sortSolarisObj(data) {
    const newSolObj = {
      _id: data._id,
      virtual_server_name: data.virtual_server_name,
      type_of_solaris_partitioning: data.type_of_solaris_partitioning,
      notes: data.notes,
      pool_type: null,
      local_zone_type: null,
      ovm_for_sparc_type: null
    };

    if (data.type_of_solaris_partitioning === 'Pool') {
      newSolObj.pool_type = {
        pool_name: data.pool_name,
        pset_value_for_zone_from_physical: data.pset_value_for_zone_from_physical,
        pset_value_for_zone_from_virtual: data.pset_value_for_zone_from_virtual,
        total_count_core_id: data.total_count_core_id
      };
    }

    if (data.type_of_solaris_partitioning === 'Local Zone') {
      newSolObj.local_zone_type = {
        dedicated_cpu: data.dedicated_cpu,
        capped_cpus: data.capped_cpus,
        ncpus: data.ncpus,
      };
    }

    if (data.type_of_solaris_partitioning === 'OVM for Sparc') {
      newSolObj.ovm_for_sparc_type = {
        constraint: data.constraint,
        whole_core: data.whole_core,
        max_cores: data.max_cores,
        pinned: data.pinned,
      };
    }
    return newSolObj;
  }

  addVirtData(virtId) {

    let current_virt;

    if (virtId) { current_virt = this.virtList.find( virt => virt._id === virtId ); }

    const dialogRef = this.dialog.open(VirtualisationComponent, {
      disableClose: true,
      width: '50%',
      data: {
        type: this.virtualisationType,
        virt: current_virt
      }
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        let data = updateData.data;

        if (this.virtualisationType === 'Solaris') {
          data = this.sortSolarisObj(data);
        }


        if (current_virt) {
          const index = this.virtList.indexOf(current_virt);
          data._id = current_virt._id;
          this.virtList[index] = data;
        } else {
          this.virtList.push(data);
        }

        if (this.virtualisationType === 'Solaris') { this.currentHardware.solaris_virt = this.virtList; } else
        if (this.virtualisationType === 'IBM') { this.currentHardware.ibm_virt = this.virtList; } else
        if (this.virtualisationType === 'OVM') { this.currentHardware.ovm_virt = this.virtList; } else
        if (this.virtualisationType === 'KVM') { this.currentHardware.kvm_virt = this.virtList; } else
        if (this.virtualisationType === 'XEN') { this.currentHardware.xen_virt = this.virtList; } else
        if (this.virtualisationType === 'VMWare') { this.currentHardware.vmware_virt = this.virtList; }

        this.hardwareService.updateHardware(this.currentHardware._id, this.currentHardware).subscribe(() => {
          this.hardwareService.getHardware(this.currentHardware._id).subscribe(hw => {
            this.onExpand(hw);
          });
        });
      } else {
        console.log('closed');
      }
    });

  }

  addCloudData(cloudId) {
    let currentVirt;
    let index;
    if (cloudId) { currentVirt = this.virtList.find(virt => virt._id === cloudId); index = this.virtList.indexOf(currentVirt); }

    const dialogRef = this.dialog.open(CloudComponent, {
      disableClose: true,
      width: '50%',
      data: {type: this.cloudType, cloud: currentVirt}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        const data = updateData;
        if (currentVirt) {
          data._id = currentVirt._id;
          this.virtList[index] = data;
        } else {
          this.virtList.push(data);
        }

        if (this.cloudType === 'AWS') { this.currentHardware.aws_cloud = this.virtList; }
        if (this.cloudType === 'Azure') { this.currentHardware.azure_cloud = this.virtList; }
        if (this.cloudType === 'Oracle Cloud') { this.currentHardware.oracle_cloud = this.virtList; }
        if (this.cloudType === 'DI Cloud') { this.currentHardware.di_cloud = this.virtList; }

        this.hardwareService.updateHardware(this.currentHardware._id, this.currentHardware).subscribe(() => {
          this.hardwareService.getHardware(this.currentHardware._id).subscribe(hw => {
            this.onExpand(hw);
          });
        });
      } else {
        console.log('closed');
      }
    });
  }

  deleteVirtData(element) {

  const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
    disableClose: true,
    width: '50%',
    data: { pageViewName: 'virtualisation', name: element.virtual_server_name }
  });


  dialogRef.afterClosed().subscribe(confirmantion => {
    if (confirmantion) {
      const index = this.virtList.indexOf(element);
      this.virtList.splice(index, 1);

      if (this.virtualisationType === 'Solaris') { this.currentHardware.solaris_virt = this.virtList; } else
      if (this.virtualisationType === 'IBM') { this.currentHardware.ibm_virt = this.virtList; } else
      if (this.virtualisationType === 'OVM') { this.currentHardware.ovm_virt = this.virtList; } else
      if (this.virtualisationType === 'KVM') { this.currentHardware.kvm_virt = this.virtList; } else
      if (this.virtualisationType === 'XEN') { this.currentHardware.xen_virt = this.virtList; } else
      if (this.virtualisationType === 'VMWare') { this.currentHardware.vmware_virt = this.virtList; }

      this.hardwareService.updateHardware(this.currentHardware._id, this.currentHardware).subscribe(() => {
        this.hardwareService.getHardware(this.currentHardware._id).subscribe(hw => {
          this.onExpand(hw);
        });
      });
    }
  });


  }

  getVirtLinked(virtId) {
    let virtName = virtId;
    try {
      if (virtId === this.currentHardware._id) {
        virtName = this.currentHardware.server_name;
      } else {
        virtName = this.virtList.find(virt => virt._id === virtId).virtual_server_name;
      }
    } catch {

    }


    return virtName;
  }

  getContractLinked(contractId, index) {
    let contractName;
    try {
      contractName = this.contractsForAllocation.find(con => con._id === contractId).customer_support_identifier;
    } catch {
      contractName = contractId;
      this.licensesAllocated = this.licensesAllocated.splice(index, 1);
      // this.licenseDataSource = new MatTableDataSource(this.licensesAllocated);
    }
    return contractName;
  }

  getLicenseLinked(element) {
    let product;
    try {
      const contract = this.contractsForAllocation.find(con => con._id === element.contract_linked);
      const license = contract.oracle_licenses.find(lic => lic._id === element.product_licensed);
      product = license.product_name;
    } catch {
      product = 'Unknown';
    }

    return product;
  }

  getCompanyName(compId) {
    const company = this.companies.find(comp => compId === comp._id);
    if (company) {
      return company.company_name;
    } else {
      return '';
    }
  }

  openLicenseDialog(licenseId) {
    let licIndex;
    let license;

    if (licenseId) {
      for (let i = 0; i < this.currentHardware.license_allocated_to_server.length; ++i) {
        if (this.currentHardware.license_allocated_to_server[i]._id === licenseId) {
          licIndex = i;
          license = this.currentHardware.license_allocated_to_server[i];
        }
      }
    }

    let dialogRef;
    // let contracts;

    if (license) {
      dialogRef = this.dialog.open(LicensesAllocatedComponent, {
        disableClose: true,
        width: '50%',
        data: {contracts: this.contractsForAllocation, hardware: this.currentHardware, license: license,
          virtList: this.virtList, virtType: this.virtualisationType}
      });
    } else {
      dialogRef = this.dialog.open(LicensesAllocatedComponent, {
        disableClose: true,
        width: '50%',
        data: {contracts: this.contractsForAllocation, hardware: this.currentHardware,
          virtList: this.virtList, virtType: this.virtualisationType}
      });
    }


    dialogRef.afterClosed().subscribe( updateData => {
      if (updateData) {

        if (license) {
          this.licensesAllocated[licIndex] = updateData.data;
        } else {
          this.licensesAllocated.push(updateData.data);
        }

        this.currentHardware.license_allocated_to_server = this.licensesAllocated;
        this.hardwareService.updateHardware(this.currentHardware._id, this.currentHardware).subscribe(() => {
          this.hardwareService.getHardware(this.currentHardware._id).subscribe(hw => {
            this.currentHardware = hw;
            this.licensesAllocated = this.currentHardware.license_allocated_to_server;
            this.licenseDataSource = new MatTableDataSource(this.licensesAllocated);
          });

        });

        let valueDiff = 0;
        if (license) { valueDiff = license.number_of_licenses_in_use; }

        const relatedContract = this.contractsForAllocation.find(con => con._id === updateData.data.contract_linked );
        const relatedLicense = relatedContract.oracle_licenses.find(lic => lic._id === updateData.data.product_licensed);
        relatedLicense.allocated = (relatedLicense.allocated + updateData.data.number_of_licenses_in_use - valueDiff);
        relatedLicense.allowed = (relatedLicense.allowed - updateData.data.number_of_licenses_in_use + valueDiff);

        this.contractService.updateContract(relatedContract._id, relatedContract).subscribe(data => {
          this.getContracts(data.contract.end_user);
        });
      } else {
        console.log('closed');
      }
    });

  }

  deleteLicenseFromHardware(licId) {
    let license;
    const updatedLicenses = <any>[];

    for (let i = 0; i < this.licensesAllocated.length; ++i) {
      if (this.licensesAllocated[i]._id === licId) {
        license = this.licensesAllocated[i];
      } else {
        updatedLicenses.push(this.licensesAllocated[i]);
      }
    }

    const contract = this.contractsForAllocation.find(con => con._id === license.contract_linked);
    const oracleLic = contract.oracle_licenses;
    let oracleLinked: any = oracleLic.find(lic => lic._id === license.product_licensed);

    if (!oracleLinked) { oracleLinked = {product_name: license.product_licensed}; }

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'licence', name: oracleLinked.product_name.customer_support_identifier }
    });

    dialogRef.afterClosed().subscribe( confirmation => {
      if (confirmation) {


        oracleLinked.allocated -= license.number_of_licenses_in_use;
        oracleLinked.allowed += license.number_of_licenses_in_use;

        this.currentHardware.license_allocated_to_server = updatedLicenses;

        this.hardwareService.updateHardware(this.currentHardware._id, this.currentHardware).subscribe(() => {
          this.hardwareService.getHardware(this.currentHardware._id).subscribe(hw => {
            this.currentHardware = hw;
            this.licensesAllocated = this.currentHardware.license_allocated_to_server;
            this.licenseDataSource = new MatTableDataSource(this.licensesAllocated);
          });

        });

        this.contractService.updateContract(contract._id, contract);
      }
    });

  }

  deleteHardware(event, hardware) {

    event.stopPropagation();

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'hardware', name: hardware.server_name }
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.hardwareService.deleteHardware(hardware._id).subscribe(() => {
          this.getHardwares();
          this.getContracts(hardware.company);
        });
      }
    });
  }


  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    this.hardwaresPerPage = pageData.pageSize;
    const numOfPages = Math.ceil(this.hardwareCount / this.hardwaresPerPage);
    if (pageData.pageIndex + 1 === numOfPages) {
      this.pageChosen = 'LAST';
    } else if (pageData.pageIndex > pageData.previousPageIndex) {
      this.pageChosen = 'NEXT';
      this.compareHardwareId = this.hardwares[this.hardwares.length - 1]._id;
    } else if (pageData.pageIndex === 0) {
      this.pageChosen = 'FIRST';
    } else {
      this.pageChosen = 'PREVIOUS';
      this.compareHardwareId = this.hardwares[0]._id;
    }

    if (pageData.pageSize !== this.hardwaresPerPage) {
      this.hardwaresPerPage = pageData.pageSize;
      this.changePageSize = true;
    }

    this.getHardwares();
  }

  decomissionHardware(hardware: any, event: Event) {
    this.getContracts(hardware.company);
    event.stopPropagation();
    const dialogRef = this.dialog.open(DecommissionCheckDialogComponent, {
      width: '50%',
      data: {hardwareName: hardware.server_name}
    });
    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation === 'Yes') {
        hardware.license_allocated_to_server.forEach(lic => {
          try {
            const contractLinked = this.contracts.find(con => con._id === lic.contract_linked);
            const oracleLicense = contractLinked.oracle_licenses.find(olic => olic._id === lic.product_licensed);
            oracleLicense.allocated -= lic.number_of_licenses_in_use;
            oracleLicense.allowed += lic.number_of_licenses_in_use;
            this.contractService.updateContract(contractLinked._id, contractLinked);
          } catch (error) {}

        });
        for (let i = 0; i < hardware.license_allocated_to_server.length; ++i) {
          hardware.license_allocated_to_server[i].number_of_licenses_in_use = 0;
        }
        hardware.decommission_date = new Date();
        hardware.license_allocated_to_server = [];
        this.hardwareService.updateHardware(hardware._id, hardware).subscribe(returnData => {
          this.auditService.addAudit('hardware', hardware._id, 'decommission', hardware.server_name, null, null, null);
          this.onExpand(hardware);
        });
      }
    });

  }

  addHardware() {
    if (this.companyId) {
      this.router.navigate(['/add-hardware/' + this.companyId]);
    } else {
      this.router.navigate(['/add-hardware']);
    }
  }

  backToCompanies() {
    localStorage.removeItem('contractId');
    localStorage.removeItem('compId');
    localStorage.removeItem('hardwareId');

    if (this.companyId) {
      const companyName = this.companies.find(comp => comp._id === this.companyId).company_name;
      this.router.navigate(['/company-details/' + companyName]);
    } else {
      this.router.navigate(['/list-company/']);
    }
  }

  backToContracts() {
    this.router.navigate(['/list-contract']);
  }

  databasesByHardware(hardwareId) {
    localStorage.setItem('hardwareId', hardwareId);
    this.router.navigate(['/list-database/']);
  }

  middleswaresByHardware(hwCompId) {
    localStorage.setItem('compId', hwCompId);
    this.router.navigate(['/list-middleware/']);
  }

  onSearch(search: string) {
    if (search === '' ) { this.searchParam = undefined; } else {this.searchParam = search; }
    this.getHardwares();
  }

  splitString(string) {
    if (string) {
      string = string.substring(0, 15);
    } else {
      string = '';
    }

    return string;
  }

  stringLength(string: string) {
    if (string === null) {
      return;
    }
    if (string.length < 15) {
      return false;
    } else {
      return true;
    }
  }

}
