export interface Licenses {
  _id: string;
  virtualisation_linked: string;
  product_licensed: string;
  license_metric_allocated: string;
  number_of_licenses_in_use: number;
  contract_linked: string;
  restricted_use: string;
}

export interface IbmLpar {
  _id: string;
  virtual_server_name: string;
  machine_serial_number: string;
  partition_name: string;
  partition_number: string;
  partition_type: string;
  mode: string;
  entitled_capacity: string;
  shared_pool_id: string;
  online_virtual_cpus: string;
  maximum_physical_cpus_in_system: string;
  active_physical_cpus_in_system: string;
  shared_physical_cpus_in_system: string;
  notes: string;
}

export interface Ovm {
  _id: string;
  virtual_server_name: string;
  uuid: string;
  max_vcpus: string;
  vcpus: string;
  cpu_affinity: string;
  total_cpus: string;
  live_migration: boolean;
  ovm_high_availability: boolean;
  notes: string;
  dom0_max_vcpus: Number;
  dom0_cpu_affinity: string;
  ovm_ha: string;
  cpus: string;
  physical_server_mapping: string;
  total_threads: Number;
  threads_per_core: Number;
  licensable_cores: Number;
  same_pool_procs: string;
  virtual_procs: string;
}

export interface Xen {
  _id: string;
  virtual_server_name: string;
  cpu_affinity: string;
  vcpus: string;
  dedicated_vcpus: string;
  notes: string;
}

export interface Vcenter {
  _id: string;
  company: string;
  vcenter_server_name: string;
  vcenter_version: string;
  host_data: [VmWare];
}

export interface VmWare {
  _id: string;
  host_name: string;
  virtual_machine_data: [VmWareVirtualMachine];
  is_stand_alone: Boolean;
  data_center: string;
  cluster: string;
  full_name: string;
  version: string;
  power_state: string;
  connection_state_datastores: string;
  managed_by_server: string;
  vcenter_server_name: string;
  vendor: string;
  esx_version: string;
  connection_state: string;
  datastores: string;
}

export interface VmWareVirtualMachine {
  _id: string;
  vm_host_name: string;
  virtual_server_name: string;
  vm_guest_host_name: string;
  vm_guest_os: string;
  vm_ip_address: string;
  is_stand_alone: Boolean;
  data_center: string;
  cluster: string;
  full_name: string;
  version: string;
  power_state: string;
  connection_state_datastores: string;
  managed_by_server: string;
  vcenter_server_name: string;
  vendor: string;
  esx_version: string;
  connection_state: string;
  datastores: string;
}

export interface Pool {
  pool_name: string;
  pset_value_for_zone_from_physical: string;
  pset_value_for_zone_from_virtual: string;
  total_count_core_id: string;
}

export interface LocalZone {
  dedicated_cpu: string;
  capped_cpus: string;
  ncpus: string;
}

export interface OvmForSparc {
  constraint: string;
  whole_core: string;
  max_cores: string;
  pinned: string;
}

export interface Solaris {
  _id: string;
  virtual_server_name: string;
  type_of_solaris_partitioning: string;
  pool_type: Pool;
  local_zone_type: LocalZone;
  ovm_for_sparc_type: OvmForSparc;
  notes: string;
}

export interface KVM {
  _id: string;
  virtual_server_name: string;
  vcpus: string;
  cpu_affinity: string;
  total_cpus: string;
  pinned: boolean;
}

export interface ActProcCount {
  number_of_sockets: number;
  cores_per_socket: number;
  logical_processors: number;
  lcpu_attribute: string;
}

export interface ComplexInfo {
  complex_name: string;
  complex_serial_number: string;
  complex_product_order_number: string;
  complex_id_number: string;
}

export interface CoreUsageDets {
  total_core_usage_rights: string;
  committed_core_usage_rights: string;
  available_core_usage_rights: string;
  number_of_partitions_present: number;
}

export interface NPartitionSumm {
  npar_id: string;
  npar_name: string;
  npar_state: string;
  npar_has_vpars: boolean;
  npar_intended_active: boolean;
  npar_total_cores: number;
  npar_actual_active: number;
  npar_assigned_cores: number;
}

export interface VPartitionSumm {
vpar_id: string;
vpar_name: string;
vpar_state: string;
vpar_assigned_cores: number;
vpar_actual_active: number;
vpar_committed_rights: string;
}

export interface VirtualPartSumm {
capped: boolean;
cpu_min: number;
cpu_max: number;
licensable_cores: number;
}

export interface SecureResourcepartition {
  cpu_entitlements_fss: string;
  cpu_entitlements_pset: string;
  srp_name: string;
  prm_id: string;
  pset: string;
  licensables_cores: number;
  notes: string;
}
export interface HPUX {
  _id: string;
  virtual_server_name: string;
  // machine_information: MachineInfo;
  active_processor_count: ActProcCount;
  complex_information: ComplexInfo;
  core_usage_right_details: CoreUsageDets;
  npartition_resource_summary: NPartitionSumm;
  vpartition_resource_summary: VPartitionSumm;
  virtual_partition_resource_summary: VirtualPartSumm;
  secure_resource_partitions: SecureResourcepartition;

}

export interface Cloud {
  _id: string;
  virtual_server_name: string;
  description: string;
  instance_type: string;
  vcpus: number;
  hyperthreaded: boolean;
  license_method: string;
}

export interface OtherVirt {
  _id: string;
  virtual_server_name: string;
  description: string;
}

export interface OtherCloud {
  _id: string;
  virtual_server_name: string;
  description: string;
}

export interface Hardware {
  _id: string;
  cluster_id: string;
  company: string;
  server_name: string;
  server_model: string;
  virtualisation_name: string;
  virtualisation_description: string;
  operating_system: string;
  processor_model: string;
  processors: Number;
  cores_per_processor: Number;
  total_physical_cores: Number;
  cores_enabled: Number;
  threads_per_core: Number;
  multi_core_chip_or_multi_chip_model: string;
  processor_speed: string;
  server_purchase_date: Date;
  server_location: string;
  commission_date: Date;
  decommission_date: Date;
  hardware_refresh_term_or_date: string;
  license_allocated_to_server: [Licenses];
  ibm_virt: [IbmLpar];
  ovm_virt: [Ovm];
  xen_virt: [Xen];
  vmware_virt: [VmWareVirtualMachine];
  solaris_virt: [Solaris];
  kvm_virt: [KVM];
  hp_ux_virt: [HPUX];
  other_virt: OtherVirt;
  aws_cloud: [Cloud];
  azure_cloud: [Cloud];
  oracle_cloud: [Cloud];
  di_cloud: [Cloud];
  other_cloud: OtherCloud;
}
