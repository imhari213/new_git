// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatBottomSheet } from '@angular/material/bottom-sheet';

// models
import { Hardware } from '../hardware.model';
import { Contract } from '../../contracts/contract.model';

// services
import { ThemeService } from '../../theme.service';

// components
import { ServerDetailsBottomSheetComponent } from '../server-details-bottomsheet/server-details-bottom-sheet.component';

@Component({
  selector: 'app-licenses-dialog',
  templateUrl: './licenses-allocated-dialog.component.html',
  styleUrls: ['./licenses-allocated-dialog.component.css'],
  providers: [ThemeService]
})

export class LicensesAllocatedComponent implements OnInit {

  constructor(private themeService: ThemeService, private dialogRef: MatDialogRef<LicensesAllocatedComponent>,
     @Inject(MAT_DIALOG_DATA) private data: any, private bottomSheet: MatBottomSheet) {}

  form: FormGroup;
  mode = 'create';
  contractLinked: Contract;
  productLicensed: string;
  contracts: Contract[];
  hardware: Hardware;
  physical;
  virtList = [];
  licenseList = <any>[];
  selectedLicense;
  maxAllowed = 0;
  allocated = 0;
  input: HTMLElement;
  license = <any>[];
  virtType;

  ngOnInit() {

    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
    this.contracts = this.data.contracts;
    this.hardware = this.data.hardware;
    this.virtType = this.data.virtType;
    if (this.data.virtList) { this.virtList = this.data.virtList; }
    if (this.data.license) { this.mode = 'edit'; this.license = this.data.license; }

    this.form = new FormGroup({
      '_id': new FormControl (undefined
      ),
      'virtualisation_linked': new FormControl( this.hardware._id
      ),
      'product_licensed': new FormControl(null, {validators: [Validators.required]
      }),
      'license_metric_allocated': new FormControl(null
      ),
      'number_of_licenses_in_use': new FormControl(null
      ),
      'contract_linked': new FormControl(null
      ),
      'restricted_use': new FormControl(null
      )
    });

    this.physical = {_id: this.hardware._id, virtual_server_name: '*' + this.hardware.server_name};
    this.virtList = [this.physical].concat(this.virtList);

    this.dialogRef.updatePosition({top: '30px'});


    if (this.mode === 'edit') {
      this.allocated = this.license.number_of_licenses_in_use;

      // this.maxAllowed = this.license.number_of_licenses_in_use;
      this.setLicenseList(this.license.contract_linked);
      this.setValues(this.license.product_licensed);


      this.form.patchValue({
        '_id': this.license._id,
        'virtualisation_linked': this.license.virtualisation_linked,
        'product_licensed': this.license.product_licensed,
        'license_metric_allocated': this.license.license_metric_allocated,
        'contract_linked': this.license.contract_linked,
        'restricted_use': this.license.restricted_use,
        'number_of_licenses_in_use': this.license.number_of_licenses_in_use
      });
    }
  }


  setLicenseList(contract_id) {
    this.contractLinked = this.contracts.find(con => con._id === contract_id);
    this.licenseList = this.contractLinked.oracle_licenses;
    this.productLicensed = undefined;
    this.form.patchValue({product_licensed: null, license_metric_allocated: null, restricted_use: null, number_of_licenses_in_use: null});
    this.maxAllowed = 0;
  }

  filterLicenses() {
    const usableList = this.licenseList.filter(
      lic => ((lic.allowed > 0 || lic._id === this.license.product_licensed || lic.quantity === -1)
               && !lic.migration_date)
      );
    return usableList;
  }

  setValues(licenseId) {
   const selectedLicense = this.licenseList.find(lic => lic._id === licenseId);
   this.selectedLicense = selectedLicense.product_name;
   this.form.patchValue({
    license_metric_allocated: selectedLicense.metric,
    restricted_use: selectedLicense.restrictions,
    number_of_licenses_in_use: selectedLicense.allowed
   });

  if (this.mode === 'edit' && this.license.product_licensed === selectedLicense._id && selectedLicense.quantity !== -1) {
    this.maxAllowed = selectedLicense.allowed + this.allocated;
  } else if (selectedLicense.quantity === -1) {
     this.maxAllowed = 0;
  } else {
    this.maxAllowed = selectedLicense.allowed;
  }

   this.input = document.getElementById('numInput');
   this.input.setAttribute('max', (this.maxAllowed).toString());

  }

  add() {
    this.dialogRef.close({data: this.form.value});
  }

  close() {
    this.dialogRef.close();
    this.bottomSheet.dismiss();
  }


  openBottomSheet(): void {
    const bottomSheetRef = this.bottomSheet.open(ServerDetailsBottomSheetComponent, {
      hasBackdrop: false,
      panelClass: 'custom-width',
      data: {Physical: this.hardware, Virtual: this.data.virtList, Cloud: this.data.CloudDetails, Type: this.virtType},
    });
    bottomSheetRef.afterDismissed().subscribe(() => {
    });
  }

  allowedValue(allowed) {
    if (allowed === -1) { return 'Unlimited'; } else { return allowed; }
  }
}
