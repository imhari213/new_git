// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

// services
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-check-add-licences-dialog',
  templateUrl: './check-add-licences-dialog.component.html',
  styleUrls: ['./check-add-licences-dialog.component.css'],
  providers: [ThemeService]
})

export class CheckAddLicencesDialogComponent implements OnInit {

  constructor(private themeService: ThemeService,
    private dialogRef: MatDialogRef<CheckAddLicencesDialogComponent>, @Inject(MAT_DIALOG_DATA) private data: any) {}

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
  }

  confirmSelection(check) {
    this.dialogRef.close(check);
  }
}
