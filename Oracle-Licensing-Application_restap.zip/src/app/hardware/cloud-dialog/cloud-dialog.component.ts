// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// services
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-cloud-dialog',
  templateUrl: './cloud-dialog.component.html',
  styleUrls: ['./cloud-dialog.component.css'],
  providers: [ThemeService]
})

export class CloudComponent implements OnInit {

  form: FormGroup;
  mode = 'create';
  dataType: string;
  methodList = ['Included', 'BYOL'];
  threadedSelected;

  constructor(private themeService: ThemeService, public dialogRef: MatDialogRef<CloudComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    }

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
    this.dataType = this.data.type;
    if (this.dataType) {
      this.form = new FormGroup({
        'virtual_server_name': new FormControl(null, {validators: [Validators.required]
        }),
        'description': new FormControl(null
        ),
        'instance_type': new FormControl(null
        ),
        'vcpus': new FormControl(null
        ),
        'hyperthreaded': new FormControl(null
        ),
        'license_method': new FormControl(null
        ),
      });

      if (this.data.cloud) {
        this.mode = 'edit';
        this.threadedSelected = this.data.cloud.hyperthreaded;
        this.form.patchValue({'virtual_server_name': this.data.cloud.virtual_server_name,
                              'description': this.data.cloud.description,
                              'instance_type': this.data.cloud.instance_type,
                              'vcpus': this.data.cloud.vcpus,
                              'hyperthreaded': this.data.cloud.hyperthreaded,
                              'license_method': this.data.cloud.license_method});
      }
    }
  }

  add() {
    this.dialogRef.close(this.form.value);
  }

}
