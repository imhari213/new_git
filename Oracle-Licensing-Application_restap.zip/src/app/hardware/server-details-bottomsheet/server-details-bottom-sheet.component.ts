// angular
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA} from '@angular/material/bottom-sheet';
import { Component, OnInit, Inject} from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

// services
import { ThemeService } from 'src/app/theme.service';

@Component({
  selector: 'app-server-details-bottom-sheet',
  templateUrl: 'server-details-bottom-sheet.component.html',
  styleUrls: ['./server-details-bottom-sheet.component.css'],
  providers: [ThemeService],
})

export class ServerDetailsBottomSheetComponent implements OnInit {

  constructor(@Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
  public router: Router,
  private _bottomSheetRef: MatBottomSheetRef<ServerDetailsBottomSheetComponent>) {}

  ngOnInit() {

    this.router.events
      .subscribe(value => {
        if (value instanceof NavigationStart) {
          if (value.url !== '/add-hardware') {
            this.close();
          } // your current route
        }
      });
  }

  close() {
    this._bottomSheetRef.dismiss();
  }

}
