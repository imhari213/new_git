// angular
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

// services
import { ThemeService } from '../theme.service';

@Component({
  templateUrl: './error.component.html',
  providers: [ThemeService]
})
export class ErrorComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ErrorComponent>, private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: {message: string}) {}

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
  }

}
