export interface PartitionEvidence {
  owner: String;
  segment_type: String;
  segment_name: String;
  min_created: Date;
  min_last_dll_time: Date;
}

export interface ADGEvidence {
  dest_id: Number;
  dest_name: String;
  status: String;
  type: String;
  database_mode: String;
  recovery_mode: String;
}

export interface SpatialEvidence {
  sdo_geom_metadata_table: Number;
}

export interface OlapEvidence {
  owner: String;
  aw_number: Number;
  aw_name: String;
  pagespaces: Number;
  generations: Number;
}

export interface AdvancedCompEvidence {
  version: String;
  name: String;
  currently_used: Boolean;
  last_usage_date: Date;
  last_sample_date: Date;
}

export interface RealAppClusEvidence {
  oracle_rac_installed: String;
  value: String;
  inst_id_status: String;
}

export interface MultitenantEvidence {
  cbd: String;
  con_id_name: String;
  open_mode: String;
  open_time: String;
  container: String;
}

export interface AdvancedSecurityEvidence {
  tablespace_name: String;
  enc: String;
}

export interface ManagementEvidence {
  name: String;
  created: Date;
  last_modified: Date;
  description: String;
  type: String;
  status: String;
}

export interface Evidence {
  location: String;
  comments: String;
  partition_ev: [PartitionEvidence];
  active_data_guard_ev: [ADGEvidence];
  spatial_ev: [SpatialEvidence];
  olap_ev: [OlapEvidence];
  advanced_comp_ev: [AdvancedCompEvidence];
  real_app_cluster_ev: [RealAppClusEvidence];
  multitenant_ev: [MultitenantEvidence];
  advanced_security_ev: [AdvancedSecurityEvidence];
  management_ev: [ManagementEvidence];
}

export interface Options {
  _id: string;
  option_in_use: string;
  host_name: String;
  instance: String;
  version: String;
  support_status: String;
  usage: String;
  bugs: String;
  detected_usages: Number;
  total_samples: Number;
  currently_used: Boolean;
  aux_count: Number;
  feature_information: String;
  last_sample_date: Date;
  last_sample_period: String;
  sample_interval: String;
  description: String;
  sys_date: Date;
  feature_mapped: String;
  evidence: Evidence;
}
export interface Managements {
  _id: string;
  management_in_use: string;
  host_name: String;
  instance: String;
  version: String;
  support_status: String;
  usage: String;
  bugs: String;
  detected_usages: Number;
  total_samples: Number;
  currently_used: Boolean;
  aux_count: Number;
  feature_information: String;
  last_sample_date: Date;
  last_sample_period: String;
  sample_interval: String;
  description: String;
  sys_date: Date;
  evidence: Evidence;
}


export interface Database {
  _id: string;
  database_instance_name: string;
  physical_server_name: string;
  virtual_server_name: string;
  pluggable_databases: string;
  environment_usage: string;
  options_in_use: [Options];
  managements_in_use: [Managements];
  rac_nodes: string;
  fal_server: string;
  fal_client: string;
  cpu_count: Number;
  cpu_count_default: Boolean;
  installation_date: Date;
  users_defined: Number;
  product_edition: string;
  product_version: string;
  control_management_pack_access: string;
  current_sessions: Number;
  highwater_sessions: string;
  database_cloned_from: string;
  database_cloned_date: Date;
  application_name: string;
  application_vendor: string;
  application_type: string;
  architecture_type: string;
  user_type: string;
  web_or_app_tier_server_name: string;
  ebs_release: string;
  end_user: string;
  virtualisation_tech: string;
  migrated_from:  string;
  migration_date: Date;
  spatial_and_graph: Boolean;
  advanced_analytics: Boolean;
}
