// angular
import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ParamMap, ActivatedRoute } from '@angular/router';
import { MatDialog, MatTableDataSource, MAT_DATE_FORMATS } from '@angular/material';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// models
import { Company } from '../../companies/company.model';
import { Hardware } from '../../hardware/hardware.model';
import { Database } from '../databases.model';
import { EnviromentalUsage, ProductEdition } from '../../config/config.model';

// services
import { CompanyService } from 'src/app/companies/companies.service';
import { HwService } from 'src/app/hardware/hardware.service';
import { DbService } from '../database.service';
import { AuthService } from 'src/app/auth/auth.service';
import { ConfigService } from '../../config/config.service';

// components
import { OptionsInUseDialogComponent } from '../options-in-use-dialog/options-in-use-dialog.component';
import { ManagmentPacksDialogComponent } from '../managment-packs-dialog/managment-packs-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';

// misc
import { Subscription } from 'rxjs';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-database-create',
  templateUrl: './databases-create.component.html',
  styleUrls: ['./databases-create.component.css'],
  providers: [{provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
              {provide: STEPPER_GLOBAL_OPTIONS,
              useValue: { displayDefaultIndicatorType: false }}],
  encapsulation: ViewEncapsulation.None
})

export class DatabaseCreateComponent implements OnInit, OnDestroy {

  constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute,
              private companyService: CompanyService, private hardwareService: HwService, private dialog: MatDialog,
              private databaseService: DbService, private config: ConfigService) {}

  form: FormGroup;
  userIsAuthenticated: boolean;
  mode = 'create';
  userRole = 'read';

  environmentalUsageList = [];
  productEditionList = [];
  optionsColumns: String[] = ['option', 'feature', 'host', 'instance', 'edit'];
  managementColumns: String[] = ['Management Packs In Use', 'host', 'instance', 'edit'];
  optionsDataSource;
  managementDataSource;

  companyId;
  hardwareId;
  databaseId;
  database: Database;
  companies: Company[];
  hardwares: Hardware[];
  selectedHardware: Hardware;
  virtualList;
  virtualId;
  managementPackAccess;
  diagnostics = false;
  tuning = false;
  cpuCountDefault: Boolean = false;
  optionsInUseList = <any>[];
  managementPacksList = <any>[];

  authStatusSub: Subscription;
  companySub: Subscription;
  hardwareSub: Subscription;
  enviromentalUsageSub: Subscription;
  productEditionSub: Subscription;

  ngOnInit() {

    this.getAuth();
    this.getCompanies();
    this.createForm();
    this.config.getEnviromentalUsages();
    this.enviromentalUsageSub = this.config.getEnviromentalUsagesListener()
      .subscribe((enviromentalUsageData: {enviromentalUsages: EnviromentalUsage[]}) => {
        this.environmentalUsageList = enviromentalUsageData.enviromentalUsages;
      });
    this.config.getProductEditions();
    this.productEditionSub = this.config.getProductEditionsListener()
      .subscribe((productEditionData: {productEditions: ProductEdition[]}) => {
        this.productEditionList = productEditionData.productEditions;
      });


    if (localStorage.getItem('compId')) {
      this.companyId = localStorage.getItem('compId');
      this.form.patchValue({'end_user': this.companyId});
    }


    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('companyId')) {
        this.companyId = paramMap.get('companyId');
        this.form.patchValue({'end_user': this.companyId});
      }
      if (paramMap.has('hardwareId')) { this.hardwareId = paramMap.get('hardwareId'); }
      if (paramMap.has('databaseId')) { this.databaseId = paramMap.get('databaseId'); this.mode = 'edit'; this.getDatabase(); }
    });
    this.getHardwares(this.companyId);

  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    this.companySub.unsubscribe();
    this.hardwareSub.unsubscribe();
    this.enviromentalUsageSub.unsubscribe();
    this.productEditionSub.unsubscribe();
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  getHardwares(compId) {

    this.hardwareService.searchHardwares(this.companyId, undefined, undefined, undefined, null, null, null, null, null);
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
    .subscribe((hardwareData: {hardwares: Hardware[]; hardwareCount: Number}) => {
      this.hardwares = hardwareData.hardwares;
      if (this.hardwareId) { this.selectHardware(this.hardwareId); }
      if (this.database) { this.selectHardware(this.database.physical_server_name); this.virtualId = this.database.virtual_server_name; }
    });
  }

  getDatabase() {
    this.databaseService.getDatabase(this.databaseId).subscribe(db => {
      this.database = db;
      this.optionsInUseList = this.database.options_in_use;
      this.managementPacksList = this.database.managements_in_use;
      this.fillForm();
    });
  }

  createForm() {
    this.form = new FormGroup({ // intialise form
      'database_instance_name': new FormControl(null, {validators: [Validators.required]
      }),
      'physical_server_name': new FormControl(this.hardwareId
      ),
      'virtual_server_name': new FormControl(null
      ),
      'pluggable_databases': new FormControl(null
      ),
      'environment_usage': new FormControl(null
      ),
      'options_in_use': new FormControl(null
      ),
      'managements_in_use': new FormControl(null
      ),
      'rac_nodes': new FormControl(null
      ),
      'fal_server': new FormControl(null
      ),
      'fal_client': new FormControl(null
      ),
      'cpu_count': new FormControl(null
      ),
      'cpu_count_default': new FormControl(null
      ),
      'installation_date': new FormControl(null
      ),
      'users_defined': new FormControl(null
      ),
      'product_edition': new FormControl(null
      ),
      'product_version': new FormControl(null
      ),
      'control_management_pack_access': new FormControl(null
      ),
      'current_sessions': new FormControl(null
      ),
      'highwater_sessions': new FormControl(null
      ),
      'database_cloned_from': new FormControl(null
      ),
      'database_cloned_date': new FormControl(null
      ),
      'license_allocated_to_server': new FormControl(null
      ),
      'application_name': new FormControl(null
      ),
      'application_vendor': new FormControl(null
      ),
      'application_type': new FormControl(null
      ),
      'architecture_type': new FormControl(null
      ),
      'user_type': new FormControl(null, {validators: [Validators.required]
      }),
      'web_or_app_tier_server_name': new FormControl(null
      ),
      'ebs_release': new FormControl(null
      ),
      'end_user': new FormControl(this.companyId
      ),
      'virtualisation_tech': new FormControl(null
      )
    });
  }

  fillForm() {

    this.form.patchValue({
      'database_instance_name': this.database.database_instance_name,
      'physical_server_name': this.database.physical_server_name,
      'virtual_server_name': this.database.virtual_server_name,
      'pluggable_databases': this.database.pluggable_databases,
      'options_in_use': this.optionsInUseList,
      'managements_in_use': this.managementPacksList,
      'rac_nodes': this.database.rac_nodes,
      'fal_server': this.database.fal_server,
      'fal_client': this.database.fal_client,
      'cpu_count': this.database.cpu_count,
      'installation_date': this.database.installation_date,
      'users_defined': this.database.users_defined,
      'product_edition': this.database.product_edition,
      'product_version': this.database.product_version,
      'current_sessions': this.database.current_sessions,
      'highwater_sessions': this.database.highwater_sessions,
      'database_cloned_from': this.database.database_cloned_from,
      'database_cloned_date': this.database.database_cloned_date,
      'application_name': this.database.application_name,
      'application_vendor': this.database.application_vendor,
      'application_type': this.database.application_type,
      'architecture_type': this.database.architecture_type,
      'user_type': this.database.user_type,
      'web_or_app_tier_server_name': this.database.web_or_app_tier_server_name,
      'ebs_release': this.database.ebs_release,
      'end_user': this.database.end_user,
      'virtualisation_tech': this.database.virtualisation_tech,
      'environment_usage': this.database.environment_usage
    });

    if (this.database.control_management_pack_access) {
      if (this.database.control_management_pack_access === 'tuning') {
        this.tuning = true;
        this.diagnostics = true;
      }
      if (this.database.control_management_pack_access === 'diagnostics') {
        this.diagnostics = true;
      }
    }
    this.cpuCountDefault = this.database.cpu_count_default;

    this.optionsInUseList = this.database.options_in_use;
    this.managementPacksList = this.database.managements_in_use;

    this.optionsDataSource = new MatTableDataSource(this.optionsInUseList);
    this.managementDataSource = new MatTableDataSource(this.managementPacksList);
  }


  setDetails(compId) {
    this.getHardwares(compId);
  }

  selectHardware(hardwareId) {
    this.selectedHardware = this.hardwares.find(hw => hw._id === hardwareId);
    if (this.selectedHardware.solaris_virt && this.selectedHardware.solaris_virt.length > 0) {
      this.virtualList = this.selectedHardware.solaris_virt;
    } else if (this.selectedHardware.ibm_virt && this.selectedHardware.ibm_virt.length > 0) {
      this.virtualList = this.selectedHardware.ibm_virt;
    } else if (this.selectedHardware.ovm_virt && this.selectedHardware.ovm_virt.length > 0) {
      this.virtualList = this.selectedHardware.ovm_virt;
    } else if (this.selectedHardware.xen_virt && this.selectedHardware.xen_virt.length > 0) {
      this.virtualList = this.selectedHardware.xen_virt;
    } else if (this.selectedHardware.vmware_virt && this.selectedHardware.vmware_virt.length > 0) {
      this.virtualList = this.selectedHardware.vmware_virt;
    } else if (this.selectedHardware.kvm_virt && this.selectedHardware.kvm_virt.length > 0) {
      this.virtualList = this.selectedHardware.kvm_virt;
    }

  }

  onCheck(event, checked: string) {
    if (checked === 'tuning') {
      this.tuning = event.checked;
      if (event.checked === true) {
        this.diagnostics = true;
      }
    } else if (checked === 'diagnostics') {
      this.diagnostics = event.checked;
      if (event.checked === false) {
        this.tuning = false;
      }
    }
  }

  optionsDialog(element): void {
    let index;
    if (element) { index = this.optionsInUseList.indexOf(element); }

    const dialogRef = this.dialog.open(OptionsInUseDialogComponent, {
      disableClose: true,
      data: {option: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.optionsInUseList.splice(index, 1, data);
        } else {
          this.optionsInUseList.push(data);
        }
        this.optionsDataSource = new MatTableDataSource(this.optionsInUseList);
      } else {
        console.log('closed');
      }
    });
  }

  deleteOption(element) {
    const index = this.optionsInUseList.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.option_in_use, pageViewName: 'Option'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.optionsInUseList.splice(index, 1);
        this.optionsDataSource = new MatTableDataSource(this.optionsInUseList);
      } else {
        console.log('closed');
      }
    });
  }

  managementDialog(element): void {

    let index;

    if (element) { index = this.managementPacksList.indexOf(element); }

    const dialogRef = this.dialog.open(ManagmentPacksDialogComponent, {
      disableClose: true,
      data: {management_pack: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.managementPacksList.splice(index, 1, data);
        } else {
          this.managementPacksList.push(data);
        }
        this.managementDataSource = new MatTableDataSource(this.managementPacksList);
      } else {
        console.log('closed');
      }
    });

  }

  deleteManagement(element) {
    const index = this.managementPacksList.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.management_in_use, pageViewName: 'Managment Pack'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.managementPacksList.splice(index, 1);
        this.managementDataSource = new MatTableDataSource(this.managementPacksList);
      } else {
        console.log('closed');
      }
    });
  }

  toggleCPU(event) {
    this.cpuCountDefault = event.checked;
  }

  addDb() {


    if (this.tuning) { this.form.patchValue({control_management_pack_access: 'tuning'}); } else
    if (this.diagnostics) { this.form.patchValue({control_management_pack_access: 'diagnostics'}); }

    this.form.patchValue({options_in_use: this.optionsInUseList, managements_in_use: this.managementPacksList});
    this.form.patchValue({cpu_count_default: this.cpuCountDefault});

    if (this.mode === 'create') {
      this.databaseService.addDb(this.form.value).subscribe(response => {
        this.onCancel();
      });
    } else {
      this.databaseService.updateDatabase(this.databaseId, this.form.value).subscribe(response => {
        this.onCancel(); // needs to update first before returning to list
      });
    }
  }

  onCancel() {
      this.router.navigate(['/list-database/']);
  }
}

