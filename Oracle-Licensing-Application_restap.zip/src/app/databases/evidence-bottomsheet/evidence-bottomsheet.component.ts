// angular
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA} from '@angular/material/bottom-sheet';
import { Component, OnInit, Inject} from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

// services
import { ThemeService } from 'src/app/theme.service';
import { Options, Evidence } from '../databases.model';
import { MatTableDataSource } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-server-details-bottom-sheet',
  templateUrl: 'evidence-bottomsheet.component.html',
  styleUrls: ['./evidence-bottomsheet.component.css'],
  providers: [ThemeService],
})

export class EvidenceBottomSheetComponent implements OnInit {

  constructor(@Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
  public router: Router,
  private _bottomSheetRef: MatBottomSheetRef<EvidenceBottomSheetComponent>) {}


  form: FormGroup;
  mode;
  currentlyUsed = false;
  option: Options;
  evidenceDataSource;
  evidenceColumns: String[] = ['name', 'detected usages', 'total samples', 'currently used', 'first usage date', 'last usage date', 'last sample date'];
  optionName = '';
  evidence = <any>[];
  feature: String;

  ngOnInit() {

    this.mode = this.data.mode;
    this.feature = this.data.feature;

    if (this.mode === 'add') {
      this.createForm();
    }
    if (this.mode === 'edit') {
      this.createForm();
      this.fillForm();
    }
    if (this.mode === 'view') {

      switch (this.feature) {
        case 'Active Data Guard':
          this.evidenceColumns = ['dest_id', 'dest_name', 'status', 'type', 'database_mode', 'recovery_mode'];
          this.evidence = this.data.evidence.active_data_guard_ev;
          break;
        case 'Partitioning':
          this.evidenceColumns = ['owner', 'segment_type', 'segment_name', 'min_created', 'min_last_dll_time'];
          this.evidence = this.data.evidence.partition_ev;
          break;
        case 'Spatial and Graph':
          this.evidenceColumns = ['sdo_geom_metadata_table'];
          this.evidence = this.data.evidence.spatial_ev;
          break;
        case 'OLAP':
          this.evidenceColumns = ['owner', 'aw_number', 'aw_name', 'pagespaces', 'generations'];
          this.evidence = this.data.evidence.olap_ev;
          break;
        case 'Advanced Compression':
          this.evidenceColumns = ['version', 'name', 'currently_used', 'last_usage_date', 'last_sample_date'];
          this.evidence = this.data.evidence.advanced_comp_ev;
          break;
        case 'Real Application Clusters':
          this.evidenceColumns = ['oracle_rac_installed', 'value', 'inst_id_status'];
          this.evidence = this.data.evidence.real_app_cluster_ev;
          break;
        case 'Multitenant':
          this.evidenceColumns = ['cbd', 'con_id_name', 'open_mode', 'open_time', 'container'];
          this.evidence = this.data.evidence.multitenant_ev;
          break;
        case 'Advanced Security':
          this.evidenceColumns = ['tablespace_name', 'enc'];
          this.evidence = this.data.evidence.advanced_security_ev;
          break;
        case 'management':
          this.evidenceColumns = ['name', 'created', 'last_modified', 'description', 'type', 'status'];
          this.evidence = this.data.evidence.management_ev;
      }
      this.evidenceDataSource = new MatTableDataSource(this.evidence);
    }

  }

  createForm() {

    this.form = new FormGroup({
      '_id': new FormControl(undefined),
    });

    switch (this.feature) {
      case 'Partitioning':
        this.form.addControl('owner', new FormControl(null));
        this.form.addControl('segment_type', new FormControl(null));
        this.form.addControl('segment_name', new FormControl(null));
        this.form.addControl('min_created', new FormControl(null));
        this.form.addControl('min_last_dll_time', new FormControl(null));
        break;
      case 'Active Data Guard':
        this.form.addControl('dest_id', new FormControl(null));
        this.form.addControl('dest_name', new FormControl(null));
        this.form.addControl('status', new FormControl(null));
        this.form.addControl('type', new FormControl(null));
        this.form.addControl('database_mode', new FormControl(null));
        this.form.addControl('recovery_mode', new FormControl(null));
        break;
      case 'Spatial and Graph':
        this.form.addControl('sdo_geom_metadata_table', new FormControl(null));
        break;
      case 'OLAP':
        this.form.addControl('owner', new FormControl(null));
        this.form.addControl('aw_number', new FormControl(null));
        this.form.addControl('aw_name', new FormControl(null));
        this.form.addControl('pagespaces', new FormControl(null));
        this.form.addControl('generations', new FormControl(null));
        break;
      case 'Advanced Compression':
        this.form.addControl('version', new FormControl(null));
        this.form.addControl('name', new FormControl(null));
        this.form.addControl('currently_used', new FormControl(null));
        this.form.addControl('last_usage_date', new FormControl(null));
        this.form.addControl('last_sample_date', new FormControl(null));
        break;
      case 'Real Application Clusters':
        this.form.addControl('oracle_rac_installed', new FormControl(null));
        this.form.addControl('value', new FormControl(null));
        this.form.addControl('inst_id_status', new FormControl(null));
        break;
      case 'Multitenant':
        this.form.addControl('cbd', new FormControl(null));
        this.form.addControl('con_id_name', new FormControl(null));
        this.form.addControl('open_mode', new FormControl(null));
        this.form.addControl('open_time', new FormControl(null));
        this.form.addControl('container', new FormControl(null));
        break;
      case 'Advanced Security':
        this.form.addControl('tablespace_name', new FormControl(null));
        this.form.addControl('enc', new FormControl(null));
        break;
      case 'management':
        this.form.addControl('name', new FormControl(null));
        this.form.addControl('created', new FormControl(null));
        this.form.addControl('last_modified', new FormControl(null));
        this.form.addControl('description', new FormControl(null));
        this.form.addControl('type', new FormControl(null));
        this.form.addControl('status', new FormControl(null));
        break;

    }

  }

  fillForm() {
    try {
      this.currentlyUsed = this.data.evidence.currently_used;
    } catch {}

    this.form.patchValue(this.data.evidence);

  }

  toggleUsed(event) {
    this.currentlyUsed = event.checked;
  }


  close() {
    this._bottomSheetRef.dismiss();
  }

  add() {
    this.form.patchValue({currently_used: this.currentlyUsed});
    this._bottomSheetRef.dismiss(this.form.value);
  }

}
