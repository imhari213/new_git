// angular
import { Component, OnInit, OnDestroy, ViewEncapsulation} from '@angular/core';
import { PageEvent, MatDialog, MatTableDataSource, MatSnackBar, MatBottomSheet } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

// models
import { Company } from '../../companies/company.model';
import { Hardware } from '../../hardware/hardware.model';
import { Database, Options} from '../databases.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { CompanyService } from '../../companies/companies.service';
import { ContractService } from 'src/app/contracts/contracts.service';
import { HwService } from 'src/app/hardware/hardware.service';
import { DbService } from '../database.service';
import { AuditService } from 'src/app/audit/audit.service';
import { OptionsService } from '../../options.service';

// components
import { OptionsInUseDialogComponent } from '../options-in-use-dialog/options-in-use-dialog.component';
import { ManagmentPacksDialogComponent } from '../managment-packs-dialog/managment-packs-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { UserRequestDialogComponent } from '../user-request-dialog/user-request-dialog.component';

// misc
import { Subscription } from 'rxjs';
import { _MatTabHeaderMixinBase } from '@angular/material/tabs/typings/tab-header';
import { EvidenceBottomSheetComponent } from '../evidence-bottomsheet/evidence-bottomsheet.component';
import { FieldSelectionDialogComponent } from 'src/app/fieldSelectionDialog/field-selection.component';


export interface OiU {
  advancedAnalytics?: Options[];
  exadata?: Options[];
  activeDataGueard?: Options[];
}

export interface Field {
  name: string;
  completed: boolean;
}

@Component({
  selector: 'app-database-list',
  templateUrl: './database-list.component.html',
  styleUrls: ['./database-list.component.css'],
  encapsulation: ViewEncapsulation.None
})



export class DatabaseListComponent implements OnInit, OnDestroy {

  userIsAuthenticated: boolean;
  userRole = 'read';
  isLoading = false;

  databasesPerPage = 20;
  currentPage = 1;
  pageSizeOptions = [20, 50, 100];
  sortType;

  companyId;
  contractId;
  hardwareId;
  searchParam;

  databases: Database[];
  totalDatabases;
  companies: Company[];
  hardwares: Hardware[];
  hardwareOnDb: Hardware;

  database: Database;
  optionsInUse = <any>[];
  managementPacks = <any>[];
  evidence = <any>[];
  optionsFields: Field[];

  // optonsColumnsToDisplay: String[] = ['option', 'host', 'instance', 'edit'];
  optonsColumnsToDisplay: String[] = ['option', 'host', 'instance', 'support status', 'usage', 'bugs'];
  optionsDataSource: MatTableDataSource<any>;
  managementPacksColumnstoDisplay: String[] = ['Management Pack', 'host', 'instance'];
  managementDataSource: MatTableDataSource<any>;

  authStatusSub: Subscription;
  companySub: Subscription;
  contractSub: Subscription;
  hardwareSub: Subscription;
  databaseSub: Subscription;
  headerOptionSub: Subscription;

  serverName: string;
  nonCompliantWarning: string;
  checkedHeader;
  changePageSize = false;
  compareDatabaseId = null;
  pageChosen = null;

  featureMapped?: String[];
  dividedOptions: OiU;
  advancedAnalyticsDataSource: MatTableDataSource<any>;
  exadataDataSource: MatTableDataSource<any>;

  completeDatabaseColumns = [
    {name: 'Instance Name', modelName: 'database_instance_name'},
    {name: 'Physical Server Name', modelName: 'physical_server_name'},
    {name: 'Virtual Server Name', modelName: 'virtual_server_name'},
    {name: 'Pluggable Databases', modelName: 'pluggable_databases'},
    {name: 'Environment Usage', modelName: 'environment_usage'},
    {name: 'RAC Nodes', modelName: 'rac_nodes'},
    {name: 'FAL Server', modelName: 'fal_server'},
    {name: 'FAL Client', modelName: 'fal_client'},
    {name: 'CPU Count', modelName: 'cpu_count'},
    {name: 'CPU Count Default', modelName: 'cpu_count_default'},
    {name: 'Installation Date', modelName: 'installation_date'},
    {name: 'Users Defined', modelName: 'users_defined'},
    {name: 'Product ed.', modelName: 'product_edition'},
    {name: 'Product vs.', modelName: 'product_version'},
    {name: 'Control Management Pack Access', modelName: 'control_management_pack_access'},
    {name: 'Current Sessions', modelName: 'current_sessions'},
    {name: 'Highwater Sessions', modelName: 'highwater_sessions'},
    {name: 'Cloned From', modelName: 'database_cloned_from'},
    {name: 'Cloned Date', modelName: 'database_cloned_date'},
    {name: 'App name', modelName: 'application_name'},
    {name: 'App Vendor', modelName: 'application_vendor'},
    {name: 'App Type', modelName: 'application_type'},
    {name: 'Architecture Type', modelName: 'architecture_type'},
    {name: 'User Type', modelName: 'user_type'},
    {name: 'Web or App Tier Server name', modelName: 'web_or_app_tier_server_name'},
    {name: 'EBS Release', modelName: 'ebs_release'},
    {name: 'Company', modelName: 'end_user'},
    {name: 'Virt Tech', modelName: 'virtualisation_tech'},
    {name: 'Migration Info', modelName: 'null'},
    {name: 'Spatial and Graph', modelName: 'spatial_and_graph'},
    {name: 'Advanced Analytics', modelName: 'advanced_analytics'},
  ];

  currentDatabaseColumns = [
    {name: 'Instance Name', modelName: 'database_instance_name'},
    {name: 'Environment Usage', modelName: 'environment_usage'},
    {name: 'Product ed.', modelName: 'product_edition'},
    {name: 'Product vs.', modelName: 'product_version'},
  ];


  constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute,
              private databaseService: DbService, private companyService: CompanyService, private contractService: ContractService,
              private hardwareService: HwService, private dialog: MatDialog, private auditService: AuditService,
              private snackBar: MatSnackBar, private optionsService: OptionsService,
              private bottomSheet: MatBottomSheet) {}

  ngOnInit() {
    this.pageChosen = 'FIRST';
    this.getAuth();

    if (localStorage.getItem('compId')) { this.companyId = localStorage.getItem('compId'); }
    if (localStorage.getItem('contractId')) { this.contractId = localStorage.getItem('contractId'); }
    if (localStorage.getItem('hardwareId')) { this.hardwareId = localStorage.getItem('hardwareId'); }

    this.isLoading = true;

    (async () => { this.getCompanies(); })();
    (async () => { this.getDatabases(); })();
    (async () => { this.getHardwares(); })();

    this.checkedHeader = this.optionsService.getHeaderOption();
      this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
      });

    this.optionsFields = [
      {name: 'option', completed: true},
      {name: 'host', completed: true},
      {name: 'instance', completed: true},
      {name: 'version', completed: false},
      {name: 'support status', completed: true},
      {name: 'usage', completed: true},
      {name: 'bugs', completed: true},
      {name: 'detected usages', completed: false},
      {name: 'total samples', completed: false},
      {name: 'currently used', completed: false},
      {name: 'aux count', completed: false},
      {name: 'feature information', completed: false},
      {name: 'last sample date', completed: false},
      {name: 'last sample period', completed: false},
      {name: 'sample interval', completed: false},
      {name: 'description', completed: false},
      {name: 'sys date', completed: false}
    ];

    // this.optonsColumnsToDisplay = ['option', 'host', 'instance', 'support status', 'usage', 'bugs', 'edit'];

  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    if (this.companySub) {
      this.companySub.unsubscribe();
    }
    if (this.contractSub) {
      this.contractSub.unsubscribe();
    }
    if (this.hardwareSub) {
      this.hardwareSub.unsubscribe();
    }
    if (this.databaseSub) {
      this.databaseSub.unsubscribe();
    }
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
    if (['master', 'admin', 'write'].includes(this.userRole)) {
      this.optonsColumnsToDisplay.push('edit');
      this.managementPacksColumnstoDisplay.push('edit');
    }
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
        this.companies = companyData.companies;
      });
  }

  getHardwares() {
    this.hardwareService.getHardwares(null, null);
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
    .subscribe((hardwareData: {hardwares: Hardware[]; hardwareCount: Number}) => {
      this.hardwares = hardwareData.hardwares;
    });
  }

  getDatabases() {
    this.databaseService.searchDatabase(
      this.companyId, this.hardwareId, this.searchParam, this.databasesPerPage, this.currentPage, this.sortType,
      this.pageChosen, this.compareDatabaseId
      );
    this.databaseSub = this.databaseService.getDatabaseUpdateListener()
    .subscribe((databaseData: {databases: Database[]; databaseCount: Number}) => {
      this.totalDatabases = databaseData.databaseCount;
      this.databases = databaseData.databases;
      this.changePageSize = false;
      this.pageChosen = null;
      this.compareDatabaseId = null;
      this.isLoading = false;
    });
  }

  sendRequest(event, database) {
    event.stopPropagation();
    const compName = this.getCompanyName(database.end_user);
    this.setHardwareName(database.physical_server_name);
    const dialogRef = this.dialog.open(UserRequestDialogComponent, {
      disableClose: true,
      data: {database: database.database_instance_name, compId: database.end_user},
      width: '50%',
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const message =
        'I would like to request that the database ' + database.database_instance_name + ' currently on ' + this.serverName
        + ' to be moved to the server ' + result.server;
        const migrateDbObj = {
          hw_id: result.hwId,
          db_id: database._id,
        };
        const requestObj = {
          message: message,
          contact: result.contact,
          userEmail: localStorage.email,
          severity: result.severity,
          company: compName,
          typeOfRequest: result.requestType,
          migrateDb: migrateDbObj

        };
        this.authService.sendRequest(requestObj);
        const snackMessage = 'Your request has been sent';

        this.snackBar.open( snackMessage , 'Close', {duration: 5000});
      }
    });
  }
  setSortType(type) {
    this.pageChosen = 'FIRST';
    this.sortType = type;
    this.getDatabases();
  }

  getHardwareName() {
    try {
      return this.hardwares.find(hw => hw._id === this.hardwareId).server_name;
    } catch {
      return 'Unknown';
    }
  }

  getColumnsClicked(option, event) {
    if (event === true) {
      this.currentDatabaseColumns.push(option);
    } else {
      const index = this.currentDatabaseColumns.indexOf(option);
      this.currentDatabaseColumns.splice(index, 1);
    }
  }

  controlDandT(d_and_t) {
    let returnValue = 'None';
    if (d_and_t === 'tuning') {
      returnValue = 'Diagnostics + Tuning';
    }
    if (d_and_t === 'diagnostics') {
      returnValue = 'Diagnostics';
    }

    return returnValue;
  }

    getCheckedBoolean(column) {
    return this.currentDatabaseColumns.find(object => object['name'] === column.name);
   }

  onExpand(database) {
    this.database = database;
    this.optionsInUse = database.options_in_use;
    this.managementPacks = database.managements_in_use;
    this.setHardwareName(database.physical_server_name);

    this.dividedOptions = {};
    this.featureMapped = [];
    this.optionsInUse.forEach(element => {
      if (!this.featureMapped.includes(element.feature_mapped)) {
        this.featureMapped.push(element.feature_mapped);
      }

    });

    const firstFeature = this.optionsInUse[0].feature_mapped;
    this.optionsDataSource = new MatTableDataSource(this.optionsInUse.filter(option => (option.feature_mapped === firstFeature)));

   // this.optionsDataSource = new MatTableDataSource(this.dividedOptions.advancedAnalytics);

    // this.optionsDataSource = new MatTableDataSource(this.optionsInUse);
    this.managementDataSource = new MatTableDataSource(this.managementPacks);
  }

  updateTable(event) {
    const tableData = this.optionsInUse.filter(option => (option.feature_mapped === event.tab.textLabel));
    this.optionsDataSource = new MatTableDataSource(tableData);
  }

  setHardwareName(serverId) {
    this.hardwareService.getHardwareName(serverId).subscribe(result => {
      this.serverName = result.serverName;
    });
  }

  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    this.databasesPerPage = pageData.pageSize;

    const numOfPages = Math.ceil(this.totalDatabases / this.databasesPerPage);
    if (pageData.pageIndex + 1 === numOfPages) {
      this.pageChosen = 'LAST';
    } else if (pageData.pageIndex > pageData.previousPageIndex) {
      this.pageChosen = 'NEXT';
      this.compareDatabaseId = this.databases[this.databases.length - 1]._id;
    } else if (pageData.pageIndex === 0) {
      this.pageChosen = 'FIRST';
    } else {
      this.pageChosen = 'PREVIOUS';
      this.compareDatabaseId = this.databases[0]._id;
    }
    if (pageData.pageSize !== this.databasesPerPage) {
      this.databasesPerPage = pageData.pageSize;
      this.changePageSize = true;
    }

    this.getDatabases();
  }

  getCompanyName(compId) {
    let compName = compId;
    try { compName = this.companies.find(comp => comp._id === compId).company_name; } catch {}
    return compName;
  }

  getPhysicalName(hardwareId) {
    this.hardwareOnDb = this.hardwares.find(hw => hw._id === hardwareId);
    return this.hardwareOnDb.server_name;
  }

  getVirtualName(virtId) {
    try { return this.hardwareOnDb.ibm_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { return this.hardwareOnDb.ovm_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { return this.hardwareOnDb.xen_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { return this.hardwareOnDb.solaris_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { return this.hardwareOnDb.vmware_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
    try { return this.hardwareOnDb.kvm_virt.find(virt => virt._id === virtId).virtual_server_name; } catch {}
  }

  optionsDialog(element): void {
    let index;
    if (this.optionsInUse !== null) {
      index = this.optionsInUse.indexOf(element);
    } else {
      this.optionsInUse = [];
    }

    const dialogRef = this.dialog.open(OptionsInUseDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {option: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.optionsInUse.splice(index, 1, data);
        } else {
          this.optionsInUse.push(data);
        }

        this.database.options_in_use = this.optionsInUse;
        this.databaseService.updateDatabase(this.database._id, this.database).subscribe(returnData => {
          this.onExpand(returnData);
          this.optionsDataSource = new MatTableDataSource(this.optionsInUse
            .filter(option => (option.feature_mapped === element.feature_mapped)));
        });


      } else {
        console.log('closed');
      }
    });


  }

  deleteOption(element) {
    const index = this.optionsInUse.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.option_in_use, pageViewName: 'Option'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.optionsInUse.splice(index, 1);
        this.database.options_in_use = this.optionsInUse;
        this.databaseService.updateDatabase(this.database._id, this.database).subscribe(returnData => {
          this.onExpand(returnData);
        });
      } else {
        console.log('closed');
      }
    });
  }

  openManagmentDialog(element): void {
    let index;
    if (this.managementPacks !== null) {
      index = this.managementPacks.indexOf(element);
    } else {
      this.managementPacks = [];
    }

    const dialogRef = this.dialog.open(ManagmentPacksDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {management_pack: element}
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        if (element) {
          data._id = element._id;
          this.managementPacks.splice(index, 1, data);
        } else {
          this.managementPacks.push(data);
        }

        this.database.managements_in_use = this.managementPacks;
        this.databaseService.updateDatabase(this.database._id, this.database).subscribe(returnData => {
          this.onExpand(returnData);
        });
      } else {
        console.log('closed');
      }
    });

  }

  deleteManagementPack(element) {
    const index = this.managementPacks.indexOf(element);
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.management_in_use, pageViewName: 'Management Pack'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.managementPacks.splice(index, 1);
        this.database.managements_in_use = this.managementPacks;
        this.databaseService.updateDatabase(this.database._id, this.database).subscribe(returnData => {
          this.onExpand(returnData);
        });
      } else {
        console.log('closed');
      }
    });
  }

  onDelete(event, element) {
    event.stopPropagation();
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.database_instance_name, pageViewName: 'database'}
    });
    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.databaseService.deleteDatabase(element._id).subscribe(response => {
          this.getDatabases();
        });
      }
    });
  }

  addDatabase() {
    if (this.hardwareId) {

      this.router.navigate(['/add-database/' + this.companyId]);
    } else if (this.companyId) {
      this.router.navigate(['/add-database/' + this.companyId]);
    } else {
      this.router.navigate(['/add-database']);
    }
  }

  backToCompanies() {
    const compName = this.companies.find(comp => comp._id === this.companyId).company_name;
    this.router.navigate(['/company-details/' + compName]);
  }

  backToContracts() {
    this.router.navigate(['list-contract/']);
  }

  backToHardWares() {
      this.router.navigate(['list-hardware/']);
  }

  onSearch(toSearch: string) {
    if (toSearch === '') {this.searchParam = undefined; } else { this.searchParam = toSearch; }
    this.getDatabases();
  }

  setNonCompliantWarning(database) {
    if (database.spatial_and_graph === false && database.advanced_analytics === false) {
      this.nonCompliantWarning =
      'There are no licenses allocated to \'Advanced Analytics\' and \'Spatial and Graph\' , you are non-compliant ';
    } else if (database.spatial_and_graph === false) {
      this.nonCompliantWarning = 'There is no license allocated to \'Spatial and Graph\', you are non-compliant ';
    } else if (database.advanced_analytics === false) {
      this.nonCompliantWarning = 'There is no license allocated to \'Advanced Analytics\', you are non-compliant ';
    }
  }

  openBottomSheet(option): void {
    let feature;

    if (option.feature) { feature = option.feature; } else { feature = 'management'; }
    const bottomSheetRef = this.bottomSheet.open(EvidenceBottomSheetComponent, {
      panelClass: ['evidence-width'],
      data: {mode: 'view', evidence: option.evidence, feature: feature},
    });
    bottomSheetRef.afterDismissed().subscribe(() => {
    });
  }

  toggleBottomsheet(option, state) {
    if (state === 'open') {
      this.openBottomSheet(option);
    } else {
      this.bottomSheet.dismiss();
    }
  }

  fieldSelectionDialog(): void {

    const dialogRef = this.dialog.open(FieldSelectionDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {name: 'Options', fields: this.optionsFields }
    });

    dialogRef.afterClosed().subscribe(list => {
      this.optionsFields = list;
      const fieldList = [];
      this.optionsFields.forEach(opt => {
        if (opt.completed === true) {
          fieldList.push(opt.name);
        }
      });

      if (['master', 'admin', 'write'].includes(this.userRole)) {
        fieldList.push('edit');
      }

      this.optonsColumnsToDisplay = fieldList;
    });


  }

  stylise(text) {
    return '<h1 color=(\'black\')>' + text + '</h1>';
  }


}
