// angular
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

// models
import { Database } from './databases.model';

// services
import { AuditService } from '../audit/audit.service';

// misc
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const BACKEND_URL = environment.apiUrl  + '/database/';

const BULKUPLOAD_BACKEND_URL = environment.apiUrl  + '/bulkUpload/createDatabase';

@Injectable({providedIn: 'root'})

export class DbService {

  private databases: Database[] = [];
  private databasesUpdated = new Subject<{databases: Database[], databaseCount: Number}>();

  constructor(private http: HttpClient, private auditService: AuditService) {}

  migrateDb (databaseObj) {
    this.http.post<{message: string}>(BACKEND_URL + 'migrateDb/', databaseObj).subscribe();
  }

  getDatabaseUpdateListener() {
    return this.databasesUpdated.asObservable();
  }

  addDb(value: any) {
    return this.http.post<{messsage: string, database: Database}>(BACKEND_URL, value);
  }

  addBulkDb(value: any) {
    return this.http.post<{messsage: string, database: Database}>(BULKUPLOAD_BACKEND_URL, value);
  }

  updateDatabase(id: string, value: any) {
    let databaseData: Database | FormData;
    databaseData = new FormData();
    databaseData = {
      ...value,
      id: id,
      company_name: value.company_name,
    };

    return this.http.put(BACKEND_URL + id, databaseData);

  }

  deleteDatabase(id: string) {
    return this.http.delete(BACKEND_URL + id);
  }

  getDatabase(id: string) {
    return this.http.get<Database>(BACKEND_URL + id);
  }

  searchDatabase(
    company: string, hardwareId: string, searchParam: string,
    databasesPerPage: number, currentPage: number, sortType: string,
    pageChosen: string, compareDatabaseId: string
    ) {
    const queryParams = 
      `?pagesize=${databasesPerPage}&page=${currentPage}&company=${company}&hardware=${hardwareId}&sort=${sortType}&pageChosen=${pageChosen}&compareDatabaseId=${compareDatabaseId}`;
    this.http.get<{message: string, databases: Database[], maxDatabases: Number}>(BACKEND_URL + 'search/' + searchParam + '/' + queryParams)
    .pipe(map((databaseData) => {
      return { databases: databaseData.databases.map(database => {
            return {
              ...database,
              database_instance_name: database.database_instance_name,
           };
        }), maxDatabases: databaseData.maxDatabases
      };
    })).subscribe((transformedDatabaseData) => {
      this.databases = transformedDatabaseData.databases;
      this.databasesUpdated.next({databases: [...this.databases], databaseCount: transformedDatabaseData.maxDatabases});
    });

  }

}
