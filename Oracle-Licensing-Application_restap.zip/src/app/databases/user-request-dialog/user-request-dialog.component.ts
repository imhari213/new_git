// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSelectChange } from '@angular/material';
import { FormGroup } from '@angular/forms';

// services
import { HwService } from 'src/app/hardware/hardware.service';

@Component({
  selector: 'app-user-request-dialog',
  templateUrl: './user-request-dialog.component.html',
  styleUrls: ['./user-request-dialog.component.css']
})
export class UserRequestDialogComponent implements OnInit {
  databaseName: any;
  serverNameList: any;
  form: FormGroup;
  selectedServer: any;
  selectedSeverity: any;
  severityList: string[] = ['High', 'Moderate', 'Low'];
  selectedServerId: any;

  constructor(public dialogRef: MatDialogRef<UserRequestDialogComponent>,
    private hardwareService: HwService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.databaseName = this.data.database;
    this.getServerNameList();
  }

  setServerName(event: MatSelectChange) {
    this.selectedServer = event.value.server_name;
    this.selectedServerId = event.value._id;
  }

  getServerNameList() {
    this.hardwareService.getServerNameList(this.data.compId).subscribe(result => {
      this.serverNameList = result.serverNameList;
    });
  }

  sendRequest() {
    // email for production "SLS-GL@dataintensity.com"
    const requestObj = {
      contact: 'scmilne@dataintensity.com',
      server: this.selectedServer,
      severity: this.selectedSeverity,
      requestType: 'Migrate Database',
      hwId: this.selectedServerId
    };
    this.dialogRef.close(requestObj);
  }

}
