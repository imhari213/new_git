// angular
import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatBottomSheet} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';

// models
import { Options, Evidence } from '../databases.model';
import { OptionsInUse } from '../../config/config.model';

// services
import { ConfigService } from '../../config/config.service';
import { ThemeService } from '../../theme.service';

// misc
import { Subscription } from 'rxjs';
import { EvidenceBottomSheetComponent } from '../evidence-bottomsheet/evidence-bottomsheet.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-options-in-use-dialog',
  templateUrl: './options-in-use-dialog.component.html',
  styleUrls: ['./options-in-use-dialog.component.css'],
  providers: [
    ThemeService,
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ],
})

export class OptionsInUseDialogComponent implements OnInit, OnDestroy {

  form: FormGroup;
  mode = 'create';
  option: Options;
  optionsInUseList = [];
  evidence = <any>[];
  evidenceDataSource;
  selectedFieldsDefault: String[] = ['name', 'version', 'support status'];
  fieldList: String[] = ['usage', 'bugs', 'detected usages', 'total samples', 'currently used', 'aux count', 'feature information', 'last sample date', 'last sample period', 'sample interval', 'description', 'sys date'];
  // evidenceColumns: String[] = this.selectedFieldsDefault.concat('edit');
  evidenceColumns: String[];

  constructor(public dialogRef: MatDialogRef<OptionsInUseDialogComponent>, private config: ConfigService,
    private themeService: ThemeService, private bottomSheet: MatBottomSheet,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  private optionsInUseSub: Subscription;

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
    this.config.getOptionsInUse();
    this.optionsInUseSub = this.config.getOptionsInUseListener().subscribe((optionsInUseData: {optionInUse: OptionsInUse[]}) => {
        this.optionsInUseList = optionsInUseData.optionInUse;
      });
    this.createForm();

    if (this.data.option) { this.option = this.data.option; this.fillForm(); }
  }

  createForm() {
    this.form = new FormGroup({
      '_id': new FormControl(undefined),
      'option_in_use': new FormControl(null, {validators: [Validators.required]}),
      'host_name': new FormControl(null),
      'instance': new FormControl(null),
      'version': new FormControl(null),
      'support_status': new FormControl(null),
      'usage': new FormControl(null),
      'bugs': new FormControl(null),
      'detected_usages': new FormControl(null),
      'total_samples': new FormControl(null),
      'currently_used': new FormControl(null),
      'aux_count': new FormControl(null),
      'feature_information': new FormControl(null),
      'last_sample_date': new FormControl(null),
      'last_sample_period': new FormControl(null),
      'sample_interval': new FormControl(null),
      'description': new FormControl(null),
      'sys_date': new FormControl(null),
      'feature_mapped': new FormControl(null),
     // 'fields': new FormControl(null),
      'evidence': new FormControl(null),
      'comments': new FormControl(null),
      'location': new FormControl(null),
    });
  }

  fillForm() {
    this.form.patchValue(this.option);
    this.setTable(this.form.value.feature_mapped);
    if (this.option.evidence) {
      this.form.patchValue({location: this.option.evidence.location, comments: this.option.evidence.comments });
      switch (this.form.value.feature_mapped) {
        case ('Active Data Guard'):
          this.evidence = this.option.evidence.active_data_guard_ev;
          break;
        case ('Partitioning'):
          this.evidence = this.option.evidence.partition_ev;
          break;
        case ('Spatial and Graph'):
          this.evidence = this.option.evidence.spatial_ev;
          break;
        case ('OLAP'):
          this.evidence = this.option.evidence.olap_ev;
          break;
        case ('Advanced Compression'):
          this.evidence = this.option.evidence.advanced_comp_ev;
          break;
        case ('Multitnnant'):
          this.evidence = this.option.evidence.multitenant_ev;
          break;
        case ('Advanced Security'):
          this.evidence = this.option.evidence.advanced_security_ev;

      }
      this.evidenceDataSource = new MatTableDataSource(this.evidence);
    }

  }

  add() {
    if (this.form.value.feature_mapped) {
      switch (this.form.value.feature_mapped) {
        case 'Active Data Guard':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            active_data_guard_ev: this.evidence };
          this.dialogRef.close(this.form.value);
          break;
        case 'Partitioning':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            partition_ev: this.evidence };
          this.dialogRef.close(this.form.value);
          break;
        case 'Spatial and Graph':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            spatial_ev: this.evidence };
            this.dialogRef.close(this.form.value);
            break;
        case 'OLAP':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            olap_ev: this.evidence };
            this.dialogRef.close(this.form.value);
            break;
        case 'Advanced Compression':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            advanced_comp_ev: this.evidence };
            this.dialogRef.close(this.form.value);
            break;
        case 'Real Application Clusters':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            real_app_cluster_ev: this.evidence };
            this.dialogRef.close(this.form.value);
            break;
        case 'Multitenant':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            multitenant_ev: this.evidence };
            this.dialogRef.close(this.form.value);
            break;
        case 'Advanced Security':
          this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
            advanced_security_ev: this.evidence };
            this.dialogRef.close(this.form.value);
            break;
      }
    }

    this.form.removeControl('fields');
    this.dialogRef.close(this.form.value);
  }

  ngOnDestroy() {
    this.optionsInUseSub.unsubscribe();
  }

  setFields(value) {
    this.evidenceColumns = this.selectedFieldsDefault.concat(value).concat('edit');
  }

  addEvidence(mode, index) {

    let evidence = null;

    if (index !== null) { evidence = this.evidence[index]; }

    const bottomSheetRef = this.bottomSheet.open(EvidenceBottomSheetComponent, {
      disableClose: true,
      panelClass: ['evidence-width'],
      data: {mode: mode, evidence: evidence, feature: this.form.value.feature_mapped }
    });



    bottomSheetRef.afterDismissed().subscribe(newEvidence => {

      if (newEvidence) {
        if (mode === 'add') {
          try {
            this.evidence.push(newEvidence);
          } catch {
            this.evidence = [newEvidence];
          }
        }

        if (mode === 'edit') {
          this.evidence.splice(index, 1, newEvidence);
        }

        this.evidenceDataSource = new MatTableDataSource(this.evidence);
      }

    });

  }

  deleteEvidence(index) {
    this.evidence.splice(index, 1);
    this.evidenceDataSource = new MatTableDataSource(this.evidence);

  }

  setTable(feature) {
    this.evidence = [];
    this.evidenceDataSource = this.evidence;
    switch (feature) {
      case 'Active Data Guard':
        this.evidenceColumns = ['dest_id', 'dest_name', 'status', 'type', 'database_mode', 'recovery_mode', 'edit'];
        break;
      case 'Partitioning':
        this.evidenceColumns = ['owner', 'segment_type', 'segment_name', 'min_created', 'min_last_dll_time', 'edit'];
        break;
      case 'Spatial and Graph':
        this.evidenceColumns = ['sdo_geom_metadata_table', 'edit'];
        break;
      case 'OLAP':
        this.evidenceColumns = ['owner', 'aw_number', 'aw_name', 'pagespaces', 'generations', 'edit'];
        break;
      case 'Advanced Compression':
        this.evidenceColumns = ['version', 'name', 'currently_used', 'last_usage_date', 'last_sample_date', 'edit'];
        break;
      case 'Real Application Clusters':
        this.evidenceColumns = ['oracle_rac_installed', 'value', 'inst_id_status', 'edit'];
        break;
      case 'Multitenant':
        this.evidenceColumns = ['cbd', 'con_id_name', 'open_mode', 'open_time', 'container', 'edit'];
        break;
      case 'Advanced Security':
        this.evidenceColumns = ['tablespace_name', 'enc', 'edit'];
    }
  }

}
