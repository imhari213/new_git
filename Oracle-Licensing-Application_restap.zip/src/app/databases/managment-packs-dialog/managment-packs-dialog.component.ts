// angular
import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatBottomSheet} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';

// models
import { ManagementPack } from '../../config/config.model';
import { Managements, Evidence } from '../databases.model';

// services
import { ConfigService } from '../../config/config.service';
import { ThemeService } from '../../theme.service';

// misc
import { Subscription } from 'rxjs';
import { EvidenceBottomSheetComponent } from '../evidence-bottomsheet/evidence-bottomsheet.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-managment-packs-dialog',
  templateUrl: './managment-packs-dialog.component.html',
  styleUrls: ['./managment-packs-dialog.component.css'],
  providers: [ThemeService,
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ],
})

export class ManagmentPacksDialogComponent implements OnInit, OnDestroy {

  mode = 'create';
  form: FormGroup;
  management_pack;
  managements: Managements;
  managementPackList = [];
  evidence: Evidence[] = [];
  evidenceDataSource;
  fieldList: String[] = ['usage', 'bugs', 'detected usages', 'total samples', 'currently used', 'aux count', 'feature information', 'last sample date', 'last sample period', 'sample interval', 'description', 'sys date'];
  selectedFieldsDefault: String[] = ['name', 'created', 'last_modified', 'description', 'type', 'status'];
  evidenceColumns: String[] = this.selectedFieldsDefault.concat('edit');

  constructor(public dialogRef: MatDialogRef<ManagmentPacksDialogComponent>, private config: ConfigService,
    private themeService: ThemeService,   private bottomSheet: MatBottomSheet,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  private managementPackSub: Subscription;

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
    this.config.getManagementPacks();
    this.managementPackSub = this.config.getManagementPacksListener().subscribe((packData: {packs: ManagementPack[]}) => {
      this.managementPackList = packData.packs;
    });
    this.createForm();
    if (this.data.management_pack) { this.management_pack = this.data.management_pack; this.fillForm(); }
  }

  createForm() {
    this.form = new FormGroup({
      'management_in_use': new FormControl(null, {validators: [Validators.required]}),
      'evidence': new FormControl(null),
      'host_name': new FormControl(null),
      'instance': new FormControl(null),
      'version': new FormControl(null),
      'support_status': new FormControl(null),
      'usage': new FormControl(null),
      'bugs': new FormControl(null),
      'detected_usages': new FormControl(null),
      'total_samples': new FormControl(null),
      'currently_used': new FormControl(null),
      'aux_count': new FormControl(null),
      'feature_information': new FormControl(null),
      'last_sample_date': new FormControl(null),
      'last_sample_period': new FormControl(null),
      'sample_interval': new FormControl(null),
      'description': new FormControl(null),
      'sys_date': new FormControl(null),
      'comments': new FormControl(null),
      'location': new FormControl(null),
    });
  }

  fillForm() {

    this.form.patchValue(this.management_pack);
    if (this.management_pack.evidence) {
      this.form.patchValue({location: this.management_pack.evidence.location, comments: this.management_pack.evidence.comments });
      this.evidence = this.management_pack.evidence.management_ev;
      this.evidenceDataSource = new MatTableDataSource(this.evidence);
    }
    /*
    this.form.patchValue({
      '_id': this.management_pack._id,
      'management_in_use': this.management_pack.management_in_use,
      'host_name': this.management_pack.host_name,
      'instance': this.management_pack.instance
      /*
      'start_date': this.management_pack.start_date,
      'end_date': this.management_pack.end_date
      * /
    });
    */

  }

  ngOnDestroy() {
    this.managementPackSub.unsubscribe();
  }

  add () {

    this.form.patchValue({evidence: {location: this.form.value.location, comments: this.form.value.comments,
      management_ev: this.evidence } });
     // this.form.value.evidence = {location: this.form.value.location, comments: this.form.value.comments,
      //  management_ev: this.evidence };
    this.form.removeControl('fields');
    this.dialogRef.close(this.form.value);
  }

  setFields(value) {
    this.evidenceColumns = this.selectedFieldsDefault.concat(value).concat('edit');
  }

  addEvidence(mode, index) {

    let evidence = null;

    if (index !== null) { evidence = this.evidence[index]; }

    const bottomSheetRef = this.bottomSheet.open(EvidenceBottomSheetComponent, {
      disableClose: true,
      panelClass: ['evidence-width'],
      data: {mode: mode, evidence: evidence, feature: 'management' }
    });



    bottomSheetRef.afterDismissed().subscribe(newEvidence => {

      if (newEvidence) {
        if (mode === 'add') {
          try {
            this.evidence.push(newEvidence);
          } catch {
            this.evidence = [newEvidence];
          }
        }

        if (mode === 'edit') {
          this.evidence.splice(index, 1, newEvidence);
        }

        this.evidenceDataSource = new MatTableDataSource(this.evidence);
      }

    });

  }

  deleteEvidence(index) {
    this.evidence.splice(index, 1);
    this.evidenceDataSource = new MatTableDataSource(this.evidence);

  }

}
