// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';

// components
import { DatabaseCreateComponent } from '../databases/databases-create/databases-create.component';
import { DatabaseListComponent } from './database-list/database-list.component';
// import { OptionsInUseDialogComponent } from './options-in-use-dialog/options-in-use-dialog.component';
import { ManagmentPacksDialogComponent } from './managment-packs-dialog/managment-packs-dialog.component';
import { UserRequestDialogComponent } from './user-request-dialog/user-request-dialog.component';
import { EvidenceBottomSheetComponent } from './evidence-bottomsheet/evidence-bottomsheet.component';
import { FieldSelectionDialogComponent } from '../fieldSelectionDialog/field-selection.component';


@NgModule({
  declarations: [
    DatabaseCreateComponent,
    DatabaseListComponent,
    ManagmentPacksDialogComponent,
    UserRequestDialogComponent,
    EvidenceBottomSheetComponent,
    FieldSelectionDialogComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
  ],
  entryComponents: [ManagmentPacksDialogComponent, UserRequestDialogComponent, EvidenceBottomSheetComponent, FieldSelectionDialogComponent]
})

export class DbModule {}
