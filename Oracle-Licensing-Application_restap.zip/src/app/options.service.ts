// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

// misc
import { Subject } from 'rxjs';
import { environment } from '../environments/environment';

const USER_URL = environment.apiUrl  + '/user/';

let headerOptionSelected;

@Injectable()

export class OptionsService {

  constructor(private http: HttpClient) {}

  private _headersOn: Subject<boolean> = new Subject<boolean>();
  isHeadersOn = this._headersOn.asObservable();

  setHeaderOption(isHeadersOn: boolean) {
    this._headersOn.next(isHeadersOn);
    headerOptionSelected = isHeadersOn;
  }

  updateUserHeaderOption(form: any) {
    this.http.put<{message: string, user: any}>(USER_URL + '/updateUserHeaderOption/' + localStorage.getItem('userId'), form)
    .subscribe(result => {
      this.getUserHeaderOption();
    });
  }

  getUserHeaderOption() {
    this.http.get<{message: string, headers: any}>( USER_URL + '/getHeaderOption/' + localStorage.getItem('userId')).subscribe(response => {
      headerOptionSelected = response.headers;
      this.setHeaderOption(response.headers);
     });
  }

  headerOptionListener() {
    return this.isHeadersOn = this._headersOn.asObservable();
  }

  getHeaderOption() {
    return headerOptionSelected;
  }

}
