// angular
import { OnInit, Component, ViewChild, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource} from '@angular/material/table';
import { MatTable, MatDialog } from '@angular/material';

// models
import { ManagementPack, Currency, SupportStatus, EnviromentalUsage, ProductEdition, OptionsInUse } from '../config.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { ConfigService } from '../config.service';
import { OptionsService } from '../../../app/options.service';

// components
import { AddVariableOptionComponent } from '../add-variable-option-dialog/add-variable-option-dialog.component';
import { DeleteConfirmationComponent } from '../../deletePopUp/delete-confirmation-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-view-config',
  templateUrl: './view-config.component.html',
  styleUrls: ['./view-config.component.css']
})

export class ViewConfigComponent implements OnInit, OnDestroy {

  userIsAuthenticated = false;
  companyId: string;
  userRole = 'read';
  mode = 'create';
  checkedHeader;

  @ViewChild(MatTable) table: MatTable<any>;

  displayedColumnsSupportStatusList: String[] = ['Reference', 'Value', 'Edit'];
  dataSourceSupportStatusList: any;

  displayedColumnsCurrencyList: String[] = ['Country', 'Currency', 'Symbol', 'Edit'];
  dataSourceCurrencyList: any;

  displayedColumnsEnviromentUsageList: String[] = ['Type', 'Edit'];
  dataSourceEnviromentUsageList: any;

  displayedColumnsProductEditionList: String[] = ['Edition', 'Edit'];
  dataSourceProductEditionList: any;

  displayedColumnsOptionsInUseList: String[] = ['Option', 'Edit'];
  dataSourceOptionInUseList: any;

  displayedColumnsManagementPackList: String[] = ['Pack', 'Edit'];
  dataSourceManagementPackList: any;

  constructor(private authService: AuthService, private router: Router, private config: ConfigService,
     private dialog: MatDialog, private optionsService: OptionsService) {}

  private authStatusSub: Subscription;

  private supportStatusSub: Subscription;
  private currencySub: Subscription;

  private enviromentalUsageSub: Subscription;
  private productEditionSub: Subscription;
  private optionsInUseSub: Subscription;
  private managementpackSub: Subscription;

  ngOnInit() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService
        .getAuthStatusListener()
        .subscribe(isAuthenticated => {
          this.userIsAuthenticated = isAuthenticated;
          this.companyId = this.authService.getUserId();
          this.userRole = this.authService.getRole();
        });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    } else {
      // checks the users role
      this.optionsService.getUserHeaderOption();
      this.config.getEnviromentalUsages();
      this.enviromentalUsageSub = this.config.getEnviromentalUsagesListener()
      .subscribe((enviromentalUsageData: {enviromentalUsages: EnviromentalUsage[]}) => {
        this.dataSourceEnviromentUsageList = new MatTableDataSource(enviromentalUsageData.enviromentalUsages);
      });

      this.config.getProductEditions();
      this.productEditionSub = this.config.getProductEditionsListener()
      .subscribe((productEditionData: {productEditions: ProductEdition[]}) => {
        this.dataSourceProductEditionList = new MatTableDataSource(productEditionData.productEditions);
      });

      this.config.getOptionsInUse();
      this.optionsInUseSub = this.config.getOptionsInUseListener()
      .subscribe((optionsInUseData: {optionInUse: OptionsInUse[]}) => {
        this.dataSourceOptionInUseList = new MatTableDataSource(optionsInUseData.optionInUse);
      });

      this.config.getSupportStatus();
      this.SupportStatusListener();

      this.config.getCurrencies();
      this.currencySub = this.config.getCurrenciesListener().subscribe((currencyData: {currencies: Currency[]}) => {
        this.dataSourceCurrencyList = new MatTableDataSource(currencyData.currencies);
      });

      this.config.getManagementPacks();
      this.managementpackSub = this.config.getManagementPacksListener().subscribe((packData: {packs: ManagementPack[]}) => {
        this.dataSourceManagementPackList = new MatTableDataSource(packData.packs);
      });

      this.userRole = this.authService.getRole();
      // sets role to 'read' if useRole is undefined
      if (!this.userRole) {
        this.userRole = 'read';
      }
  }
}

  SupportStatusListener() {
    this.supportStatusSub = this.config.getSupportStatusListener().subscribe((supportStatusData: {supportStatuses: SupportStatus[]}) => {
      this.dataSourceSupportStatusList = new MatTableDataSource(supportStatusData.supportStatuses);
    });
  }

  addVariableOption(variableType: string) {

    if (this.mode === 'create') {
      const dialogRef = this.dialog.open(AddVariableOptionComponent, {
        disableClose: true,
        width: '30%',
        data: {
          type: variableType,
        }
      });

      dialogRef.afterClosed().subscribe( updateData => {

        if (!updateData.data) {
          return;
        } else {
          if (variableType.match('SupportStatus')) {
            this.config.addSupportStatus(updateData.data);
          }
          if (variableType.match('Currency')) {
            this.config.addCurrency(updateData.data);
          }
          if (variableType.match('EnviromentalUsage')) {
            this.config.addEnviromentalUsage(updateData.data);
          }
          if (variableType.match('ProductEdition')) {
            this.config.addProductEdition(updateData.data);
          }
          if (variableType.match('OptionInUse')) {
            this.config.addOptionInUse(updateData.data);
          }
          if (variableType.match('ManagementPack')) {
            this.config.addManagementPack(updateData.data);
          }
        }
      });
    }

  }

  deleteVariableOption(variableType: string, id: string, name: string) {

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '30%',
      data: {
        pageViewName: variableType,
        name: name,
      }
    });

    dialogRef.afterClosed().subscribe( result => {

      if (result.match('yes')) {
        if (variableType.match('SupportStatus')) {
          this.config.deleteSupportStatus(id);
        }
        if (variableType.match('Currency')) {
          this.config.deleteCurrency(id);
        }
        if (variableType.match('EnviromentalUsage')) {
          this.config.deleteEnviromentalUsage(id);
        }
        if (variableType.match('ProductEdition')) {
          this.config.deleteProductEdition(id);
        }
        if (variableType.match('OptionInUse')) {
          this.config.deleteOptionsInUse(id);
        }
        if (variableType.match('ManagementPack')) {
          this.config.deleteManagementPack(id);
        }
      } else {
        return;
      }
    });
  }

  getOptions() {
    this.checkedHeader = this.optionsService.getHeaderOption();
    return this.checkedHeader;
  }

  toggleHeaders() {
    this.checkedHeader = !this.checkedHeader;
    this.optionsService.setHeaderOption(this.checkedHeader);
    const form = {headers: this.checkedHeader};
    this.optionsService.updateUserHeaderOption(form);
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    this.supportStatusSub.unsubscribe();
    this.currencySub.unsubscribe();
    this.enviromentalUsageSub.unsubscribe();
    this.productEditionSub.unsubscribe();
    this.optionsInUseSub.unsubscribe();
    this.managementpackSub.unsubscribe();
  }

}
