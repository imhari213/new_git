// angular
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

// models
import { ManagementPack, Currency, SupportStatus, EnviromentalUsage, ProductEdition, OptionsInUse } from './config.model';

// misc
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const BACKEND_URL = environment.apiUrl  + '/config/';

@Injectable({providedIn: 'root'})
export class ConfigService {

  private currencies: Currency[] = [];
  private currenciesUpdated = new Subject<{currencies: Currency[]}>();

  private supportStatuses: SupportStatus[] = [];
  private supportStatusUpdated = new Subject<{supportStatuses: SupportStatus[]}>();

  private enviromentalUsages: EnviromentalUsage[] = [];
  private enviromentalUsagesUpdated = new Subject<{enviromentalUsages: EnviromentalUsage[]}>();

  private productEditions: ProductEdition[] = [];
  private productEditionsUpdated = new Subject<{productEditions: ProductEdition[]}>();

  private optionsInUse: OptionsInUse[] = [];
  private optionsInUseUpdated = new Subject<{optionInUse: OptionsInUse[]}>();

  private managementPacks: ManagementPack[] = [];
  private managementPacksUpdated = new Subject<{packs: ManagementPack[]}>();

  constructor(private http: HttpClient) {}

  // Contract Variables --------------------------------------------------------------------------------------------------

  getCurrencies() {
    this.http.get<{message: string, currency: any, maxCurrency: number}>(BACKEND_URL + 'currency')
    .pipe(map((currencyData) => {
      return { currency: currencyData.currency.map(currencies => {
         return currencies;
      }), maxCurrencies: currencyData.maxCurrency};
    })).subscribe((transformedData) => {
      this.currencies = transformedData.currency,
      this.currenciesUpdated.next({currencies: [...this.currencies]});
    });
  }

  getCurrenciesListener() {
    return this.currenciesUpdated.asObservable();
  }

  addCurrency(Value: any) {
    this.http.post<{messsage: string, currency: Currency}>(BACKEND_URL + 'currency', Value)
    .subscribe((responseData) => {
      console.log('Currency option added sucessfully!');
      this.getCurrencies();
    });
  }

  deleteCurrency(Id: string) {
    return this.http.delete(BACKEND_URL + 'currency/' + Id).subscribe((response) => {
      console.log('Currency option deleted sucessfully!');
      this.getCurrencies();
    });
  }

  getSupportStatus() {
    this.http.get<{message: string, supportStatus: any, maxSupportStatus: number}>(BACKEND_URL + 'supportStatus')
    .pipe(map((supportStatusData) => {
      return { supportStatus: supportStatusData.supportStatus.map(supportStatuses => {
         return supportStatuses;
      }), maxSupportStatus: supportStatusData.maxSupportStatus};
    })).subscribe((transformedData) => {
      this.supportStatuses = transformedData.supportStatus,
      this.supportStatusUpdated.next({supportStatuses: [...this.supportStatuses]});
    });
  }

  getSupportStatusListener() {
    return this.supportStatusUpdated.asObservable();
  }

  addSupportStatus(Value: any) {
    this.http.post<{messsage: string, supportStatus: SupportStatus}>(BACKEND_URL + 'supportStatus', Value)
    .subscribe((responseData) => {
      console.log('Support Status option added sucessfully!');
      this.getSupportStatus();
    });
  }

  deleteSupportStatus(Id: string) {
    return this.http.delete(BACKEND_URL + 'supportStatus/' + Id).subscribe((response) => {
      console.log('Support Status option deleted sucessfully!');
      this.getSupportStatus();
    });
  }

  // Database Variables --------------------------------------------------------------------------------------------------

  getEnviromentalUsages() {
    this.http.get<{message: string, enviromentalUsages: any, maxEnviromentalUsages: number}>(BACKEND_URL + 'enviromentalUsage')
    .pipe(map((enviromentalUsageData) => {
      return { enviromentalUsage: enviromentalUsageData.enviromentalUsages.map(enviromentalUsages => {
         return enviromentalUsages;
      }), maxEnviromentalUsages: enviromentalUsageData.maxEnviromentalUsages};
    })).subscribe((transformedData) => {
      this.enviromentalUsages = transformedData.enviromentalUsage,
      this.enviromentalUsagesUpdated.next({enviromentalUsages: [...this.enviromentalUsages]});
    });
  }

  getEnviromentalUsagesListener() {
    return this.enviromentalUsagesUpdated.asObservable();
  }

  addEnviromentalUsage(Value: any) {
    this.http.post<{messsage: string, enviromentalUsage: EnviromentalUsage}>(BACKEND_URL + 'enviromentalUsage', Value)
    .subscribe((responseData) => {
      console.log('Enviromental Usages option added sucessfully!');
      this.getEnviromentalUsages();
    });
  }

  deleteEnviromentalUsage(Id: string) {
    return this.http.delete(BACKEND_URL + 'enviromentalUsage/' + Id).subscribe((response) => {
      console.log('Enviromental Usages option deleted sucessfully!');
      this.getEnviromentalUsages();
    });
  }

  getProductEditions() {
    this.http.get<{message: string, productEditions: any, maxProductEditions: number}>(BACKEND_URL + 'productEdition')
    .pipe(map((productEditionsData) => {
      return { productEditions: productEditionsData.productEditions.map(productEditions => {
         return productEditions;
      }), maxProductEditions: productEditionsData.maxProductEditions};
    })).subscribe((transformedData) => {
      this.productEditions = transformedData.productEditions,
      this.productEditionsUpdated.next({productEditions: [...this.productEditions]});
    });
  }

  getProductEditionsListener() {
    return this.productEditionsUpdated.asObservable();
  }

  addProductEdition(Value: any) {
    this.http.post<{messsage: string, productEdition: ProductEdition}>(BACKEND_URL + 'productEdition', Value)
    .subscribe((responseData) => {
      console.log('Product Edition option added sucessfully!');
      this.getProductEditions();
    });
  }

  deleteProductEdition(Id: string) {
    return this.http.delete(BACKEND_URL + 'productEdition/' + Id).subscribe((response) => {
      console.log('Product Edition option deleted sucessfully!');
      this.getProductEditions();
    });
  }

  getOptionsInUse() {
    this.http.get<{message: string, optionsInUse: any, maxOptions: number}>(BACKEND_URL + 'optionsInUse')
    .pipe(map((optionsInUseData) => {
      return { optionsInUse: optionsInUseData.optionsInUse.map(optionsInUse => {
         return optionsInUse;
      }), maxOptions: optionsInUseData.maxOptions};
    })).subscribe((transformedData) => {
      this.optionsInUse = transformedData.optionsInUse,
      this.optionsInUseUpdated.next({optionInUse: [...this.optionsInUse]});
    });
  }

  getOptionsInUseListener() {
    return this.optionsInUseUpdated.asObservable();
  }

  addOptionInUse(Value: any) {
    this.http.post<{messsage: string, optionInUse: OptionsInUse}>(BACKEND_URL + 'optionsInUse', Value)
    .subscribe((responseData) => {
      console.log('Option In Use option added sucessfully!');
      this.getOptionsInUse();
    });
  }

  deleteOptionsInUse(Id: string) {
    return this.http.delete(BACKEND_URL + 'optionsInUse/' + Id).subscribe((response) => {
      console.log('Option In Use option deleted sucessfully!');
      this.getOptionsInUse();
    });
  }

  getManagementPacks() {
    this.http.get<{message: string, managementPacks: any, maxPacks: number}>(BACKEND_URL + 'managementPacks')
    .pipe(map((managementPackData) => {
      return { managementPacks: managementPackData.managementPacks.map(managementpacks => {
         return managementpacks;
      }), maxPacks: managementPackData.maxPacks};
    })).subscribe((transformedData) => {
      this.managementPacks = transformedData.managementPacks,
      this.managementPacksUpdated.next({packs: [...this.managementPacks]});
    });
  }

  getManagementPacksListener() {
    return this.managementPacksUpdated.asObservable();
  }

  addManagementPack(Value: any) {
    this.http.post<{messsage: string, managementPack: ManagementPack}>(BACKEND_URL + 'managementPacks', Value)
    .subscribe((responseData) => {
      console.log('Management pack option added sucessfully!');
      this.getManagementPacks();
    });
  }

  deleteManagementPack(Id: string) {
    return this.http.delete(BACKEND_URL + 'managementPacks/' + Id).subscribe((response) => {
      console.log('Management pack option deleted sucessfully!');
      this.getManagementPacks();
    });
  }

}
