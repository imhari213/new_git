// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource, MatDialog } from '@angular/material';

// models
import { Company } from 'src/app/companies/company.model';
import { AuthData } from '../../auth/auth-data.model';

// services
import { AuthService } from '../../auth/auth.service';
import { CompanyService } from 'src/app/companies/companies.service';

// components
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { MasterEditComponent } from '../master-edit-dialog/master-edit.component';
import { ConfirmationEmailDialogComponent } from '../confirmation-email-dialog/confirmation-email-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})

export class UserListComponent implements OnInit, OnDestroy {

  constructor(private authService: AuthService, private router: Router, private companyService: CompanyService,
              private dialog: MatDialog) {}

  userIsAuthenticated: Boolean;
  userRole = 'read';
  userId;
  isLoading = false;

  companies: Company[];
  users;

  filterListValues = ['', ''];
  filteredByEmail: AuthData[];

  dataSourceUsers: any;
  displayedColumnsUsers = ['Company', 'Email', 'Role', 'Password', 'Edit'];

  authStatusSub: Subscription;
  companySub: Subscription;
  usersSub: Subscription;

  ngOnInit() {
    this.getAuth();
    this.isLoading = true;
    this.getUsers();
    this.getCompanies();
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
  }

  getUsers() {
    this.authService.getAllUsers();
    this.usersSub = this.authService.getAllUsersListener()
    .subscribe(userData => {
      const users = userData.users;
      for (let i = 0; i < users.length; ++i) {
        if (!users[i].company) { users[i].company = ''; }
        if (!users[i].role) { users[i].role = ''; }
      }
      this.userId = this.authService.getUserId();
      this.users = users;
      this.filteredByEmail = this.users;
      this.filterList(null, null);
      this.isLoading = false;
    });
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
        this.companies = companyData.companies;
      });
  }

  getCompName(compId) {
    try {
      return this.companies.find(comp => comp._id === compId).company_name;
    } catch {
      return compId;
    }
  }

  editUserDialog(element) {

    const dialogRef = this.dialog.open(MasterEditComponent, {
      width: '30%',
      disableClose: true,
      data: {user: element}
    });

    dialogRef.afterClosed().subscribe(() => {
      this.getUsers();
    });
  }

  deleteUserDialog(element) {
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: element.email, pageViewName: 'user'}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.authService.deleteUser(element._id).subscribe( () => { this.getUsers(); });
      } else {
        console.log('Nothing was deleted');
      }
    });
  }

  filterList(type: string, value: string) {
    if (type === 'company') {
      if (!value) { this.filterListValues[0] = ''; } else { this.filterListValues[0] = value; }
    }
    if (type === 'role') {
      if (!value) { this.filterListValues[1] = ''; } else { this.filterListValues[1] = value; }
    }

    const filteredUsers = this.users.filter(user => {
      if (user.company.includes(this.filterListValues[0]) && user.role.includes(this.filterListValues[1])) {
        return true;
      } else {
        return false;
      }
    });
    this.dataSourceUsers = new MatTableDataSource(filteredUsers);
  }

  filterByEmail(value: string) {
    const filtered = this.users.filter(user => user.email.includes(value));
    this.dataSourceUsers = new MatTableDataSource(filtered);
  }

  resetPassword(email: string) {
    this.authService.sendingEmail(email);
    this.dialog.open(ConfirmationEmailDialogComponent, {
      data: {email: email}
    });
  }

  ngOnDestroy() {
    if (this.usersSub) {
      this.usersSub.unsubscribe();
    }
    if (this.companySub) {
      this.companySub.unsubscribe();
    }
    if (this.authStatusSub) {
      this.authStatusSub.unsubscribe();
    }
  }
}
