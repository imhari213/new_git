// angular
import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// model
import { Company } from 'src/app/companies/company.model';

// services
import { CompanyService } from 'src/app/companies/companies.service';
import { AuthService } from '../../auth/auth.service';
import { ThemeService } from '../../theme.service';

// misc
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './master-edit.component.html',
  styleUrls: ['./master-edit.component.css'],
  providers: [ThemeService]
})

export class MasterEditComponent implements OnInit, OnDestroy {

  constructor(public dialogRef: MatDialogRef<MasterEditComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
              private companyService: CompanyService, private authService: AuthService, private dialog: MatDialog,
              private themeService: ThemeService) {}

  form: FormGroup;
  user;
  companies: Company[];
  checked = false;

  companySub: Subscription;

  roleList = ['admin', 'write', 'read'];

  ngOnInit() {
    this.user = this.data.user;
    if (localStorage.getItem('role') === 'master') {
      this.roleList = ['master'].concat(this.roleList);
    }
    this.getCompanies();
    this.createForm();
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
  }

  createForm() {
    this.form = new FormGroup({
      '_id': new FormControl (this.user._id
      ),
      'email': new FormControl (this.user.email, {validators: [Validators.required]
      }),
      'password': new FormControl (null, {validators: [Validators.required]
      }),
      'role': new FormControl(this.user.role, {validators: [Validators.required]
      }),
      'company': new FormControl (this.user.company
      )
    });
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
        this.companies = companyData.companies;
      });
  }

  updateUser() {
    if (this.form.value.company === '') { this.form.patchValue({company: null}); }
    if (this.checked === false) { this.form.patchValue({password: this.user.password}); }
    this.authService.updateMasterUser({user: this.form.value, newpassword: this.checked}).subscribe(() => {
      this.dialogRef.close();
    });
  }

  checkbox(event) {
    this.checked = event.checked;
  }

  ngOnDestroy() {
    this.companySub.unsubscribe();
  }

}
