// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// services
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-add-variable-option-dialog',
  templateUrl: './add-variable-option-dialog.component.html',
  styleUrls: ['./add-variable-option-dialog.component.css'],
  providers: [ThemeService]
})
export class AddVariableOptionComponent implements OnInit {

  form: FormGroup;
  mode = 'create';

  variableType;

  constructor(public dialogRef: MatDialogRef<AddVariableOptionComponent>,
    private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {

    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }

    this.variableType = this.data.type;

    if (this.variableType === 'SupportStatus') { this.setSupportStatus(); }
    if (this.variableType === 'Currency') { this.setCurrency(); }
    if (this.variableType === 'EnviromentalUsage') { this.setEnviromentalUsage(); }
    if (this.variableType === 'ProductEdition') { this.setProductEdition(); }
    if (this.variableType === 'OptionInUse') { this.setOptionInUse(); }
    if (this.variableType === 'ManagementPack') { this.setManagementPack(); }

  }

  setSupportStatus() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'reference': new FormControl(null, {validators: [Validators.required]
      }),
      'value': new FormControl(null, {validators: [Validators.required]
      }),
    });
  }

  setCurrency() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'country': new FormControl(null, {validators: [Validators.required]
      }),
      'currency': new FormControl(null, {validators: [Validators.required]
      }),
      'symbol': new FormControl(null, {validators: [Validators.required]
      }),
    });
  }

  setEnviromentalUsage() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'type': new FormControl(null, {validators: [Validators.required]
      }),
    });
  }

  setProductEdition() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'edition': new FormControl(null, {validators: [Validators.required]
      }),
    });
  }

  setOptionInUse() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'option': new FormControl(null, {validators: [Validators.required]
      }),
    });
  }

  setManagementPack() {
    this.form = new FormGroup({
      '_id': new FormControl(null
      ),
      'pack': new FormControl(null, {validators: [Validators.required]
      }),
    });
  }

  add() {
    this.dialogRef.close({data: this.form.value});
  }

}
