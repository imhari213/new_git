// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  templateUrl: './confirmation-email-dialog.component.html',
  styleUrls: ['./confirmation-email-dialog.component.css']
})

export class ConfirmationEmailDialogComponent implements OnInit {

  email: string;

  constructor(public dialogRef: MatDialogRef<ConfirmationEmailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {
    this.email = this.data.email;
  }

}
