export interface Config {
  support_status: [SupportStatus];
  currency: [Currency];
  enviromental_usage: [EnviromentalUsage];
  product_edition: [ProductEdition];
  option_in_use: [OptionsInUse];
  management_pack: [ManagementPack];
}

export interface SupportStatus {
  reference: number;
  value: string;
}

export interface Currency {
  country: string;
  currency: string;
  symbol: string;
}

export interface EnviromentalUsage {
  type: string;
}

export interface ProductEdition {
  edition: string;
}

export interface OptionsInUse {
  option: string;
}

export interface ManagementPack {
  pack: string;
}
