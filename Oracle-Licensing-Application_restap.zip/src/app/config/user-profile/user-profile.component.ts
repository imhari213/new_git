// angular
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';

// services
import { AuthService } from '../../auth/auth.service';
import { ThemeService } from '../../theme.service';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  form: FormGroup;
  userIsAuthenticated: any;
  isLoading: boolean;
  user: any;
  hide = true;

  constructor(public authService: AuthService, private router: Router,
     private themeService: ThemeService, private _snackBar: MatSnackBar) { }

  authStatusSub: any;
  updateUserPasswordSub: any;

  ngOnInit() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.authStatusSub = this.authService.getAuthStatusListener().subscribe(
      authStatus => {
        this.isLoading = false;
      }
    );

    const localStorageRole = localStorage.getItem('role');

    this.user = {
      email: localStorage.getItem('email'),
      role: localStorageRole.charAt(0).toUpperCase() + localStorageRole.slice(1),
      company: localStorage.getItem('name'),
      nightmode: this.themeService.getThemeSelected()
    };

    if (this.user.company === 'undefined') {
      this.user.company = 'N/A';
    }

    this.form = new FormGroup({
      '_id': new FormControl(null),
      'new_email': new FormControl(null, {validators: [Validators.email, Validators.required]}),
      'current_password': new FormControl(null, {validators: Validators.required}),
      'new_password': new FormControl(null, {validators: Validators.required}),
      'confirm_password': new FormControl(null, {validators: Validators.required}),
    }, {validators: [this.checkPasswords, Validators.minLength(3)]});

    this.form.patchValue({new_email: this.user.email});
    this.form.patchValue({_id: this.authService.getUserId()});

    this.updateUserPasswordSub = this.authService.getUserUpdateProfileListener().subscribe(update => {
      if (update === true) {
        this.openSnackBar('Password Updated for ', this.form.get('new_email').value);
        this.form.reset();
      }
    });

  }

  checkPasswords(form: FormGroup) {
  const pass = form.get('new_password').value;
  const confirmPass = form.get('confirm_password').value;

  if (pass === null || pass !== confirmPass) {
    return {invalid: true };
  }
 }

  confirmChanges() {
    // check old passsword matches then forward change request
    this.authService.updateUserProfilePassword(this.form.value);
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
    });
  }

}
