// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';

// components
import { ViewConfigComponent } from './view-config/view-config.component';
import { AddVariableOptionComponent } from './add-variable-option-dialog/add-variable-option-dialog.component';
import { ConfirmationEmailDialogComponent } from './confirmation-email-dialog/confirmation-email-dialog.component';
import { MasterEditComponent } from './master-edit-dialog/master-edit.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

@NgModule({
  declarations: [
    ViewConfigComponent,
    AddVariableOptionComponent,
    ConfirmationEmailDialogComponent,
    MasterEditComponent,
    UserListComponent,
    UserProfileComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule
  ],
  entryComponents: [
    AddVariableOptionComponent,
    ConfirmationEmailDialogComponent,
    MasterEditComponent
  ]
})

export class ConfigModule {}
