// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';

// models
import { DataCenter } from '../vcenter.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-data-center-dialog',
  templateUrl: './data-center-dialog.component.html',
  styleUrls: ['./data-center-dialog.component.css'],
  providers: [ThemeService]
})

export class DataCenterComponent implements OnInit {

  form: FormGroup;
  mode = 'create';
  dataCenter: DataCenter;

  constructor(public dialogRef: MatDialogRef<DataCenterComponent>,
    private themeService: ThemeService,
    private authService: AuthService, @Inject(MAT_DIALOG_DATA) public data: any) {}

    ngOnInit() {
      this.authService.autoAuthUser();

      if (this.themeService.getThemeSelected() === true ) {
        this.dialogRef.addPanelClass('dark-theme');
      }

      this.dataCenter = this.data.dataCenter;

      this.form = new FormGroup({
        'data_center': new FormControl(null
          ),
      });

      if (this.dataCenter) {
        this.mode = 'edit';
        this.form.patchValue({'data_center': this.dataCenter.data_center});
      }
    }

  add() {

    if (this.mode === 'edit') {
      this.dataCenter.data_center = this.form.value.data_center;
    } else {
      this.dataCenter = {'data_center': this.form.value.data_center, 'clusters': null};
    }
    this.dialogRef.close({data: this.dataCenter});
  }

}
