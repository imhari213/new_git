// angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from '../angular-material.module';

// components
import { VcenterCreateComponent } from './vcenter-create/vcenter-create.component';
import { VcenterListComponent } from './vcenter-list/vcenter-list.component';
import { DataCenterComponent } from './data-center-dialog/data-center-dialog.component';
import { ClusterComponent } from './cluster-dialog/cluster-dialog.component';

@NgModule({
  declarations: [
    VcenterCreateComponent,
    VcenterListComponent,
    DataCenterComponent,
    ClusterComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
  ],
  entryComponents: [DataCenterComponent, ClusterComponent]
})

export class VCenterModule {}
