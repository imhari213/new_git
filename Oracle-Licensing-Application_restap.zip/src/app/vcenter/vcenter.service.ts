// angular
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

// models
import { VCenter } from './vcenter.model';

// services
import { AuditService } from '../audit/audit.service';

// misc
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const BACKEND_URL = environment.apiUrl  + '/vcenter/';
@Injectable({providedIn: 'root'})

export class VCenterService {

  constructor(private http: HttpClient, private router: Router, private auditService: AuditService) {}

  private vcenters: VCenter[] = [];

  private vCentersUpdated = new Subject<{vcenters: VCenter[], vcenterCount: Number}>();

  addVCenter(value: VCenter) {
    this.http.post<{message: string, vCenter: any}>(BACKEND_URL, value)
    .subscribe((responseData) => {
      this.auditService.addAudit('vcenter', responseData.vCenter._id, 'add', responseData.vCenter.server_name, null, null, null);
      this.router.navigate(['list-vcenter']);
    });
  }

  updateVcenter(value: VCenter) {
    return this.http.put<{message: string, vcenter: VCenter}>(BACKEND_URL + value._id, value);
  }

  getVCenters(searchParam, companyId, perPage, currentPage) {
    const queryParams = `?pagesize=${perPage}&page=${currentPage}&company=${companyId}`;
    this.http.get<{message: string, vcenters: any, maxVCenters: number}>
    (BACKEND_URL + 'search/' + searchParam  + queryParams).pipe(map((vcenterData) => {
      return { vcenters: vcenterData.vcenters.map(vcenter => {
        return vcenter;
      }), maxVCenters: vcenterData.maxVCenters};
    })).subscribe((transformedData) => {
      this.vcenters = transformedData.vcenters;
      this.vCentersUpdated.next({vcenters: [...this.vcenters], vcenterCount: transformedData.maxVCenters});
    });
  }

  getVCenterUpdateListener() {
    return this.vCentersUpdated.asObservable();
  }

  // gets once vc using the id from that vcenter, used for edit create
  getVC(vcId) {
    return this.http.get<{message: string, vcenter: VCenter}>(BACKEND_URL + vcId);
  }

  deleteVCenter(vcId) {
    return this.http.delete<{message: string}>(BACKEND_URL + 'vcenter/' + vcId);
  }

}
