// angular
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router, ParamMap, ActivatedRoute } from '@angular/router';
import { MatTable, MatTableDataSource, MatTabGroup, MatTabChangeEvent, PageEvent, MatDialog } from '@angular/material';

// models
import { Company } from 'src/app/companies/company.model';
import { Hardware } from 'src/app/hardware/hardware.model';
import { Cluster, DataCenter, VCenter } from '../vcenter.model';

// services
import { CompanyService } from 'src/app/companies/companies.service';
import { VCenterService } from './../vcenter.service';
import { HwService } from 'src/app/hardware/hardware.service';
import { AuthService } from 'src/app/auth/auth.service';
import { AuditService } from 'src/app/audit/audit.service';
import { OptionsService } from '../../options.service';

// components
import { DataCenterComponent } from '../data-center-dialog/data-center-dialog.component';
import { ClusterComponent } from '../cluster-dialog/cluster-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-vcenter-list',
  templateUrl: './vcenter-list.component.html',
  styleUrls: ['./vcenter-list.component.css']
})

export class VcenterListComponent implements OnInit, OnDestroy {

  userIsAuthenticated: boolean;
  userRole = 'read';
  searchParam;
  isLoading = false;

  vcenter: VCenter;

  vcenters: VCenter[];
  companies: Company[];
  hardwares: Hardware[];

  vcentersPerPage = 10;
  currentPage = 1;
  vcenterCount: Number = 0;
  pageSizeOptions = [10, 20, 50];

  companyId;
  allClusters: Cluster[];
  clusters: Cluster[];
  dataCenters = <any>[];
  currentDataCenter: DataCenter;

  dataSourceDataCenters: any;
  displayedColumnsDataCenters: string[] = ['dataCenter', 'clusters', 'add'];
  dataSourceClusters: any;
  displayedColumnsClusters: string[] = ['cluster', 'hardware', 'add', ];

  selectedIndex = 0;
  checkedHeader;

  authStatusSub: Subscription;
  vcenterSub: Subscription;
  companySub: Subscription;
  hardwareSub: Subscription;
  headerOptionSub: Subscription;

  @ViewChild('dataCenterTable') dataCenterTable: MatTable<any>;
  @ViewChild('clusterTable') clusterTable: MatTable<any>;
  @ViewChild('tabs') tabGroup: MatTabGroup;

  constructor(private authService: AuthService, private router: Router, private vcenterService: VCenterService,
              private companyService: CompanyService, private route: ActivatedRoute, private hardwareService: HwService,
              private dialog: MatDialog, private auditService: AuditService, private optionsService: OptionsService) {}

  ngOnInit() {
    this.getAuth();

    if (localStorage.getItem('compId') !== 'null')  {this.companyId = localStorage.getItem('compId'); }
    this.isLoading = true;

    this.route.paramMap.subscribe(paramMap => {
      if (paramMap.has('companyId')) { this.companyId = paramMap.get('companyId'); }

      this.getVCenters();
      this.getCompanies();
      this.getHardwares();
      this.checkedHeader = this.optionsService.getHeaderOption();
      this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
      });
    });
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });

    this.authService.autoAuthUser();
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }

    if (this.userRole === 'read') {
      this.displayedColumnsDataCenters = ['dataCenter', 'clusters'];
    }

  }

  getVCenters() {

    this.vcenterService.getVCenters(this.searchParam, this.companyId, this.vcentersPerPage, this.currentPage);
    this.vcenterSub = this.vcenterService.getVCenterUpdateListener()
    .subscribe((vcenterData: {vcenters: VCenter[], vcenterCount: Number}) => {
      this.vcenters = vcenterData.vcenters;
      this.vcenterCount = vcenterData.vcenterCount;
      this.isLoading = false;
    });
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[], companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  getHardwares() {
    this.hardwareService.getHardwares(null, null);
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
    .subscribe((hardwareData: {hardwares: Hardware[], hardwareCount: Number}) => {
      this.hardwares = hardwareData.hardwares;
    });
  }

  getCompanyName(companyId) {
    let companyName = companyId;
    try { companyName = this.companies.find(comp => comp._id === companyId).company_name; } catch {}
    return companyName;
  }

  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    this.vcentersPerPage = pageData.pageSize;
    this.getVCenters();
  }

  getData(vcenter) {

    this.vcenter = vcenter;
    this.dataCenters = vcenter.dataCenters;

    this.dataSourceDataCenters = new MatTableDataSource(this.dataCenters);

    this.allClusters = [];
    this.dataCenters.forEach(dc => {
      if (dc.clusters) {
        this.allClusters = this.allClusters.concat(dc.clusters);
      }

    });
    this.clusters = this.allClusters;
    this.dataSourceClusters = new MatTableDataSource(this.clusters);

  }

  changeTab(event) {
    this.selectedIndex = event.index;
  }

  selectDC(element) {
    this.currentDataCenter = element;
    this.clusters = element.clusters;
    this.dataSourceClusters = new MatTableDataSource(this.clusters);
    this.selectedIndex = 2;
  }

  countHw(element) {
    const clusterId = element._id;
    const relatedHwlength = this.hardwares.filter(hw => hw.cluster_id === clusterId).length;
    return relatedHwlength;
  }

  hardwaresByClusters(element) {
    localStorage.setItem('clusterId', element._id);
    localStorage.setItem('compId', this.vcenter.company);
    this.router.navigate(['/list-hardware/']);
  }

  editDataCenter(element) {
    let index;

    if (element) { index = this.dataCenters.indexOf(element); }

    const dialogRef = this.dialog.open(DataCenterComponent, {
      disableClose: true,
      width: '50%',
      data: {dataCenter: element}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        const data = updateData.data;
        if (element) {
          this.vcenter.dataCenters[index] = data;
        } else {
          this.vcenter.dataCenters.push(data);
        }

        this.vcenterService.updateVcenter(this.vcenter).subscribe(response => {
          this.vcenterService.getVC(this.vcenter._id).subscribe(vc => {
            this.vcenter = vc.vcenter;
            this.getData(this.vcenter);
          });
        });
      } else {
        console.log('closed');
      }
    });


  }

  editCluster(element) {
    let index;
    if (element) { index = this.clusters.indexOf(element); }

    let currentDC;

    if  (this.currentDataCenter) {
      currentDC = this.currentDataCenter;
    } else {
      currentDC = this.dataCenters.find(dc => dc.clusters.includes(element));
    }

    const dialogRef = this.dialog.open(ClusterComponent, {
      disableClose: true,
      width: '50%',
      data: {dataCenters: this.dataCenters, currentDataCenter: currentDC, cluster: element}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        const data = updateData.data;
        const dcIndex = this.dataCenters.indexOf(data.selectedDC);
        const clusterObj = {_id: undefined, cluster: data.cluster};
        if (element) {
          const clusterIndex = this.dataCenters[dcIndex].clusters.indexOf(element);
          clusterObj._id = element._id;
          this.dataCenters[dcIndex].clusters[clusterIndex] = clusterObj;
        } else {
          this.dataCenters[dcIndex].clusters.push(clusterObj);
        }

        this.vcenter.dataCenters = this.dataCenters;

        this.vcenterService.updateVcenter(this.vcenter).subscribe(response => {
          this.vcenterService.getVC(this.vcenter._id).subscribe(vc => {
            this.vcenter = vc.vcenter;
            this.getData(this.vcenter);
            if (this.currentDataCenter) {
              this.selectDC(this.vcenter.dataCenters[dcIndex]);
            }
          });
        });


      } else {
        console.log('closed');
      }
    });
  }

  backToCompanies() {
    if (this.companyId) {
      const compName = this.companies.find(comp => comp._id === this.companyId).company_name;
      this.router.navigate(['/company-details/' + compName]);
    } else {
      this.router.navigate(['list-company']);
    }
  }

  backToContracts() {
    this.router.navigate(['/list-contract']);
  }

  addVCenter() {
    if (this.companyId) {
      this.router.navigate(['/add-vcenter/' + this.companyId]);
    } else {
      this.router.navigate(['/add-vcenter']);
    }
  }

  deleteVCenter(event: Event, vcenter) {
    event.stopPropagation();
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'VCenter', name: vcenter.vcenter_server_name }
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.vcenterService.deleteVCenter(vcenter._id).subscribe(response => {
          this.auditService.addAudit('vcenter', vcenter._id, 'delete', vcenter.vcenter_server_nam, null, null, null);
          this.getVCenters();
        });
      }
    });
  }

  deleteCluster(element) {
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'cluster', name: element.cluster }
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        const dataCenter = this.vcenter.dataCenters.find(dc => dc.clusters.includes(element));
        const cl_index = dataCenter.clusters.indexOf(element);
        dataCenter.clusters.splice(cl_index, 1);
        this.vcenterService.updateVcenter(this.vcenter).subscribe(response => {
          this.vcenterService.getVC(this.vcenter._id).subscribe(vc => {
            this.getData(vc.vcenter);
          });
        });

      }
    });
  }

  onSearch(toSearch: string) {
    if (toSearch === '') { this.searchParam = undefined; } else { this.searchParam = toSearch; }
    this.getVCenters();
  }

  deleteDataCenter(element) {
    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      disableClose: true,
      width: '50%',
      data: { pageViewName: 'data center', name: element.data_center }
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        const index = this.vcenter.dataCenters.indexOf(element);
        this.vcenter.dataCenters.splice(index, 1);
        this.vcenterService.updateVcenter(this.vcenter).subscribe(response => {
          this.vcenterService.getVC(this.vcenter._id).subscribe(vc => {
            this.getData(vc.vcenter);
          });
        });
      }
    });
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    this.vcenterSub.unsubscribe();
    this.companySub.unsubscribe();
    this.hardwareSub.unsubscribe();
  }

}
