// angular
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ParamMap, ActivatedRoute } from '@angular/router';
import { MatTable, MatTableDataSource, MatDialog } from '@angular/material';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// models
import { Company } from 'src/app/companies/company.model';
import { DataCenter, VCenter } from '../vcenter.model';

// services
import { CompanyService } from 'src/app/companies/companies.service';
import { VCenterService } from './../vcenter.service';
import { AuthService } from 'src/app/auth/auth.service';

// components
import { DataCenterComponent } from '../data-center-dialog/data-center-dialog.component';
import { ClusterComponent } from '../cluster-dialog/cluster-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-vcenter-create',
  templateUrl: './vcenter-create.component.html',
  styleUrls: ['./vcenter-create.component.css'],
  providers: [{provide: STEPPER_GLOBAL_OPTIONS,
    useValue: { displayDefaultIndicatorType: false }}]
})
export class VcenterCreateComponent implements OnInit {

  form: FormGroup;
  userIsAuthenticated: boolean;
  userRole = 'read';
  mode = 'create';

  companyId;
  companies: Company[];
  vcenterId;
  vcenter: VCenter;
  dataCenters = <any>[];
  currentDataCenter: DataCenter;
  allClusters = <any>[];
  clusters = <any>[];

  dataSourceDataCenters;
  displayedColumnsDataCenters: string[] = ['dataCenter', 'clusters', 'add'];
  dataSourceClusters;
  displayedColumnsClusters: string[] = ['cluster', 'add'];

  authStatusSub: Subscription;
  companySub: Subscription;

  @ViewChild('dataCenterTable') dataCenterTable: MatTable<any>;
  @ViewChild('clusterTable') clusterTable: MatTable<any>;

  constructor(private route: ActivatedRoute, private authService: AuthService, private router: Router,
              private companyService: CompanyService, private vcenterService: VCenterService,
              private dialog: MatDialog) {}


  ngOnInit() {

    this.getAuth();
    this.createForm();

    if (localStorage.getItem('compId') !== 'null') {
      this.companyId = localStorage.getItem('compId');
      this.form.patchValue({company: this.companyId});
    }

    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('companyId')) {
        this.companyId = paramMap.get('companyId');
        this.form.patchValue({company: this.companyId});
      }
      if (paramMap.has('vcenterId')) {
        this.mode = 'edit';
        this.vcenterId = paramMap.get('vcenterId');
        this.vcenterService.getVC(this.vcenterId).subscribe(vc => {this.vcenter = vc.vcenter; this.fillForm(); });
      }

      this.getCompanies();
    });

  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }

    if (this.userRole === 'read') {
      this.displayedColumnsDataCenters = ['dataCenter', 'clusters'];
      this.displayedColumnsClusters = ['cluster'];
    }

  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  createForm() {
    this.form = new FormGroup({
      '_id': new FormControl(undefined),
      'company': new FormControl(null, {validators: [Validators.required]
      }),
      'vcenter_server_name': new FormControl(null, {validators: [Validators.required]
      }),
      'vcenter_version': new FormControl(null
      ),
      'dataCenters': new FormControl(null
      ),
    });
  }

  fillForm() {
    this.form.patchValue({
      ...this.vcenter,
      company: this.vcenter.company
    });

    this.dataCenters = this.vcenter.dataCenters;
    this.dataCenters.forEach(dc => this.allClusters = this.allClusters.concat(dc.clusters));
    this.clusters = this.allClusters;

    this.dataSourceDataCenters = new MatTableDataSource(this.dataCenters);
    this.dataSourceClusters = new MatTableDataSource(this.clusters);
  }

  setCompId(compId) {
    this.companyId = compId;
  }

  selectDataCenter(datacenter) {
    this.currentDataCenter = datacenter;
    this.clusters = this.currentDataCenter.clusters;
    this.dataSourceClusters = new MatTableDataSource(this.clusters);
  }

  onSave() {
    this.form.patchValue({dataCenters: this.dataCenters});
    if (this.mode === 'create') {
      this.vcenterService.addVCenter(this.form.value);
    } else {
      this.vcenterService.updateVcenter(this.form.value).subscribe();
    }
  }

  onCancel() {
    this.router.navigate(['/list-vcenter']);
  }

  editDataCenter(element) {
    let index;

    if (element) { index = this.dataCenters.indexOf(element); }

    const dialogRef = this.dialog.open(DataCenterComponent, {
      disableClose: true,
      width: '30%',
      data: {dataCenter: element}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        const data = updateData.data;
        if (element) {
          this.dataCenters[index] = data;
        } else {
          this.dataCenters.push(data);
        }
        this.dataSourceDataCenters = new MatTableDataSource(this.dataCenters);
      } else {
        console.log('closed');
      }
    });

  }

  editCluster(element) {

    let currentDC;
    if (this.currentDataCenter) {
      currentDC = this.currentDataCenter;
    } else {
      currentDC = this.dataCenters.find(dc => dc.clusters.includes(element));
    }

    const dialogRef = this.dialog.open(ClusterComponent, {
      disableClose: true,
      width: '50%',
      data: {dataCenters: this.dataCenters, currentDataCenter: currentDC, cluster: element}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        const data = updateData.data;
        const dcIndex = this.dataCenters.indexOf(data.selectedDC);
        const clusterObj = {_id: undefined, cluster: data.cluster};
        if (element) {
          const clusterIndex = this.dataCenters[dcIndex].clusters.indexOf(element);
          clusterObj._id = element._id;
          this.dataCenters[dcIndex].clusters[clusterIndex] = clusterObj;
        } else {
          try {
            this.dataCenters[dcIndex].clusters.push(clusterObj);
          } catch {
            this.dataCenters[dcIndex].clusters = [clusterObj];
          }
        }

        this.allClusters = [];
        this.dataCenters.forEach(dc => {
          this.allClusters = this.allClusters.concat(dc.clusters);
        });

        if (this.currentDataCenter) {
          this.currentDataCenter = this.dataCenters[dcIndex];
          this.clusters = this.currentDataCenter.clusters;
          this.dataSourceClusters = new MatTableDataSource(this.clusters);
        } else {
          this.dataSourceClusters = new MatTableDataSource(this.allClusters);
        }

      } else {
        console.log('closed');
      }
    });
  }


}
