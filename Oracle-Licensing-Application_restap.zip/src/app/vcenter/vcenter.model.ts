export interface Cluster {
  _id: string;
  cluster: string;
}

export interface DataCenter {
  data_center: string;
  clusters: [Cluster];
}

export interface VCenter {
  _id: string;
  company: string;
  vcenter_server_name: string;
  vcenter_version: string;
  dataCenters: [DataCenter];
}
