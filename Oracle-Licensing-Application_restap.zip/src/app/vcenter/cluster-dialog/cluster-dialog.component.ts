// angular
import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

// models
import { Cluster, DataCenter } from '../vcenter.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-cluster-dialog',
  templateUrl: './cluster-dialog.component.html',
  styleUrls: ['./cluster-dialog.component.css'],
  providers: [ThemeService]
})

export class ClusterComponent implements OnInit {

  form: FormGroup;
  cluster: Cluster;
  dataCenters: DataCenter[];
  dataCenter: DataCenter;

  constructor(public dialogRef: MatDialogRef<ClusterComponent>,
    private themeService: ThemeService,
    private authService: AuthService, @Inject(MAT_DIALOG_DATA) public data: any) {}


    ngOnInit() {
      this.authService.autoAuthUser();

      if (this.themeService.getThemeSelected() === true ) {
        this.dialogRef.addPanelClass('dark-theme');
      }

      this.cluster = this.data.cluster;
      this.dataCenter = this.data.currentDataCenter;
      this.dataCenters = this.data.dataCenters;

      this.createFillForm();

    }

    createFillForm () {
      this.form = new FormGroup({
        'data_center': new FormControl(this.dataCenter),
        'cluster': new FormControl(null)
      });

      if (this.cluster) { this.form.patchValue({cluster: this.cluster.cluster}); }
    }

    add() {
      const selectedDC = this.form.value.data_center;
      const cluster = this.form.value.cluster;
      this.dialogRef.close({data: {selectedDC: selectedDC, cluster: cluster}});
    }

}
