import { FormGroup, FormControl, FormGroupDirective, NgForm, ValidatorFn, AbstractControl, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material';

/**
 * Custom validator functions for reactive form validation
 */
export class CustomValidators extends Validators{
    static isNumberValidator(control: AbstractControl) : { [key: string]: boolean } | null {
        if (typeof(control.value) !== 'number') {
          return {notNumberCheck: true};
        }
        return null;
      }
}