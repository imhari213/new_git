// angular
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialModule } from './angular-material.module';
import { LayoutModule } from '@angular/cdk/layout';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HashLocationStrategy, LocationStrategy  } from '@angular/common';

// modules
import { AppRoutingModule } from './app-routing.module';
import { CompanyModule } from './companies/companies.module';
import { ContractModule } from './contracts/contracts.module';
import { VCenterModule } from './vcenter/vcenter.module';
import { DbModule } from './databases/database.module';
import { HardwareModule } from './hardware/hardware.module';
import { ConfigModule } from './config/config.module';
import { MiddlewareModule } from './middleware/middleware.module';
import { DeclarationsModule } from './declarations/declarations.module';
import { ReportingModule } from './reporting/reporting.module';


// interceptors
import { AuthInterceptor } from './auth/auth-interceptor';
import { ErrorInterceptor } from './error-interceptor';

// components
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ErrorComponent } from './error/error.component';
import { AdaptNavComponent } from './adapt-nav/adapt-nav.component';
import { ResolveRequestsDialogComponent } from './resolve-requests-dialog/resolve-requests-dialog.component';
import { DeleteConfirmationComponent } from './deletePopUp/delete-confirmation-dialog.component';
import { OptionsInUseDialogComponent } from './databases/options-in-use-dialog/options-in-use-dialog.component';

// misc
import { RECAPTCHA_V3_SITE_KEY, RecaptchaV3Module } from 'ng-recaptcha';
import { RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ErrorComponent,
    AdaptNavComponent,
    DeleteConfirmationComponent,
    ResolveRequestsDialogComponent,
    OptionsInUseDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AngularMaterialModule,
    LayoutModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    CompanyModule,
    ContractModule,
    DbModule,
    HardwareModule,
    VCenterModule,
    MiddlewareModule,
    ConfigModule,
    RecaptchaV3Module,
    RecaptchaModule,
    RecaptchaFormsModule,
    DeclarationsModule,
    ReportingModule
  ],
  providers: [{provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true},
    {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true},
    {provide: RECAPTCHA_V3_SITE_KEY, useValue: '6Lfw384UAAAAAIlKP7bEK3-nXOzLEO3L0Db15lzz'},
    {provide : LocationStrategy , useClass: HashLocationStrategy}
  ],
  bootstrap: [AppComponent],
  entryComponents: [ErrorComponent, HeaderComponent, DeleteConfirmationComponent, ResolveRequestsDialogComponent,
    OptionsInUseDialogComponent],
})
export class AppModule { }
