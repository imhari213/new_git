// angular
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatTable } from '@angular/material';
import { Location } from '@angular/common';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// models
import { Company, EndUserContact, EndUserComment } from '../company.model';

// services
import { CompanyService } from '../companies.service';
import { AuthService } from 'src/app/auth/auth.service';

// components
import { EndUserContactDialogComponent } from '../end-user-contact-dialog/end-user-contact-dialog.component';
import { EndUserCommentDialogComponent } from '../end-user-comment-dialog/end-user-comment-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-company-create',
  templateUrl: './companies-create.component.html',
  styleUrls: ['./companies-create.component.css'],
  providers: [{provide: STEPPER_GLOBAL_OPTIONS, useValue: { displayDefaultIndicatorType: false }}]
})

export class CompanyCreateComponent implements OnInit, OnDestroy {

  form: FormGroup;
  company: Company;
  private companyId: string;

  mode = 'create';
  userRole = 'read';
  userIsAuthenticated = false;
  subsidaryList = this.getCompanyList();

  dataSourceEndUserContact: any;
  displayedColumnsEndUserContact: string[] = ['Name', 'Role', 'Type', 'Edit'];
  endUserContactArray: EndUserContact[] = [];

  dataSourceEndUserComment: any;
  displayedColumnsEndUserComment: string[] = ['Date', 'Entered By', 'Contact', 'Edit'];
  endUserCommentArray: EndUserComment[] = [];

  contactRoles = [];
  contactTypes = [];
  contactLocations = [];

  companies: Company[] = [];
  companyName;

  private companySub: Subscription;
  private authStatusSub: Subscription;

  @ViewChild(MatTable) table: MatTable<any>;
  constructor(public companyService: CompanyService, public route: ActivatedRoute,
    private authService: AuthService, private router: Router, public dialog: MatDialog, private location: Location) {}

  ngOnInit() {
      this.userIsAuthenticated = this.authService.getIsAuth();
      this.userRole = this.authService.getRole();
      this.authStatusSub = this.authService.getAuthStatusListener()
        .subscribe(isAuthenticated => {
          this.userIsAuthenticated = isAuthenticated;
          this.companyId = this.authService.getUserId();
          this.userRole = this.authService.getRole();
        });
      if (this.userIsAuthenticated === false) {
        this.router.navigate(['/auth/login']);
      }
      this.getCompanies();

      this.companyService.getCompanies(null, null);
      this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: number, matched: any}) => {
        this.companies = companyData.companies;
        this.setLists();
      });
    this.form = new FormGroup({ // intialise form
      'company_name': new FormControl(null, {validators: [Validators.required, Validators.minLength(3)]
      }),
      'hq_location': new FormControl(null
      ),
      'end_user_contacts': new FormControl(null
      ),
      'end_user_comments': new FormControl(null
      ),
      'end_user_subsidiaries': new FormControl(null
      ),
      'oma_reference_number': new FormControl(null
      ),
      'vad_name': new FormControl(null
      ),
      'vad_contact': new FormControl(null
      )
    });

    this.route.paramMap.subscribe((paramMap: ParamMap) => {  // listening to changes in the route url/parameters
      if (paramMap.has('companyId')) {
        this.mode = 'edit';
        this.companyId = paramMap.get('companyId');
        this.companyService.getCompany(this.companyId).subscribe(companyData => {
          this.dataSourceEndUserContact = new MatTableDataSource(companyData.end_user_contacts);
          this.dataSourceEndUserComment = new MatTableDataSource(companyData.end_user_comments);
          if (companyData.end_user_contacts) {this.endUserContactArray = companyData.end_user_contacts; }
          if (companyData.end_user_comments) {this.endUserCommentArray = companyData.end_user_comments; }
          this.company = {
            ...companyData,
            _id: companyData._id,
            end_user_contacts: companyData.end_user_contacts,
            end_user_comments: companyData.end_user_comments,
            end_user_subsidiaries: companyData.end_user_subsidiaries,
          };
          this.companyName = this.company.company_name;
          this.form.patchValue({
            'company_name': this.company.company_name,
            'hq_location': this.company.hq_location,
            'end_user_contacts': this.company.end_user_contacts,
            'end_user_comments': this.company.end_user_comments,
            'end_user_subsidiaries': this.company.end_user_subsidiaries,
            'oma_reference_number': this.company.oma_reference_number,
            'vad_name': this.company.vad_name,
            'vad_contact': this.company.vad_contact,
          });
        });
      } else {
        this.mode = 'create';
        this.companyId = null;
      }
    });
  }

getCompanyList() {
 return this.companyService.setCompanylist();
}

getCompanies() {
  this.companyService.getCompanyNames();
}

// a nicety to suggest roles etc by using previously used. not important however
setLists() {
  this.companies.forEach(company => {

    if (company.end_user_contacts) { // for empty lists
      company.end_user_contacts.forEach(contact => {

        if (contact.end_user_role) {
          if (!this.contactRoles.includes(contact.end_user_role)) {
            this.contactRoles.push(contact.end_user_role);
          }
        }
        if (contact.end_user_type) {
          if (!this.contactTypes.includes(contact.end_user_type)) {
            this.contactTypes.push(contact.end_user_type);
          }
        }
        if (contact.end_user_location) {
          if (!this.contactLocations.includes(contact.end_user_location)) {
            this.contactLocations.push(contact.end_user_location);
          }
        }
      });
    }

  });
}

// table filter
applyEndUserContactFilter(filterValue: string) {
  this.dataSourceEndUserContact.filter = filterValue.trim().toLowerCase();
}

applyEndUserCommentFilter(filterValue: string) {
  this.dataSourceEndUserComment.filter = filterValue.trim().toLowerCase();
}

 // Create
 endUserContact_CreateDialog (): void {
  const dialogRef = this.dialog.open(EndUserContactDialogComponent, {
    disableClose: true,
    width: '50%',
    data: {contactRoles: this.contactRoles, contactTypes: this.contactTypes, contactLocations: this.contactLocations}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (!result || result.data === undefined) {
      console.log('no data saved');
    } else {
      this.endUserContactArray.push(result.data); // form data add to form array
      this.dataSourceEndUserContact = new MatTableDataSource(this.endUserContactArray);
    }
  });
}

// Edit dialog
endUserContact_EditDialog(i: any): void {
  let dialogRef;
    dialogRef = this.dialog.open(EndUserContactDialogComponent, {
      disableClose: true,
      width: '50%',
      data: { contactRoles: this.contactRoles, contactTypes: this.contactTypes, contactLocations: this.contactLocations,
        end_user_contacts: this.endUserContactArray[i]}
    });
  dialogRef.afterClosed().subscribe(result => {
    if (!result || result.data === undefined) {
      console.log('no data saved');
    } else {
      this.endUserContactArray.splice(i, 1, result.data);
      this.dataSourceEndUserContact = new MatTableDataSource(this.endUserContactArray);
    }
  });
}

onDeleteEndUserContact(i: any): void {
  this.endUserContactArray.splice(i, 1);
  this.dataSourceEndUserContact = new MatTableDataSource(this.endUserContactArray);
}

endUserComment_CreateDialog (): void {
  const dialogRef = this.dialog.open(EndUserCommentDialogComponent, {
    disableClose: true,
    width: '50%',
    data: {compContacts: this.endUserContactArray}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (!result || result.data === undefined) {
      console.log('no data saved');
    } else {
      this.endUserCommentArray.push(result.data);
      this.dataSourceEndUserComment = new MatTableDataSource(this.endUserCommentArray);
    }
  });
}

endUserComment_EditDialog (i: any): void {
  const dialogRef = this.dialog.open(EndUserCommentDialogComponent, {
    disableClose: true,
    width: '50%',
    data: {compContacts: this.endUserContactArray, end_user_comments: this.endUserCommentArray[i]}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (!result || result.data === undefined) {
      console.log('no data saved');
    } else {
      this.endUserCommentArray.splice(i, 1, result.data);
      this.dataSourceEndUserComment = new MatTableDataSource(this.endUserCommentArray);
    }
  });
}

onDeleteEndUserComment(i: any): void {
  this.endUserCommentArray.splice(i, 1);
  this.dataSourceEndUserComment = new MatTableDataSource(this.endUserCommentArray);
}

onSaveCompany() {
  if (this.form.invalid) {
    return;
  } else {
    this.form.patchValue({end_user_comments: this.endUserCommentArray});
    this.form.patchValue({end_user_contacts: this.endUserContactArray});
    if (this.mode === 'create') {
      this.companyService.addCompany(this.form.value).subscribe(result => {
        this.authService.newCompanyRefreshedToken(result.token, result.expiresIn);
        this.router.navigate(['/list-company']);
      });
    } else {
      this.companyService.updateCompany(this.companyId, this.form.value).subscribe(() => {
        this.router.navigate(['/list-company']);
      });
    }
  }
}

onCancel() {
  this.location.back();
}

ngOnDestroy() {
  try { this.companySub.unsubscribe(); } catch {}
  try { this.authStatusSub.unsubscribe(); } catch {}
}

}
