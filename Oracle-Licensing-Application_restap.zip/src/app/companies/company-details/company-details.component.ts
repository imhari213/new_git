// angular
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import { MatTable } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

// models
import { Company, EndUserContact } from '../company.model';
import { Hardware } from '../../hardware/hardware.model';

// services
import { CompanyService } from '../companies.service';
import { AuthService } from 'src/app/auth/auth.service';
import { HwService } from '../../hardware/hardware.service';
import { HeaderService } from 'src/app/header/header.service';

// components
import { EndUserContactDialogComponent } from '../end-user-contact-dialog/end-user-contact-dialog.component';
import { EndUserCommentDialogComponent } from '../end-user-comment-dialog/end-user-comment-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.css']
})

export class CompanyDetailsComponent implements OnInit, OnDestroy {

  company: Company;
  companies: Company[];
  companyId: any;
  urlArray = [];
  subsidiaryList = [];
  tempSubsidiaryList = [];
  subList = [];
  contactRoles = [];
  contactType = [];
  contactLocation = [];
  matchedEmailList = [];

  selectedCompany: string;
  mode = 'create';
  userRole = 'read';
  ready = false;
  userIsAuthenticated = false;
  vcenterChecked: Boolean;

  displayedColumnsEndUserContact: String[] = ['Name', 'Role', 'Type', 'Number', 'Email', 'Location', 'Edit'];
  displayedColumnsEndUserComment: string[] = ['Date', 'Note', 'Entered By', 'Contact', 'Edit'];
  dataSourceEndUserContact: any;
  dataSourceEndUserComment: any;

  constructor(private authService: AuthService, private headerService: HeaderService, private hardwareService: HwService,
    private companyService: CompanyService, private router: Router, private activeRoute: ActivatedRoute,
    private  dialog: MatDialog) {}

  private companySub: Subscription;
  private companiesSub: Subscription;
  private hardwareSub: Subscription;
  private authStatusSub: Subscription;

  @ViewChild(MatTable) table: MatTable<any>;

  /*
  function that is called when the component has been navigated to
  */
  ngOnInit() {
    // checks that that the user is authenticated to view the application i.e. logged in and a token has been generated
    localStorage.removeItem('contractId');
    localStorage.removeItem('hardwareId');
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
      // if they havent been authenticated the user will be routed to the login page
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    // if they have been authenticated then their role will be checked to see and set so they can only access certain parts of the component
    this.userRole = this.authService.getRole();
    if (this.userRole === 'read') {
      // removes the edit column for contacts since the users only has read access
      this.displayedColumnsEndUserContact = ['Name', 'Role', 'Type', 'Number', 'Email', 'Location'];
      this.displayedColumnsEndUserComment = ['Date', 'Note', 'Entered By', 'Contact'];
    }
    // sets the url into an array split by each '/'
    this.urlArray = (window.location.href.split('/'));
    // sets the companyId as the fourth postion in the urlarray
    this.companyId = this.urlArray[4];
    // if the company name that was passed through to reach this page is null, then the user is routed to the list all companies component
    this.activeRoute.params.subscribe(routeParams => {
      if (routeParams.companyName == null) {
        this.router.navigate(['/list-company']);
      } else {
        // if there is a company name then then we check the backend with the company name and search the database
        // for a match (companies have unique names so there should only be one)
          this.companyService.getCompanyByName(routeParams.companyName);
          // we set a subscription that allows us to read the information from the backend
          this.companySub = this.companyService.getCompanyByNameListener()
            .subscribe((companyData) => {
              // set object of the company
              this.company = companyData.company;
              // set if the company has a vcenter or not
              this.vcenterChecked = companyData.vcenterChecked;
              // checks any of the contacts of the company have a account registered with the same email
              this.authService.getEmailCheckedList(this.company.end_user_contacts).subscribe(result => {
                this.matchedEmailList = result.email;
              });
              // sets a list of the companies subsidaries
              this.subList = this.company.end_user_subsidiaries;
              // gets the name of the subsidare
              this.getSubs(this.company.end_user_subsidiaries);
              // setting the contacts into an array to be used for the table on the view
              this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
              this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
              this.ready = true;
              this.companySub.unsubscribe(); // stops sub list multiplying
            });
    }

    // calls hardware backend for some reason
    this.hardwareService.getHardwares(null, null);
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
      .subscribe((hardwareData: {hardwares: Hardware[]; hardwareCount: number}) => {
      });
    });

    // calls company backend again for some reason
    this.companyService.getCompanies(null, null);
    this.companiesSub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: number, matched: any}) => {
      this.companies = companyData.companies;
      this.companies.forEach(comp => {
      if (comp.end_user_contacts) {
        comp.end_user_contacts.forEach(contact => {
          if (contact.end_user_role && !this.contactRoles.includes(contact.end_user_role)) {
            this.contactRoles.push(contact.end_user_role);
          }
          if (contact.end_user_type && !this.contactType.includes(contact.end_user_type)) {
            this.contactType.push(contact.end_user_type);
          }
          if (contact.end_user_location && !this.contactLocation.includes(contact.end_user_location)) {
            this.contactLocation.push(contact.end_user_location);
          }
        });
      }
      });
    });
  }

  // called from the table view and will check if the contacts email matches,
  // one of the emails that are in the backend which we have set in ngonit
  // if they do match it will return a '*'
  getEmail(email: string, i) {
    if (this.matchedEmailList[i] === email) {
      return '*';
    }
  }

  // filter used with the mat table, when customer types into the filter box the table will update and filter, without reloading the page
  applyEndUserContactFilter(filterValue: any) {
    this.dataSourceEndUserContact.filter = filterValue.trim().toLowerCase();
  }

  applyEndUserCommentFilter(filterValue: any) {
    this.dataSourceEndUserComment.filter = filterValue.trim().toLowerCase();
  }

  // get company subsidaires names
  getSubs(subs: any) {
    this.subsidiaryList = this.getSubsList();
    this.companyService.getSubNames(subs);
  }

  // not sure either
  getSubsList() {
    return this.companyService.setSubList();
  }

  // if the user clicks on one of the subsidaries then they will be routed to the same component
  // but will have a new customer name to search from
  getSelectedCompany(company) {
    this.selectedCompany = company;
    this.router.navigate(['/company-details/' + this.selectedCompany]);
  }

  // dialog box used for adding/editing a contact to the company
  endUserContact_CreateDialog (index: any, id: any): void {
    let dialogRef;

    if ((index === null)) {
      dialogRef = this.dialog.open(EndUserContactDialogComponent, {
        disableClose: true,
        width: '50%',
        data: { contactRoles: this.contactRoles, contactTypes: this.contactType, contactLocations: this.contactLocation}
      });
    } else {
      dialogRef = this.dialog.open(EndUserContactDialogComponent, {
        disableClose: true,
        width: '50%',
        data: { contactRoles: this.contactRoles, contactTypes: this.contactType,
                contactLocations: this.contactLocation, end_user_contacts: this.company.end_user_contacts[index]}
      });
    }

    dialogRef.afterClosed().subscribe(result => {
      if (!result || result.data === undefined) {
        console.log('no data saved');
      } else {
        if (index === null) {
          this.company.end_user_contacts.push(result.data); // form data add to form array
          this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
          this.companyService.updateCompany(id, this.company);
        } else {
          this.company.end_user_contacts.splice(index, 1, result.data);
          this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
          this.companyService.updateCompany(id, this.company);
        }
      }
    });
  }

  // delete contact which uses a dialog box for conformation
  onDeleteContact(optioni) {
    let dialogRef;
    dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: this.company.end_user_contacts[optioni].end_user_name, pageViewName: 'Companies contact'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.company.end_user_contacts.splice(optioni, 1);
        this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
        this.companyService.updateCompany(this.company._id, this.company);
        this.table.renderRows();
      } else {
        console.log('contact not deleted');
      }
    });
  }

  endUserComment_CreateDialog (): void {
    const dialogRef = this.dialog.open(EndUserCommentDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {compContacts: this.company.end_user_contacts}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result || result.data === undefined) {
        console.log('no data saved');
      } else {
        if (this.company.end_user_comments) {
          this.company.end_user_comments.push(result.data);
        } else {
          this.company.end_user_comments = [result.data];
        }
        this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
        this.companyService.updateCompany(this.company._id, this.company);
      }
    });
  }

  endUserComment_EditDialog (i: any): void {
    const dialogRef = this.dialog.open(EndUserCommentDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {compContacts: this.company.end_user_contacts, end_user_comments: this.company.end_user_comments[i]}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result || result.data === undefined) {
        console.log('no data saved');
      } else {
        this.company.end_user_comments.splice(i, 1, result.data);
        this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
        this.companyService.updateCompany(this.company._id, this.company);
      }
    });
  }

  onDeleteEndUserComment(i) {
    let dialogRef;
    dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: this.company.end_user_comments[i].entered_by.email, pageViewName: 'Customer Note made by'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.company.end_user_comments.splice(i, 1);
        this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
        this.companyService.updateCompany(this.company._id, this.company);
      } else {
        console.log('contact not deleted');
      }
    });
  }

  /*
  four functions for routing the customer to other components depending on the button they have selected
  */
  listCompaniesContracts(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-contract/']);
  }

  listCompaniesHardware(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-hardware/']);
  }

  listCompaniesDatabases(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-database/']);
  }

  listCompaniesMiddleware(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-middleware']);
  }

  listCompaniesVcenters(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-vcenter/']);
  }

  getReports() {
    this.router.navigate(['/create-report']);
  }

  // called when the uses naviagates away from the component to remove subscritptions
  ngOnDestroy() {
    this.companiesSub.unsubscribe();
    this.authStatusSub.unsubscribe();
    this.companySub.unsubscribe();
    this.hardwareSub.unsubscribe();
  }


}
