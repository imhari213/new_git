export interface Company {
  _id: string;
  company_name: string;
  hq_location: string;
  end_user_contacts: [EndUserContact];
  end_user_comments: [EndUserComment];
  end_user_subsidiaries: [{type: string}]; // string
  oma_reference_number: string;
  vad_name: string;
  vad_contact: string;
}

export interface EndUserContact {
  end_user_name: string;
  end_user_role: string;
  end_user_type: string;
  end_user_pnumber: string;
  end_user_email: string;
  end_user_location: string;
}

export interface EndUserComment {
  comment_date: Date;
  comment_message: string;
  comment_contact: string;
  entered_by: {
    id: string;
    email: string;
  };
}
