// angular
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { PageEvent } from '@angular/material';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { MatTable } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';

// models
import { Company } from '../company.model';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { CompanyService } from '../companies.service';
import { AuditService } from 'src/app/audit/audit.service';
import { ThemeService } from '../../theme.service';
import { OptionsService } from '../../options.service';

// components
import { EndUserContactDialogComponent } from '../end-user-contact-dialog/end-user-contact-dialog.component';
import { EndUserCommentDialogComponent } from '../end-user-comment-dialog/end-user-comment-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';

// misc
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-company-list',
  templateUrl: './companies-list.component.html',
  styleUrls: ['./companies-list.component.css'],
})

export class CompanyListComponent implements OnInit, OnDestroy {

  @ViewChild(MatTable) table: MatTable<any>;

  companies: any[] = [];
  vcenterCheckList = [];
  matchedEmailList: any[];
  contactRole = [];
  contactType = [];
  contactLocation = [];
  subsidiaryList = [];

  checkedHeader;
  searchParam;
  company;

  userIsAuthenticated: Boolean;
  userRole = 'read';
  isLoading = false;

  pageSizeOptions = [20, 50, 100];
  totalCompanies = 0;
  companiesPerPage = 20;
  currentPage = 1;

  displayedColumnsEndUserContact: String[] = ['Name', 'Role', 'Type', 'Number', 'Email', 'Location', 'Edit'];
  displayedColumnsEndUserComment: string[] = ['Date', 'Note', 'Entered By', 'Contact', 'Edit'];
  dataSourceEndUserContact: any;
  dataSourceEndUserComment: any;

  authStatusSub: Subscription;
  companySub: Subscription;
  headerOptionSub: Subscription;
  pageChosen: string;
  compareContractId: any;
  changePageSize: boolean;

  constructor(public companyService: CompanyService, private authService: AuthService, private router: Router, private dialog: MatDialog,
    private auditService: AuditService, private themeService: ThemeService, private optionsService: OptionsService) {}

    ngOnInit() {
      this.themeService.getUserThemeSelected();
      localStorage.removeItem('compId');
      localStorage.removeItem('contractId');
      localStorage.removeItem('hardwareId');
      this.isLoading = true;
      (async () => { this.getAuth(); })();
      (async () => { this.getCompanies(); })();
      this.optionsService.getUserHeaderOption();
      this.checkedHeader = this.optionsService.getHeaderOption();
      this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
      });
    }

    getAuth() {
      this.userIsAuthenticated = this.authService.getIsAuth();
      this.authStatusSub = this.authService.getAuthStatusListener()
        .subscribe(isAuthenticated => {
          this.userIsAuthenticated = isAuthenticated;
        });
      if (this.userIsAuthenticated === false) {
        this.router.navigate(['/auth/login']);
      }
      this.userRole = this.authService.getRole();
      if (!this.userRole) {this.userRole = 'read'; }
      if (this.userRole === 'read') {
        // table view for company's contacts is changed to remove add and edit functionallity
        this.displayedColumnsEndUserContact = ['Name', 'Role', 'Type', 'Number', 'Email', 'Location'];
      }
    }

    getCompanies() {
      this.companyService.searchCompany(this.searchParam, this.companiesPerPage, this.currentPage, this.pageChosen, this.compareContractId);
      this.companySub = this.companyService.getCompanyUpdateListener()
        .subscribe((companyData: {companies: Company[]; companyCount: number; matched: any}) => {
          this.companies = companyData.companies;
          this.totalCompanies = companyData.companyCount;
          this.vcenterCheckList = companyData.matched;
          this.changePageSize = false;
          this.pageChosen = null;
          this.compareContractId = null;
          this.isLoading = false;
        });
    }

    vCenterCheck(company) {
      const index = this.companies.indexOf(company);
      return this.vcenterCheckList[index];
    }

    onSearch(search) {
      if (search === '') { this.searchParam = undefined; } else { this.searchParam = search; }
      this.getCompanies();
    }

    setTableAndUserData(company) {
      this.company = company;
      this.dataSourceEndUserContact = new MatTableDataSource(company.end_user_contacts);
      this.dataSourceEndUserComment = new MatTableDataSource(company.end_user_comments);
      this.setUsers();
    }

    getSelectedCompany(company) {
      this.router.navigate(['/company-details/' + company]);
    }

    getSubs(subs: any) {
      this.subsidiaryList = this.getSubsList();
      this.companyService.getSubNames(subs);
    }

    setUsers() {
      if (this.company.end_user_contacts) {
        this.company.end_user_contacts.forEach(element => {
          this.authService.getEmails(element.end_user_email);
          this.matchedEmailList = this.authService.getEmailCheckerListener();
        });
      } else {
        return;
      }
    }

    getSubsList() {
      return this.companyService.setSubList();
    }

    listCompaniesDeclarations(companyId: string) {
      localStorage.setItem('compId', companyId);
      this.router.navigate(['/list-declarations/']);
    }

  // function which when called links user to a list of contracts assocaited with the specific company.
  listCompaniesContracts(companyId: string) {
    // this.companyService.SearchContracts(companyId, this.companiesPerPage, this.currentPage);
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-contract/']);
  }

// function which when called links user to a list of databases assocaited with the specific company.
  listCompaniesDatabases(companyId: string) {
    // this.companyService.searchDatabase(companyId, this.companiesPerPage, this.currentPage);
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-database/']);
  }

// function which when called links user to a list of hardwares assocaited with the specific company.
  listCompaniesHardwares(companyId: string) {
    // this.companyService.SearchHardware(companyId, this.companiesPerPage, this.currentPage);
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-hardware/']);
  }

  listCompaniesMiddleware(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-middleware/']);
  }

  listCompaniesVcenters(companyId: string) {
    localStorage.setItem('compId', companyId);
    this.router.navigate(['/list-vcenter/']);
  }

  onDelete(companyId: string, company_name: String, event: Event) {
    let dialogRef;
    dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: company_name, pageViewName: 'company'}
    });
    event.stopPropagation(); // stops drop down open when clicking button
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'yes') {
        this.companyService.deleteCompany(companyId).subscribe(() => {
          // this.auditService.addAudit('company', companyId, 'delete', company_name, null, null, null);
          this.companyService.getCompanies(this.companiesPerPage, this.currentPage);
        });
      }
    });
  }

  applyEndUserContactFilter(filterValue: any) {
    this.dataSourceEndUserContact.filter = filterValue.trim().toLowerCase();
  }

  applyEndUserCommentFilter(filterValue: any) {
    this.dataSourceEndUserComment.filter = filterValue.trim().toLowerCase();
  }

  getEmail(email: string, i) {
    try {
      if (email === undefined) {return;
      } else if (this.matchedEmailList[i] === email) {return '*'; }
    } catch {return ''; }
  }

    // function that opens a dialog box to add or edit details of the company's contacts
    endUserContact_CreateDialog (i: any): void {

      let dialogRef;
      // companyIndex = this.companies.indexOf(companyIndex);
      // checks to make sure there is an id or not for the contact, to determine if they are creating or editing

      if ((i === null)) { // create branch
        dialogRef = this.dialog.open(EndUserContactDialogComponent, {
          disableClose: true,
          width: '50%',
          data: { contactRoles: this.contactRole, contactTypes: this.contactType, contactLocations: this.contactLocation }
        });
      } else { // edit branch
        dialogRef = this.dialog.open(EndUserContactDialogComponent, {
          disableClose: true,
          width: '50%',
          data: { contactRoles: this.contactRole, contactTypes: this.contactType, contactLocations: this.contactLocation,
                  end_user_contacts: this.company.end_user_contacts[i]}
        });
      }
      dialogRef.afterClosed().subscribe(result => {
        if (!result || result.data === undefined) {
          console.log('no data saved');
        } else {
          // mode is parsed through from the dialog component and used to decide if the user is creating or editing
          if (result.mode === 'create') {
            this.company.end_user_contacts.push(result.data); // form data add to form array
            this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
            this.companyService.updateCompany(this.company._id, this.company);
          }
          if (result.mode === 'edit' && result.data !== undefined) {
            this.company.end_user_contacts.splice(i, 1, result.data);
            this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
            this.companyService.updateCompany(this.company._id, this.company);
          }
        }
      });
  }

  onDeleteEndUserContact(i) {
    let dialogRef;
    dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: this.company.end_user_contacts[i].end_user_name, pageViewName: `${this.company.company_name} contact`}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.company.end_user_contacts.splice(i, 1);
        this.dataSourceEndUserContact = new MatTableDataSource(this.company.end_user_contacts);
        this.companyService.updateCompany(this.company._id, this.company);
      } else {
        console.log('contact not deleted');
      }
    });
  }

  endUserComment_CreateDialog (): void {
    const dialogRef = this.dialog.open(EndUserCommentDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {compContacts: this.company.end_user_contacts}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result || result.data === undefined) {
        console.log('no data saved');
      } else {
        if (this.company.end_user_comments) {
          this.company.end_user_comments.push(result.data);
        } else {
          this.company.end_user_comments = [result.data];
        }
        this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
        this.companyService.updateCompany(this.company._id, this.company);
      }
    });
  }

  endUserComment_EditDialog (i: any): void {
    const dialogRef = this.dialog.open(EndUserCommentDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {compContacts: this.company.end_user_contacts, end_user_comments: this.company.end_user_comments[i]}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (!result || result.data === undefined) {
        console.log('no data saved');
      } else {
        this.company.end_user_comments.splice(i, 1, result.data);
        this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
        this.companyService.updateCompany(this.company._id, this.company);
      }
    });
  }

  onDeleteEndUserComment(i) {
    let dialogRef;
    dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: this.company.end_user_comments[i].entered_by.email, pageViewName: 'Customer Note made by'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.company.end_user_comments.splice(i, 1);
        this.dataSourceEndUserComment = new MatTableDataSource(this.company.end_user_comments);
        this.companyService.updateCompany(this.company._id, this.company);
      } else {
        console.log('contact not deleted');
      }
    });
  }

  refresh(sub: string) {
    this.router.navigate(['/company-details/' + sub]);
  }

  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    this.companiesPerPage = pageData.pageSize;
    
    const numOfPages = Math.ceil(this.totalCompanies / this.companiesPerPage);
    if (pageData.pageIndex + 1 === numOfPages) {
      this.pageChosen = 'LAST';
    } else if (pageData.pageIndex > pageData.previousPageIndex) {
      this.pageChosen = 'NEXT';
      this.compareContractId = this.companies[this.companies.length - 1]._id;
    } else if (pageData.pageIndex === 0) {
      this.pageChosen = 'FIRST';
    } else {
      this.pageChosen = 'PREVIOUS';
      this.compareContractId = this.companies[0]._id;
    }

    if (pageData.pageSize !== this.companiesPerPage) {
      this.companiesPerPage = pageData.pageSize;
      this.changePageSize = true;
    }
    this.getCompanies();
  }
  /*
  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    const numOfPages = Math.ceil(this.totalContracts / this.contractsPerPage);
    if (pageData.pageIndex + 1 === numOfPages) {
      this.pageChosen = 'LAST';
    } else if (pageData.pageIndex > pageData.previousPageIndex) {
      this.pageChosen = 'NEXT';
      this.compareContractId = this.contracts[this.contracts.length - 1]._id;
    } else if (pageData.pageIndex === 0) {
      this.pageChosen = 'FIRST';
    } else {
      this.pageChosen = 'PREVIOUS';
      this.compareContractId = this.contracts[0]._id;
    }

    if (pageData.pageSize !== this.contractsPerPage) {
      this.contractsPerPage = pageData.pageSize;
      this.changePageSize = true;
    }

    this.getContracts();
  }*/

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    this.companySub.unsubscribe();
  }

}
