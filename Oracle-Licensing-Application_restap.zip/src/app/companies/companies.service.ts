// angular
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

// models
import { Company } from './company.model';

// services
import { AuditService } from '../audit/audit.service';

// misc
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const BACKEND_URL = environment.apiUrl  + '/company/';
const comp_name_list: any  = [];
let subsList: any = [];
const endUserContactList: any = [];

@Injectable({providedIn: 'root'})
export class CompanyService {
  private companies: Company[] = [];
  private company: Company;
  private companySelected = new Subject<{company: Company, vcenterChecked: Boolean}>();
  private companiesUpdated = new Subject<{companies: Company[], companyCount: Number, matched: any}>();
  private companiesHeaderUpdated = new Subject<{companies: Company[]}>();

  constructor(private http: HttpClient,  private router: Router, private auditService: AuditService) {}

  getCompanyNames() {
    this.http.get<{message: string, companies: any, maxCompanies: number}>(BACKEND_URL)
      .pipe(map((companyData) => {
        return { companies: companyData.companies.map(company => {
          let boolFlag = false;
          if (comp_name_list.length === 0 ) {
            comp_name_list.push(company.company_name); //  empty array, add element
          } else {
            for (let i = 0; i < comp_name_list.length; i ++) {
              if (comp_name_list[i] === company.company_name) { //  does frontened list = backend
                boolFlag = true; // yes then set true
              }
            }
            if (boolFlag === false) { // no match, if belongs in backend add it
              comp_name_list.push(company.company_name); // add backend element
            } else {
              comp_name_list.pop(company.company_name); // remove backend element
            }
          }
        })};
      })).subscribe(() => {
        console.log('Successfully retrieved Company names!');
      });
  }

  getSubNames(subs: [string]) {
    if (subsList.length === 0) {
      this.http.get<{message: string, companies: any, maxCompanies: number}>(BACKEND_URL)
      .pipe(map((companyData) => {
        return { companies: companyData.companies.map(company => {
          if (subs) {
            if (subs.includes(company._id)) {
              subsList.push(company.company_name);
            }
          }
        })};
      })).subscribe(() => {});
    }
  }

  getListSubNames(compId) {
    return this.http.get<{subNameList: any}>(BACKEND_URL + 'subNames/' + compId);
  }

  setSubList() {
    subsList = [];
    return subsList;
  }

  // get name for listing
  setCompanylist() {
    return comp_name_list;
  }

  addCompany(Value: any) {
    return this.http.post<{messsage: string, company: Company, token: string, expiresIn: number}>
    (BACKEND_URL, {company: Value, refreshToken: localStorage.getItem('refreshToken')});
  }


  getCompanies(companiesPerPage: number, currentPage: number) {
    const queryParams = `?pagesize=${companiesPerPage}&page=${currentPage}`;
    this.http.get<{message: string, companies: any, maxCompanies: number, matched: any}>(BACKEND_URL + queryParams)
    .pipe(map((companyData) => {
      return { companies: companyData.companies.map(companies => {
         return companies;
      }), maxCompanies: companyData.maxCompanies, matched: companyData.matched};
    })).subscribe((transformedData) => {
      this.companies = transformedData.companies,
      this.companiesUpdated.next({companies: [...this.companies],
        companyCount: transformedData.maxCompanies, matched: transformedData.matched});
    });
  }

  getCompaniesHeader() {
    this.http.get<{message: string, companies: any}>(BACKEND_URL).pipe(map((companyData) => {
      return { companies: companyData.companies.map(companies => {
        return companies;
      })};
    })).subscribe((transformedData) => {
      this.companies = transformedData.companies; // setting the posts to the posts from the server, tranformed due to _id
      this.companiesHeaderUpdated.next({companies: [...this.companies]});
    });
  }

  updateCompany(id: string, Value: any) {
    let companyData: Company | FormData;
    companyData = new FormData();
    companyData = {
      _id: id,
      company_name: Value.company_name,
      hq_location: Value.hq_location,
      end_user_contacts: Value.end_user_contacts,
      end_user_comments: Value.end_user_comments,
      end_user_subsidiaries: Value.end_user_subsidiaries,
      oma_reference_number: Value.oma_reference_number,
      vad_name: Value.vad_name,
      vad_contact: Value.vad_contact
    };
    return this.http.put(BACKEND_URL + id, companyData);
}

  getCompanyUpdateListener() {
    return this.companiesUpdated.asObservable();
  }

  getCompanyHeaderListener() {
    return this.companiesHeaderUpdated.asObservable();
  }

  getCompanyByName(companyName: string) {
    this.http.get<{message: string, company: any, vcenter: Boolean}>(BACKEND_URL + 'companyData/' + companyName)
      .pipe(map((companyData) => {
        this.company = companyData.company;
        return { company: companyData.company, vcenterChecked: companyData.vcenter};
  })).subscribe((companyData) => {
    this.company = companyData.company;
    this.companySelected.next({company: this.company, vcenterChecked: companyData.vcenterChecked});
  });
}

getCompanyByNameListener() {
  return this.companySelected.asObservable();
}

searchCompany(searchParam: string, companiesPerPage: number, currentPage: number, pageChosen: string, compareCompanyId: string) {
    if (searchParam === 'list-company' || searchParam === '' || !searchParam) {
      this.getCompanies(companiesPerPage, currentPage);
    } else {
    const queryParams = `?pagesize=${companiesPerPage}&page=${currentPage}&pageChosen=${pageChosen}&compareCompanyId=${compareCompanyId}`;
    this.http.get<{message: string, companies: any, maxCompanies: number, matched: any}>
    (BACKEND_URL + 'search/' + searchParam + '/' + queryParams)
      .pipe(map((companyData) => {
        return { companies: companyData.companies.map(company => {
              return {
                ...company,
                company_name: company.company_name,
             };
        }), maxCompanies: companyData.maxCompanies, matched: companyData.matched
      };
      }))
      .subscribe((transformedCompanyData) => {
      this.companies = transformedCompanyData.companies;
      this.companiesUpdated.next({companies: [...this.companies],
        companyCount: transformedCompanyData.maxCompanies, matched: transformedCompanyData.matched});
    });
  }
}


getEndUserContactList() {
  return endUserContactList;
}

getCompany(id: string) {
  return this.http.get<Company>(BACKEND_URL + id);
  // find the posts object we're looking at, is it the same as our passing argument id
}

deleteCompany(companyId: string) {
  return this.http.delete(BACKEND_URL + companyId);
}
}
