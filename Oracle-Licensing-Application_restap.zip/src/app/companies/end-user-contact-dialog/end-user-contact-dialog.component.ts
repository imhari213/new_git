// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

// models
import { EndUserContact } from '../company.model';

// services
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-end-user-contact-dialog',
  templateUrl: './end-user-contact-dialog.component.html',
  styleUrls: ['./end-user-contact-dialog.component.css'],
  providers: [ThemeService]
})
export class EndUserContactDialogComponent implements OnInit {

  form: FormGroup;
  mode = 'create';
  enduserContact: EndUserContact;

  contactRoles: string[] = [];
  filteredContactRoles: string[] = [];
  contactTypes: string[] = [];
  filteredContactTypes: string[] = [];
  contactLocations: string[] = [];
  filteredContactLocations: string[] = [];

  constructor(public dialogRef: MatDialogRef<EndUserContactDialogComponent>,
    private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any, public route: ActivatedRoute) {}

    /*
    set form for user to add details of the contact
    */
    ngOnInit() {
      if (this.themeService.getThemeSelected() === true ) {
        this.dialogRef.addPanelClass('dark-theme');
      }
      this.form = new FormGroup({ // intialise form
        'end_user_name': new FormControl(null, {validators: [Validators.required]
        }),
        'end_user_role': new FormControl(null, {validators: [Validators.required]
        }),
        'end_user_type': new FormControl(null
        ),
        'end_user_pnumber': new FormControl(null
        ),
        'end_user_email': new FormControl(null, {validators: [
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]
        }),
        'end_user_location': new FormControl(null
        )
    });

    /*
    Information brought through the dialog function and used on this component
    */
    this.contactRoles = this.data.contactRoles;
    this.filteredContactRoles = this.contactRoles;
    this.contactTypes = this.data.contactTypes;
    this.filteredContactTypes = this.contactTypes;
    this.contactLocations = this.data.contactLocations;
    this.filteredContactLocations = this.contactLocations;

    // checks to see if data for end user contacts was brought through, which will determine if the user is editing or creating a contact
    if (this.data.end_user_contacts) {
      this.mode = 'edit';
      this.enduserContact = {
        end_user_name: this.data.end_user_contacts.end_user_name,
        end_user_role: this.data.end_user_contacts.end_user_role,
        end_user_type: this.data.end_user_contacts.end_user_type,
        end_user_pnumber: this.data.end_user_contacts.end_user_pnumber,
        end_user_email: this.data.end_user_contacts.end_user_email,
        end_user_location: this.data.end_user_contacts.end_user_location,

      };
      // sets the information that has been passed through to be viewed
      this.form.patchValue({
        'end_user_name': this.enduserContact.end_user_name,
        'end_user_role': this.enduserContact.end_user_role,
        'end_user_type': this.enduserContact.end_user_type,
        'end_user_pnumber': this.enduserContact.end_user_pnumber,
        'end_user_email': this.enduserContact.end_user_email,
        'end_user_location': this.enduserContact.end_user_location,
      });
    } else {
      this.mode = 'create';
    }
    }

  save() {
    // closes the dialog box and saves the form and passes it to the front end
    this.dialogRef.close({data: this.form.value, mode: this.mode});
  }

  filterRoles (filterValue: any) {
    this.filteredContactRoles = [];
    this.contactRoles.forEach(role => {
      if (role.toLowerCase().includes(filterValue)) {
        this.filteredContactRoles.push(role);
      }
    });
  }

  filterTypes (filterValue: any) {
    this.filteredContactTypes = [];
    this.contactTypes.forEach(type => {
      if (type.toLowerCase().includes(filterValue)) {
        this.filteredContactTypes.push(type);
      }
    });
  }

  filterLocations (filterValue: any) {
    this.filteredContactLocations = [];
    this.contactLocations.forEach(loc => {
      if (loc.toLowerCase().includes(filterValue)) {
        this.filteredContactLocations.push(loc);
      }
    });
  }

}
