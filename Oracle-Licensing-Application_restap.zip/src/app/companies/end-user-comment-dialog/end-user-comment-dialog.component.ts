// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { ActivatedRoute } from '@angular/router';

// models
import { EndUserComment } from '../company.model';

// services
import { ThemeService } from '../../theme.service';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-end-user-contact-dialog',
  templateUrl: './end-user-comment-dialog-component.html',
  styleUrls: ['./end-user-comment-dialog.component.css'],
  providers: [ThemeService, {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}]
})
export class EndUserCommentDialogComponent implements OnInit {

  form: FormGroup;
  mode = 'create';
  endUserComment: EndUserComment;
  currentUser = localStorage.getItem('email');
  currentUserId = localStorage.getItem('userId');
  companyUserList = this.data.compContacts;
  entered_by;

  constructor(public dialogRef: MatDialogRef<EndUserCommentDialogComponent>,
    private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any, public route: ActivatedRoute) {}

  ngOnInit() {
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }

    this.entered_by =  {email: this.currentUser, id: this.currentUserId};

    this.form = new FormGroup({ // intialise form
      'comment_date': new FormControl(new Date(), {validators: [Validators.required]
      }),
      'comment_message': new FormControl(null, {validators: [Validators.required]
      }),
      'comment_contact': new FormControl(null
      ),
      'entered_by': new FormControl(this.entered_by
      )
    });

    if (this.data.end_user_comments) {
      this.mode = 'edit';
      this.endUserComment = {
        comment_date: this.data.end_user_comments.comment_date,
        comment_message: this.data.end_user_comments.comment_message,
        comment_contact: this.data.end_user_comments.comment_contact,
        entered_by: this.data.end_user_comments.entered_by,
      };
      // sets the information that has been passed through to be viewed
      this.form.patchValue({
        'comment_date': this.endUserComment.comment_date,
        'comment_message': this.endUserComment.comment_message,
        'comment_contact': this.endUserComment.comment_contact,
        'entered_by': this.endUserComment.entered_by,
      });
    } else {
      this.mode = 'create';
    }
  }

  save() {
    // closes the dialog box and saves the form and passes it to the front end
    this.dialogRef.close({data: this.form.value, mode: this.mode});
  }
}
