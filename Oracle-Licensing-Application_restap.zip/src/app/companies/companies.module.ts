// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AngularMaterialModule } from '../angular-material.module';

// components
import { CompanyCreateComponent } from './companies-create/companies-create.component';
import { CompanyListComponent } from './companies-list/companies-list.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { EndUserContactDialogComponent } from './end-user-contact-dialog/end-user-contact-dialog.component';
import { EndUserCommentDialogComponent } from './end-user-comment-dialog/end-user-comment-dialog.component';

@NgModule({
  declarations: [
    CompanyCreateComponent,
    CompanyListComponent,
    CompanyDetailsComponent,
    EndUserContactDialogComponent,
    EndUserCommentDialogComponent

  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
  ],
  entryComponents: [EndUserContactDialogComponent, EndUserCommentDialogComponent]
})

export class CompanyModule {}
