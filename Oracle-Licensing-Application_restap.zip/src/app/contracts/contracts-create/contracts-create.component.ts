// angular
import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { Router, ActivatedRoute, ParamMap} from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// models
import { Company } from '../../companies/company.model';
import { Contract } from '../contract.model';

// services
import { CompanyService } from 'src/app/companies/companies.service';
import { ContractService } from '../contracts.service';
import { AuthService } from 'src/app/auth/auth.service';
import { AuditService } from 'src/app/audit/audit.service';

// components
import { SupportContractDialogComponent } from 'src/app/contracts/support-contract-dialog/support-contract-dialog.component';
import { OracleLicenseDialogComponent } from 'src/app/contracts/oracle-license-dialog/oracle-license-dialog.component';
import { NonStandardTermsDialogComponent } from '../non-standard-terms-dialog/non-standard-terms-dialog.component';

// misc
import { mimeType } from './mime-type.validator';
import { Subscription } from 'rxjs';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-contract-create',
  templateUrl: './contracts-create.component.html',
  styleUrls: ['./contracts-create.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [{provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
              {provide: STEPPER_GLOBAL_OPTIONS,
              useValue: { displayDefaultIndicatorType: false }}]
})

export class ContractCreateComponent implements OnInit, OnDestroy {

  form: FormGroup;
  userIsAuthenticated = false;
  userRole = 'edit';
  mode = 'create';

  companies: Company[] = [];

  contractId;
  contracts: Contract[];
  contract: Contract;
  companyId;
  oracleLicenses = <any>[];
  nonStandardterms = <any>[];
  supportContracts = <any>[];

  imagesEditPreview = [];
  imagesPreview = [];
  fileArray: File[];
  pathArray: String[];

  dataSourceOracleLicence: any;
  displayedColumnsOracleLicence: string[] = ['productName', 'Metric', 'License Type', 'Restrictions', 'edit'];
  dataSourceSupportContract: any;
  displayedColumnsSupportContract: string[] = ['supportContractName', 'supportTerm', 'LinePrice', 'edit'];
  dataSourceNonStandardTerms: any;
  displayedColumnsNonStandardTerms: string[] = ['termName', 'edit'];

  constructor(private router: Router, public companyService: CompanyService, public dialog: MatDialog, private route: ActivatedRoute,
    public contractService: ContractService, private _snackBar: MatSnackBar,
    private location: Location, private authService: AuthService, private auditService: AuditService) {}

  private companySub: Subscription;
  private contractSub: Subscription;
  private authStatusSub: Subscription;


  ngOnInit() {
    this.getAuth();
    this.createForm();
    if (localStorage.getItem('compId')) {
      this.companyId = localStorage.getItem('compId');
      this.form.patchValue({end_user: this.companyId});
    }
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('companyId')) {
        this.companyId = paramMap.get('companyId');
        this.form.patchValue({end_user: this.companyId});
      }
      if (paramMap.has('contractId')) {
        this.mode = 'edit';
        this.contractId = paramMap.get('contractId');
        this.getContract();
      }
    });
    this.getCompanies();
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
    .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
      this.companies = companyData.companies;
    });
  }

  getContract() {
    this.contractService.getContract(this.contractId).subscribe(returnData => {
      this.contract = returnData.contract;
      this.fillForm();
    });
  }

  getSubList() {
    try {
      const subIdList = this.companies.find(comp => comp._id === this.form.value.end_user).end_user_subsidiaries;
      const subList = this.companies.filter(comp => subIdList.toString().includes(comp._id));
      return subList;
    } catch (error) {
      return [];
    }
  }

  createForm() {
    this.form = new FormGroup({ // intialise form
      'order_identifier': new FormControl(null
      ),
      'contract_date': new FormControl(null, {validators: [Validators.required]
      }),
      'customer_support_identifier': new FormControl(null, {validators: [Validators.required]
      }),
      'contract_territory': new FormControl(null
      ),
      'non_standard_terms': new FormControl(null
      ),
      'contract_terminated': new FormControl(null
      ),
      'total_capex_cost_of_contract': new FormControl(null
      ),
      'end_user': new FormControl(null, {validators: [Validators.required]
      }),
      'end_user_accepted_subsidiaries': new FormControl(null
      ),
      'signed_by': new FormControl(null
      ),
      'signed_by_date': new FormControl(null
      ),
      'contract_upload': new FormControl(null
      ),
      'contract_type': new FormControl(null
      ),
      'support_contract': new FormControl(null
      ),
      'oracle_licenses': new FormControl(null, {validators: [Validators.required]
      }),
      'image': new FormControl(null, {asyncValidators: [mimeType]
      }),
      'contract_imagepath': new FormControl(null
      ),
      'contract_filenames_toupload': new FormControl(null
      ),
    });
  }

  fillForm() {
    if (this.contract.contract_terminated !== undefined) {
      this.form.patchValue({
        ...this.contract,
        'order_identifier': this.contract.order_identifier,
        'contract_terminated': this.contract.contract_terminated.toString(),
        'customer_support_identifier': this.contract.customer_support_identifier
      });
    } else {
      this.form.patchValue({...this.contract,
        'order_identifier': this.contract.order_identifier,
        'contract_terminated': this.contract.contract_terminated,
        'customer_support_identifier': this.contract.customer_support_identifier
      });
    }
  this.oracleLicenses = this.contract.oracle_licenses;
  this.nonStandardterms = this.contract.non_standard_terms;
  this.supportContracts = this.contract.support_contract;

  this.dataSourceOracleLicence = new MatTableDataSource(this.oracleLicenses);
  this.dataSourceNonStandardTerms = new MatTableDataSource(this.nonStandardterms);
  this.dataSourceSupportContract = new MatTableDataSource(this.supportContracts);
  }

  onImagesPicked(event) {
    const selectedFiles = (event.target as HTMLInputElement).files;
    this.imagesPreview = [];
    if (this.fileArray === undefined ) {
      this.fileArray = Array.from(selectedFiles);
    } else {
      this.fileArray = (Array.from(selectedFiles)).concat(this.fileArray);
    }
    if (selectedFiles === undefined) {return; }
    for (const file of this.fileArray) {
      if (this.pathArray === undefined) {
        this.pathArray = [];
        this.pathArray.push(file.name);
      } else {
        this.pathArray.push(file.name);
      }
      this.form.patchValue({'image' : file}); // needed for validation
      this.form.get('image').updateValueAndValidity();
      const reader = new FileReader();
      reader.onload = () => {
        this.imagesPreview.push(<string>reader.result);
      };
      reader.readAsDataURL(file);
    }
    let str = '';
    this.fileArray.forEach(function(element) {
      str = str + element.name + ', ';
    });
    this.openSnackBar('Files Uploaded: ', str );
    console.log(this.imagesPreview);
}

  onSave() {

    if (this.nonStandardterms !== undefined) {
      for (const term of this.nonStandardterms) {
        if ((term.image !== null) && (term.image !== undefined) && (term.image) !== '') {
          for (const img of term.image) {
            if (this.fileArray === undefined ) {
              this.fileArray = [];
            }
            this.fileArray.push(img); // adding nst images to img array
          }
        }
      }
    }
    if (this.supportContracts !== undefined) {
      for (const support of this.supportContracts) {
        if ((support.image !== null) && (support.image !== undefined) && (support.image) !== '') {
          for (const img of support.image) {
            if (this.fileArray === undefined ) {
              this.fileArray = [];
            }
            this.fileArray.push(img); // adding support images to img array
          }
        }
      }
    }

    this.form.patchValue({non_standard_terms: this.nonStandardterms,
                          support_contract: this.supportContracts,
                          image: this.fileArray,
                          contract_filenames_toupload: this.pathArray,
                          oracle_licenses: this.oracleLicenses
                          });

    if (this.mode === 'create') {
      this.contractService.addContract(this.form.value).subscribe(data => {
        this.contract = data.contract;
        //this.auditService.addAudit('contract', data.contract._id, 'add', data.contract.customer_support_identifier, null, null, null);
        this.onCancel();
      });
    } else {
      this.form.patchValue({contract_imagepath: this.contract.contract_imagepath});
      this.contractService.updateContract(this.contractId, this.form.value).subscribe(data => {
        this.contract = data.contract;
        this.onCancel();
      });
    }
  }

  onCancel() {
    this.router.navigate(['/list-contract/']);
  }

  oracleLicenseDialog(element): void {
    let index;
    let mode = 'Create';

    if (element) { index = this.oracleLicenses.indexOf(element); mode = 'Edit'; }

    const dialogRef = this.dialog.open(OracleLicenseDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {oracle_license: element, mode: mode}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        if (element) {
          this.oracleLicenses.splice(index, 1, updateData);
        } else {
          this.oracleLicenses.push(updateData);
        }

        this.dataSourceOracleLicence = new MatTableDataSource(this.oracleLicenses);
      } else {
        console.log('closed');
      }
    });

  }

  onDeleteOracleLicence(element) {
    const index = this.oracleLicenses.indexOf(element);
    this.oracleLicenses.splice(index, 1);
    this.dataSourceOracleLicence = new MatTableDataSource(this.oracleLicenses);
  }

  nonStandardTermsDialog(element): void {

    let  index;
    let mode = 'Create';

    if (element) { index = this.nonStandardterms.indexOf(element); mode = 'Edit'; }

    const dialogRef = this.dialog.open(NonStandardTermsDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {non_standard_terms: element, mode: mode}
    });

    dialogRef.afterClosed().subscribe(updatedata => {
      if (updatedata) {
        if (element) {
          this.nonStandardterms.splice(index, 1, updatedata);
        } else {
          this.nonStandardterms.push(updatedata);
        }
        this.dataSourceNonStandardTerms = new MatTableDataSource(this.nonStandardterms);
      } else {
        console.log('closed');
      }
    });
  }

  onDeleteNonStandardterm(element) {
    const index = this.nonStandardterms.indexOf(element);
    this.nonStandardterms.splice(index, 1);
    this.dataSourceNonStandardTerms = new MatTableDataSource(this.nonStandardterms);
  }

  supportContractsDialog(element): void {
    let index;
    let mode = 'Create';
    if (element) { index = this.supportContracts.indexOf(element); mode = 'Edit'; }

    const dialogRef = this.dialog.open(SupportContractDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {support_contract: element, mode: mode}
    });

    dialogRef.afterClosed().subscribe(updateData => {
      if (updateData) {
        if (element) {
          this.supportContracts.splice(index, 1, updateData);
        } else {
          this.supportContracts.push(updateData);
        }

        this.dataSourceSupportContract = new MatTableDataSource(this.supportContracts);
      } else {
        console.log('closed');
      }
    });
  }

  onDeleteSupportContract(element) {
    const index = this.supportContracts.indexOf(element);
    this.supportContracts.splice(index, 1);
    this.dataSourceSupportContract = new MatTableDataSource(this.supportContracts);
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
    });
  }

  ngOnDestroy() {
    try { this.companySub.unsubscribe(); } catch {}
    try { this.contractSub.unsubscribe(); } catch {}
    this.authStatusSub.unsubscribe();
  }

}

