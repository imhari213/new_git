export interface Contract {
  _id: string;
  order_identifier: number;
  customer_support_identifier: string;
  contract_date: Date;
  contract_territory: string;
  non_standard_terms: [NonStandardTerms];
  contract_terminated: Boolean;
  total_capex_cost_of_contract: string;
  support_contract: [SupportContract];
  oracle_licenses: [OracleLicenses];
  end_user: string;
  end_user_accepted_subsidiaries: [string];
  signed_by: string;
  signed_by_date: Date;
  contract_upload: string;
  contract_type: string;
  contract_imagepath: [{type: string}];
  image: any;
  }

export interface NonStandardTerms {
  _id: string;
  term_name: string;
  term_description: string;
  term_filepaths:  [{type: string}];
  term_filenames_toupload: [{type: string}];
  image: any;
}

export interface SupportContract {
  _id: string;
  support_contract_number: number;
  support_start_date: Date;
  support_end_date: Date;
  support_term: string;
  support_offer_expiration: Date;
  support_representive: string;
  support_service_number: number;
  total_price: number;
  currency: string;
  line_price: number;
  support_filepaths:  [{type: string}];
  support_filenames_toupload: [{type: string}];
  image: any;
}

export interface OracleLicenses {
  _id: string;
  product_name: string;
  quantity: number;
  metric: string;
  term: string;
  license_type: string;
  restrictions: string;
  license_notes: string;
  support_status: string;
  support_end_date: Date;
  unit_price: number;
  total_cost: number;
  discount: string;
  allowed: number;
  allocated: number;
  migrated_to: Contract;
  migrated_from:  Contract;
  migration_date: Date;
}
