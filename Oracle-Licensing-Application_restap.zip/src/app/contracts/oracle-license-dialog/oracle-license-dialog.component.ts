// angular
import { Component, OnInit, Inject, OnDestroy, AfterViewInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';

// models
import { OracleLicenses } from '../contract.model';
import { SupportStatus, OptionsInUse } from '../../config/config.model';

// services
import { ConfigService } from '../../config/config.service';
import { ThemeService } from '../../theme.service';

// misc
import { Subscription } from 'rxjs';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-oracle-license-dialog',
  templateUrl: './oracle-license-dialog.component.html',
  styleUrls: ['./oracle-license-dialog.component.css'],
  providers: [ThemeService,
              {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}],
})

export class OracleLicenseDialogComponent implements OnInit, OnDestroy {

  form: FormGroup;
  mode = 'create';
  oracleLicenses: OracleLicenses;
  metricsList: string[] = [];
  filteredMetrics: string[] = [];
  termsList: string[] = [];
  filteredTerms: string[] = [];
  typesList: string[] = [];
  filteredTypes: string[] = [];
  supportStatusList = [];
  optionInUseList: OptionsInUse[];
  filteredOptionInUseList: OptionsInUse[] = [];
  input: HTMLElement;

  constructor(public dialogRef: MatDialogRef<OracleLicenseDialogComponent>, private config: ConfigService,
    private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  private supportStatusSub: Subscription;
  private optionsInUseSub: Subscription;

  ngOnInit() {

    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
    if (this.data.mode !== 'View') {
      this.setEditData();
    }
    this.getOptions();
  }

  changeMode() {
    this.data.mode = 'Edit';
    this.setEditData();
  }

  setEditData() {
    this.form = new FormGroup({ // intialise form
      'product_name': new FormControl(null, {validators: [Validators.required]
      }),
      'quantity': new FormControl(null, {validators: [Validators.required]
      }),
      'metric': new FormControl(null
      ),
      'term': new FormControl(null
      ),
      'license_type': new FormControl(null
      ),
      'restrictions': new FormControl(null
      ),
      'license_notes': new FormControl(null
      ),
      'support_status': new FormControl(null
      ),
      'support_end_date': new FormControl(null
      ),
      'unit_price': new FormControl(null
      ),
      'total_cost': new FormControl(null
      ),
      'discount': new FormControl(null
      ),
      'allocated': new FormControl(null
      ),
      'allowed': new FormControl(null
      )
    });
    this.config.getSupportStatus();
    this.supportStatusSub = this.config.getSupportStatusListener().subscribe((supportStatusData: {supportStatuses: SupportStatus[]}) => {
      this.supportStatusList  = supportStatusData.supportStatuses;
    });

    this.metricsList = this.data.metrics;
    this.filteredMetrics = this.metricsList;
    this.termsList = this.data.terms;
    this.filteredTerms = this.termsList;
    this.typesList = this.data.types;
    this.filteredTypes = this.typesList;
    if (this.data.oracle_license) {
      this.form.addControl('_id', new FormControl(null));
      this.oracleLicenses = {
        _id: this.data.oracle_license._id,
        product_name: this.data.oracle_license.product_name,
        quantity: this.data.oracle_license.quantity,
        metric: this.data.oracle_license.metric,
        term: this.data.oracle_license.term,
        license_type: this.data.oracle_license.license_type,
        restrictions: this.data.oracle_license.restrictions,
        license_notes: this.data.oracle_license.license_notes,
        support_status: this.data.oracle_license.support_status,
        support_end_date: this.data.oracle_license.support_end_date,
        unit_price: this.data.oracle_license.unit_price,
        total_cost: this.data.oracle_license.total_cost,
        discount: this.data.oracle_license.discount,
        allocated: this.data.oracle_license.allocated,
        allowed: this.data.oracle_license.allowed,
        migrated_from: this.data.migrated_from,
        migrated_to: this.data.migrated_to,
        migration_date: this.data.migration_date
      };
      this.form.patchValue({
        '_id': this.data.oracle_license._id,
        'product_name': this.oracleLicenses.product_name,
        'quantity': this.oracleLicenses.quantity,
        'metric': this.oracleLicenses.metric,
        'term': this.oracleLicenses.term,
        'license_type': this.oracleLicenses.license_type,
        'restrictions': this.oracleLicenses.restrictions,
        'license_notes': this.oracleLicenses.license_notes,
        'support_status': this.oracleLicenses.support_status,
        'support_end_date': this.oracleLicenses.support_end_date,
        'unit_price': this.oracleLicenses.unit_price,
        'total_cost': this.oracleLicenses.total_cost,
        'discount': this.oracleLicenses.discount,
        'allocated': this.oracleLicenses.allocated,
        'allowed': this.oracleLicenses.allowed
      });
    }
  }

  getOptions() {
    this.config.getOptionsInUse();
    this.optionsInUseSub = this.config.getOptionsInUseListener()
    .subscribe((optionsInUseData: {optionInUse: OptionsInUse[]}) => {
      this.optionInUseList = optionsInUseData.optionInUse;
    });
  }

  ngOnDestroy() {
    if (this.supportStatusSub) {
      this.supportStatusSub.unsubscribe();
    }
    this.optionsInUseSub.unsubscribe();
  }

  save () {
    
    this.form.patchValue({'allowed': this.form.value.quantity - this.form.value.allocated});
    if ((this.form.value.unit_price !== null) && (this.form.value.unit_price !== 0)
    && (typeof this.form.value.unit_price !== 'number')) {
      this.form.patchValue({'unit_price': this.form.value.unit_price.replace(/,/g, '')});
    }
    if ((this.form.value.total_cost !== null) && (this.form.value.total_cost !== 0)
    && (typeof this.form.value.total_cost !== 'number')) {
      this.form.patchValue({'total_cost': this.form.value.total_cost.replace(/,/g, '')});
    }
    this.dialogRef.close(this.form.value);
  }

  filterMetricList(filterValue: any) {
    this.filteredMetrics = [];
    this.metricsList.forEach(metric => {
      if ( metric.toLowerCase().includes(filterValue)) {
        this.filteredMetrics.push(metric);
      }
    });
  }

  filterTermList(filterValue: any) {
    this.filteredTerms = [];
    this.termsList.forEach(term => {
      if (term.toLowerCase().includes(filterValue)) {
        this.filteredTerms.push(term);
      }
    });
  }

  filterTypesList(filterValue: any) {
    this.filteredTypes = [];
    this.typesList.forEach(type => {
      if (type.toLowerCase().includes(filterValue)) {
        this.filteredTypes.push(type);
      }
    });
  }

  filterOptions(val) {
    this.filteredOptionInUseList = this.optionInUseList.filter(opt => opt.option.toLowerCase().includes(val.toLowerCase()));
  }

  onSelectedOption(option) {
    this.form.patchValue({product_name: option});
  }

}

