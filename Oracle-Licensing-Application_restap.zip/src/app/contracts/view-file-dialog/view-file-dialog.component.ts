// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

// services
import { ContractService } from '../contracts.service';
import { FileService } from 'src/app/file.service';

// misc
import { saveAs } from 'file-saver';
import printJS from 'print-js';

@Component({
  selector: 'app-view-file-dialog',
  templateUrl: './view-file-dialog.component.html',
  styleUrls: ['./view-file-dialog.component.css'],
  providers: [FileService]
})

export class ViewFileDialogComponent implements OnInit {

  imagepath: any;
  fileName: String;
  fileLocation: String;

  src: string;
  page = 1;
  totalPages: number;
  isLoaded = false;
  mode = this.data.mode;

  constructor(public dialogRef: MatDialogRef<ViewFileDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public contractService: ContractService, private fileService: FileService) {}

    ngOnInit() {
      this.imagepath = this.data.image;
    }

    afterLoadComplete(pdfData: any) {
      this.totalPages = pdfData.numPages;
      this.isLoaded = true;
    }

    print() {
      if (this.data.file.filetype === 'images') {
        this.fileName = this.data.file.filepath.split('/images/')[1];
      } else {
        this.fileName = this.data.file.filepath.split('/files/')[1];
      }
      this.fileService.downloadFile(this.fileName, this.data.file.filetype)
      .subscribe(
       /*data =>  {
         if (window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(data, this.data.file.fileName);
          } else {
            const fileURL = URL.createObjectURL(data);
            const a: HTMLAnchorElement = document.createElement('a');
            a.href = fileURL;
            a.target = '_blank';
            document.body.appendChild(a);
            a.click();
          }},*/
        data => {
        const pdfUrl = URL.createObjectURL(data);
        printJS(pdfUrl);
        },
        error => console.error(error)
      );
    }

    nextPage() {
      this.page++;
    }

    prevPage() {
      this.page--;
    }

    downloadFile(file: any) {
      if (file.filetype === 'images') {
        this.fileName = file.filepath.split('/images/')[1];
      } else {
        this.fileName = file.filepath.split('/files/')[1];
      }
      this.fileService.downloadFile(this.fileName, file.filetype)
      .subscribe(
        data => saveAs(data, this.fileName),
        error => console.error(error)
      );
    }

    close () {
      this.dialogRef.close();
    }

}
