// angular
import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormGroup, FormControl, Validators, AbstractControl, FormGroupDirective, NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { MAT_DATE_FORMATS, ErrorStateMatcher, ShowOnDirtyErrorStateMatcher } from '@angular/material/core';

// models
import { SupportContract } from '../contract.model';
import { Currency } from '../../config/config.model';

// services
import { ConfigService } from '../../config/config.service';
import { FileService } from 'src/app/file.service';
import { ThemeService } from '../../theme.service';

// components
import { ViewFileDialogComponent } from '../view-file-dialog/view-file-dialog.component';

// misc
import { CustomValidators } from '../../customer.validator';
import { saveAs } from 'file-saver';
import { PDFSource } from 'ng2-pdf-viewer';
import { mimeType } from '../contracts-create/mime-type.validator';
import { Subscription } from 'rxjs';

export const MY_FORMATS = {
  parse: {
    dateInput: 'll',
  },
  display: {
    dateInput: 'll',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'll',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-support-contract-dialog',
  templateUrl: './support-contract-dialog.component.html',
  styleUrls: ['./support-contract-dialog.component.css'],
  providers: [[FileService],
              ThemeService,
              {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}],
})
export class SupportContractDialogComponent implements OnInit, OnDestroy {

  // for view mode
  fileName;
  fileListByName = [];
  file = { filename: '', filepath: '', filetype: ''};
  viewHeight;
  viewWidth;
  pdfSrc: string | PDFSource | ArrayBuffer;
  public innerWidth: any;
  public innerHeight: any;

  form: FormGroup;
  matcher = new MyErrorStateMatcher();
  mode = 'create';
  supportContract: SupportContract;
  supportTerms: string[] = [];
  filteredSupportTerms: string[] = [];
  imagesEditPreview = [];
  imagesPreview = [];
  fileArray: File[];
  pathArray: String[] = null;
  selectedCurrencySymbol = '$';
  selectedCurrency = '';
  currencyObject = null;
  currencyList = [];
  isNumber: any;

  constructor(public dialogRef: MatDialogRef<SupportContractDialogComponent>, public route: ActivatedRoute,
     private _snackBar: MatSnackBar, private fileService: FileService,  public dialog: MatDialog, private config: ConfigService,
     private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  private currencySub: Subscription;

  ngOnInit() {

    console.log(this.matcher);
    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }
    if (this.data.mode === 'View') {
      console.log(this.data);
      this.getFileName(this.data.support_contract.support_filepaths);
    } else {
      this.setEditData();
    }
    this.innerWidth = window.innerWidth;
    this.innerHeight = window.innerHeight;
  }

  setEditData () {
    this.form = new FormGroup({ // intialise form
      'support_contract_number': new FormControl(null, {validators: [Validators.required]
      }),
      'support_start_date': new FormControl(null, {validators: [Validators.required]
      }),
      'support_end_date': new FormControl(null
      ),
      'support_term': new FormControl(null
      ),
      'support_offer_expiration': new FormControl(null
      ),
      'support_representive': new FormControl(null
      ),
      'support_service_number': new FormControl(null, [CustomValidators.isNumberValidator]
      ),
      'total_price': new FormControl(null
      ),
      'currency': new FormControl(null
      ),
      'line_price': new FormControl(null
      ),
      'image': new FormControl(null, {asyncValidators: [mimeType]
      }),
      'support_filepaths': new FormControl(null
      ),
      'support_filenames_toupload': new FormControl(null
      ),
    });
    this.config.getCurrencies();
    this.currencySub = this.config.getCurrenciesListener().subscribe((currencyData: {currencies: Currency[]}) => {
      this.currencyList = currencyData.currencies;
    });
    if (this.data) {
      this.supportTerms = this.data.terms;
      this.filteredSupportTerms = this.supportTerms;
    if (this.data.support_contract) {
      this.supportContract = {
        _id: this.data.support_contract._id,
        support_contract_number: this.data.support_contract.support_contract_number,
        support_start_date: this.data.support_contract.support_start_date,
        support_end_date: this.data.support_contract.support_end_date,
        support_term: this.data.support_contract.support_term,
        support_offer_expiration: this.data.support_contract.support_offer_expiration,
        support_representive: this.data.support_contract.support_representive,
        support_service_number: this.data.support_contract.support_service_number,
        total_price: this.data.support_contract.total_price,
        currency: this.data.support_contract.currency,
        line_price: this.data.support_contract.line_price,
        support_filepaths: this.data.support_contract.support_filepaths,
        support_filenames_toupload: this.data.support_contract.support_filenames_toupload,
        image: null
      };
      this.currencyList.forEach(currency => {
        if (this.data.support_contract.currency) {
          if ((this.data.support_contract.currency).includes(currency.country)) {
            this.currencyObject = currency;
            this.selectedCurrencySymbol = currency.symbol;
          }
        }
      });
      this.selectedCurrency = this.data.support_contract.currency;
      if (this.supportContract.support_filenames_toupload === undefined) {
        this.supportContract.support_filenames_toupload = null;
      }
      this.form.patchValue({
        '_id': this.supportContract._id,
        'support_contract_number': this.supportContract.support_contract_number,
        'support_start_date': this.supportContract.support_start_date,
        'support_end_date': this.supportContract.support_end_date,
        'support_term': this.supportContract.support_term,
        'support_offer_expiration': this.supportContract.support_offer_expiration,
        'support_representive': this.supportContract.support_representive,
        'support_service_number': this.supportContract.support_service_number,
        'total_price': this.supportContract.total_price,
        'currency': this.currencyObject,
        'line_price': this.supportContract.line_price,
        'image': this.supportContract.image,
        'support_filepaths': this.supportContract.support_filepaths,
        'support_filenames_toupload': this.supportContract.support_filenames_toupload
      });
      this.imagesEditPreview = this.supportContract.support_filepaths;
      if (this.data.support_contract.image) {
        this.onImageEdit(this.data.support_contract.image);
      }
    }
    }
  }

  onImageEdit(files: [File]) {
    const selectedFiles = files;
    this.imagesPreview = [];
    if (this.fileArray === undefined ) {
      this.fileArray = Array.from(selectedFiles);
    } else {
      this.fileArray = (Array.from(selectedFiles)).concat(this.fileArray);
    }
    if (selectedFiles === undefined) {return; }
    for (const file of this.fileArray) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imagesPreview.push(<string>reader.result);
      };
      reader.readAsDataURL(file);
    }
  }

  onImagesPicked(event) {
    const selectedFiles = (event.target as HTMLInputElement).files;
    this.imagesPreview = [];
    if (selectedFiles === undefined) {return; }
    if (this.fileArray === undefined) {
      this.fileArray = Array.from(selectedFiles);
    } else {
      this.fileArray = (Array.from(selectedFiles)).concat(this.fileArray);
    }
    for (const file of this.fileArray) {
      if (this.pathArray === null) {
        this.pathArray = [];
        this.pathArray.push(file.name);
      } else {
        this.pathArray.push(file.name);
      }
      this.form.patchValue({'image' : file}); // needed for validation
      this.form.get('image').updateValueAndValidity();
      const reader = new FileReader();
      reader.onload = () => {
        this.imagesPreview.push(<string>reader.result);
      };
      reader.readAsDataURL(file);
    }
    let str = '';
    this.fileArray.forEach(function(element) {
      str = str + element.name + ', ';
    });
    this.openSnackBar('Files Uploaded: ', str );
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
    });
  }

  filterSupportTerms(filterValue: any) {
    this.filteredSupportTerms = [];
    this.supportTerms.forEach(term => {
      if (term.toLowerCase().includes(filterValue)) {
        this.filteredSupportTerms.push(term);
      }
    });
  }

  onSelectedCurrency(currency) {
    this.selectedCurrencySymbol = currency.symbol;
    this.selectedCurrency = currency.country + '-' + currency.currency;
  }

  /*
  isNumberValidator(control: AbstractControl) : { [key: string]: boolean } | null {
    if (typeof(control.value) !== 'number') {
      return {'isNumber': true}
    }
    return null;
  }*/

  save() {
    console.log(this.matcher);
    //console.log(this.form.value.total_price);
    // if (this.form.invalid) {
    //   return;
    // } else {
    //   console.log('all is gucci');
    // }
    
    this.form.patchValue({'support_filenames_toupload' : this.pathArray});
    if (this.fileArray !== undefined) {
      this.form.patchValue({'image' : this.fileArray});
    }
    this.form.patchValue({'currency' : this.selectedCurrency });
    if ((this.form.value.line_price !== null) && (this.form.value.line_price !== 0) && (typeof this.form.value.line_price !== 'number')) {
      this.form.patchValue({'line_price': this.form.value.line_price.toString().replace(/,/g, '')});
    }
    if ((this.form.value.total_price !== null) && (this.form.value.total_price !== 0) && (typeof this.form.value.line_price !== 'number')) {
      this.form.patchValue({'total_price': this.form.value.total_price.toString().replace(/,/g, '')});
    }
    this.dialogRef.close(this.form.value);
  }

  getFileName(filepaths: any) {
    if (filepaths === null) {
      return;
    }
    this.fileListByName = [];
    console.log(filepaths);
    for (let file of filepaths) {
      this.file = { filename: '', filepath: '', filetype: ''};
      if (file.includes('images')) {
        debugger;
        this.file.filepath = file;
        // file = file.split('localhost:3000/images/')[1];
        file = file.split('/images/')[1];
        this.file.filename = /.*(?=\-)/.exec(file)[0];
        this.file.filetype = 'images';
      } else {
        this.file.filepath = file;
        debugger;
        //file = file.split('localhost:3000/files/')[1];
        file = file.split('/files/')[1];
        this.file.filename = /.*(?=\-)/.exec(file)[0];
        this.file.filetype = 'files';
      }
      this.fileListByName.push(this.file);
    }
  }

  getImageDimensions(j: any) {
    const theImage = new Image();
    theImage.src =  (String) (this.data.support_contract.support_filepaths[j]);
    theImage.onload = () => {
       this.viewHeight = theImage.height;
       this.viewWidth = theImage.width;
       this.openViewFileDialog(j);
    };
  }

  openViewFileDialog (j: any): void {

    const dialogRef = this.dialog.open(ViewFileDialogComponent, {
      panelClass: 'app-full-image-dialog', // changes default mat-dialog styling
      height: this.viewHeight.toString() + 'px',
      width: this.viewWidth.toString() + 'px',
      data: {image: this.data.support_contract.support_filepaths[j], mode: 'Image'}
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  downloadFile(file: any) {
    console.log(file);
    debugger;
    if (file.filetype === 'images') {
      this.fileName = file.filepath.split('/images/')[1];
    } else {
      this.fileName = file.filepath.split('/files/')[1];
    }
    console.log(this.fileName);
    this.fileService.downloadFile(this.fileName, file.filetype)
    .subscribe(
      data => saveAs(data, this.fileName),
      error => console.error(error)
    );
  }

  openPDF(file: any) {
    debugger;
    //this.fileName = file.filepath.split('localhost:3000/files/')[1];
    this.fileName = file.filepath.split('/files/')[1];
    this.fileService.downloadFile(this.fileName, file.filetype).subscribe(
      data => {
        this.pdfSrc = URL.createObjectURL(data);
        const newWidth = (this.innerWidth / 1.414);
        console.log('Height: ' + this.innerHeight + ' Width: ' + this.innerWidth);
        const dialogRef = this.dialog.open(ViewFileDialogComponent, {
        height: this.innerHeight.toString() + 'px',
        width: newWidth.toString() + 'px',
        data: {pdf: this.pdfSrc, mode: 'File', fileName: this.fileName, file: file }
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      }); },
      error => console.error(error)
    );
  }

  changeMode() {
    this.data.mode = 'Edit';
    this.setEditData();
  }

  ngOnDestroy() {
    if (this.currencySub) {
      this.currencySub.unsubscribe();
    }
  }

}
