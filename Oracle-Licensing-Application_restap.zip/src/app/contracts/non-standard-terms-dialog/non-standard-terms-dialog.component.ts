// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material';

// models
import { NonStandardTerms } from '../contract.model';

// services
import { ThemeService } from '../../theme.service';
import { FileService } from 'src/app/file.service';

// components
import { ViewFileDialogComponent } from '../view-file-dialog/view-file-dialog.component';

// misc
import { saveAs } from 'file-saver';
import { PDFSource } from 'ng2-pdf-viewer';
import { mimeType } from '../contracts-create/mime-type.validator';

@Component({
  selector: 'app-non-standard-terms-dialog',
  templateUrl: './non-standard-terms-dialog.component.html',
  styleUrls: ['./non-standard-terms-dialog.component.css'],
  providers: [FileService, ThemeService]
})

export class NonStandardTermsDialogComponent implements OnInit {

  form: FormGroup;
  mode = 'create';
  nonStandardTerms: NonStandardTerms;
  imagesEditPreview = [];
  imagesPreview = [];
  fileArray: File[];
  pathArray: String[] = null;

  // for view mode
  fileName;
  fileListByName = [];
  file = { filename: '', filepath: '', filetype: ''};
  viewHeight;
  viewWidth;
  pdfSrc: string | PDFSource | ArrayBuffer;
  public innerWidth: any;
  public innerHeight: any;

  constructor(public dialogRef: MatDialogRef<NonStandardTermsDialogComponent>,
    private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, private fileService: FileService,
    public dialog: MatDialog) {}

    ngOnInit() {
      if (this.themeService.getThemeSelected() === true ) {
        this.dialogRef.addPanelClass('dark-theme');
      }
      if (this.data.mode === 'View') {
        this.getFileName(this.data.non_standard_terms.term_filepaths);
      } else {
        this.setEditData();
      }
      this.innerWidth = window.innerWidth;
      this.innerHeight = window.innerHeight;

    }
    changeMode () {
      this.data.mode = 'Edit';
      this.setEditData();
    }
    setEditData() {
      this.form = new FormGroup({
        'term_name': new FormControl(null
        ),
        'term_description': new FormControl(null
        ),
        'image': new FormControl(null, {asyncValidators: [mimeType]
        }),
        'term_filepaths': new FormControl(null
        ),
        'term_filenames_toupload': new FormControl(null
        ),
      });
      if (this.data.non_standard_terms) {
        this.nonStandardTerms = {
          _id: this.data.non_standard_terms._id,
          term_name: this.data.non_standard_terms.term_name,
          term_description: this.data.non_standard_terms.term_description,
          term_filepaths: this.data.non_standard_terms.term_filepaths,
          term_filenames_toupload: this.data.non_standard_terms.term_filenames_toupload,
          image: null
        };
        if (this.nonStandardTerms.term_filenames_toupload === undefined) {
          this.nonStandardTerms.term_filenames_toupload = null;
        }
        this.form.patchValue({
          '_id': this.nonStandardTerms._id,
          'term_name': this.nonStandardTerms.term_name,
          'term_description': this.nonStandardTerms.term_description,
          'image': this.nonStandardTerms.image,
          'term_filepaths': this.nonStandardTerms.term_filepaths,
          'term_filenames_toupload': this.nonStandardTerms.term_filenames_toupload
        });
        this.imagesEditPreview = this.nonStandardTerms.term_filepaths;
        if (this.data.non_standard_terms.image) {
          this.onImageEdit(this.data.non_standard_terms.image);
        }
      }
    }

    // turns image data into a readable ohject
    onImageEdit(files: [File]) {
      const selectedFiles = files;
      this.imagesPreview = [];
      if (this.fileArray === undefined ) {
        this.fileArray = Array.from(selectedFiles);
      } else {
        this.fileArray = (Array.from(selectedFiles)).concat(this.fileArray);
      }
      if (selectedFiles === undefined || selectedFiles === null) {return; }
      for (const file of this.fileArray) {
        const reader = new FileReader();
        reader.onload = () => {
          this.imagesPreview.push(<string>reader.result);
        };
        reader.readAsDataURL(file);
      }
    }

    onImagesPicked(event) {
      const selectedFiles = (event.target as HTMLInputElement).files;
      this.imagesPreview = [];
      if (this.fileArray === undefined ) {
        this.fileArray = Array.from(selectedFiles);
      } else {
        this.fileArray = (Array.from(selectedFiles)).concat(this.fileArray);
      }
      if (selectedFiles === undefined) {return; }
      for (const file of this.fileArray) {
        if (this.pathArray === null) {
          this.pathArray = [];
          this.pathArray.push(file.name);
        } else {
          this.pathArray.push(file.name);
        }
        this.form.patchValue({'image' : file}); // needed for validation
        this.form.get('image').updateValueAndValidity();
        const reader = new FileReader();
        reader.onload = () => {
          this.imagesPreview.push(<string>reader.result);
        };
        reader.readAsDataURL(file);
      }
      let str = '';
      this.fileArray.forEach(function(element) {
        str = str + element.name + ', ';
      });
      this.openSnackBar('Files Uploaded: ', str );
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
    });
  }

  save() {
    this.form.patchValue({'term_filenames_toupload' : this.pathArray});
    this.form.patchValue({'image' : this.fileArray});
    this.dialogRef.close(this.form.value);
  }

  // for view mode
  getFileName(filepaths: any) {
    if (filepaths === null) {
      return;
    }
    this.fileListByName = [];
    for (let file of filepaths) {
      this.file = { filename: '', filepath: '', filetype: ''};
      if (file.includes('images')) {
        this.file.filepath = file;
        file = file.split('localhost:3000/images/')[1];
        this.file.filename = /.*(?=\-)/.exec(file)[0];
        this.file.filetype = 'images';
      } else {
        this.file.filepath = file;
        file = file.split('localhost:3000/files/')[1];
        this.file.filename = /.*(?=\-)/.exec(file)[0];
        this.file.filetype = 'files';
      }
      this.fileListByName.push(this.file);
    }
  }

  getImageDimensions(j: any) {
    const theImage = new Image();
    theImage.src =  (String) (this.data.non_standard_terms.term_filepaths[j]);
    theImage.onload = () => {
       this.viewHeight = theImage.height;
       this.viewWidth = theImage.width;
       this.openViewFileDialog(j);
    };
  }

  openViewFileDialog (j: any): void {

    const dialogRef = this.dialog.open(ViewFileDialogComponent, {
      panelClass: 'app-full-image-dialog', // changes default mat-dialog styling
      height: this.viewHeight.toString() + 'px',
      width: this.viewWidth.toString() + 'px',
      data: {image: this.data.non_standard_terms.term_filepaths[j], mode: 'Image'}
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
}

  downloadFile(file: any) {
    if (file.filetype === 'images') {
      this.fileName = file.filepath.split('localhost:3000/images/')[1];
    } else {
      this.fileName = file.filepath.split('localhost:3000/files/')[1];
    }
    this.fileService.downloadFile(this.fileName, file.filetype)
    .subscribe(
      data => saveAs(data, this.fileName),
      error => console.error(error)
    );
  }

  openPDF(file: any) {
    this.fileName = file.filepath.split('localhost:3000/files/')[1];
    this.fileService.downloadFile(this.fileName, file.filetype).subscribe(
      data => {
        this.pdfSrc = URL.createObjectURL(data);
        const newWidth = (this.innerWidth / 1.414);
        console.log('Height: ' + this.innerHeight + ' Width: ' + this.innerWidth);
        const dialogRef = this.dialog.open(ViewFileDialogComponent, {
        height: this.innerHeight.toString() + 'px',
        width: newWidth.toString() + 'px',
        data: {pdf: this.pdfSrc, mode: 'File', fileName: this.fileName, file: file }
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      }); },
      error => console.error(error)
    );
  }


}
