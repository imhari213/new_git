// angular
import { Component, OnInit, OnDestroy, HostListener, } from '@angular/core';
import { PageEvent } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';

// models
import { Contract, NonStandardTerms, SupportContract, OracleLicenses } from '../contract.model';
import { Company } from '../../companies/company.model';

// services
import { ContractService } from '../contracts.service';
import { CompanyService } from '../../companies/companies.service';
import { FileService } from 'src/app/file.service';
import { AuthService } from 'src/app/auth/auth.service';
import { OptionsService } from '../../options.service';

// components
import { SupportContractDialogComponent } from '../support-contract-dialog/support-contract-dialog.component';
import { NonStandardTermsDialogComponent } from '../non-standard-terms-dialog/non-standard-terms-dialog.component';
import { OracleLicenseDialogComponent } from '../oracle-license-dialog/oracle-license-dialog.component';
import { DeleteConfirmationComponent } from 'src/app/deletePopUp/delete-confirmation-dialog.component';
import { AssignHardwareDialogComponent } from '../assign-hardware-dialog/assign-hardware-dialog.component';
import { ViewFileDialogComponent } from '../view-file-dialog/view-file-dialog.component';
import { MigrateContractDialogComponent } from '../migrate-contract-dialog/migrate-contract-dialog.component';

// misc
import { Subscription } from 'rxjs';
import { AuditService } from 'src/app/audit/audit.service';
import { saveAs } from 'file-saver';
import { PDFSource } from 'ng2-pdf-viewer';

@Component({
  selector: 'app-contract-list',
  templateUrl: './contracts-list.component.html',
  styleUrls: ['./contracts-list.component.css'],
  providers: [FileService]
})

export class ContractListComponent implements OnInit, OnDestroy {

  userIsAuthenticated: boolean;
  userRole = 'read';
  subNames = [];
  isLoading = false;

  totalContracts = 0;
  contractsPerPage = 20;
  pageSizeOptions = [20, 50, 100];
  currentPage = 1;
  changePageSize = false;
  sortType;
  contractIndex;

  companyId;
  companies: Company[];
  contracts: Contract[];
  oracleLicenses: [OracleLicenses];
  nonStandardTerms: [NonStandardTerms];
  supportContracts: [SupportContract];

  contract: Contract;
  contractId;
  newHardWareCount = [];

  filteredLicensesBool = true;
  filteredLicenseList = <any>[];
  anyLicenseTermination = false;

  metricList = [];
  termList = [];
  typeList = [];

  fileLocation: String;
  fileListByName = [];
  fileName;
  fileArray: File[];
  file = { filename: '', filepath: '', filetype: ''};
  pdfSrc: string | PDFSource | ArrayBuffer;
  viewContractHeight;
  viewContractWidth;
  public innerWidth: any;
  public innerHeight: any;

  subsidiaryList = [];
  substring = '';
  companyName: string;
  checkedHeader;
  pageChosen = null;
  compareContractId = null;

  dataSourceOracleLicence: MatTableDataSource<OracleLicenses>;
  dataSourceContracts: any;
  displayedColumnsOracleLicence: string[] = ['productName', 'Metric', 'License Type', 'Restrictions', 'Allocations',
                                            'Availability', 'view', 'edit'];
  dataSourceSupportContract: any;
  displayedColumnsSupportContract: string[] = ['supportContractName', 'supportTerm', 'LinePrice', 'view', 'edit'];
  dataSourceNonStandardTerms: any;
  displayedColumnsNonStandardTerms: string[] = ['termName', 'view', 'edit'];
  displayedContractHeaders: string[] = ['contractIdentifier', 'contractCsi', 'contractDate', 'contractTerminated'];

  authStatusSub: Subscription;
  companySub: Subscription;
  contractSub: Subscription;
  searchParam: string;
  headerOptionSub: Subscription;

  completeContractColumns = [
    {name: 'Order Identifier', modelName: 'order_identifier'},
    {name: 'CSI', modelName: 'customer_support_identifier'},
    {name: 'Contract Date', modelName: 'contract_date'},
    {name: 'Contract Territory', modelName: 'contract_territory'},
    {name: 'Contract Terminated', modelName: 'contract_terminated'},
    {name: 'Total Capex Cost', modelName: 'total_capex_cost_of_contract'},
    {name: 'Company', modelName: 'end_user'},
    {name: 'Signed By', modelName: 'signed_by'},
    {name: 'Signed By Date', modelName: 'signed_by_date'},
    {name: 'Contract Upload', modelName: 'contract_upload'},
    {name: 'Contract Type', modelName: 'contract_type'}
  ];

  currentContractColumns = [
    {name: 'Order Identifier', modelName: 'order_identifier'},
    {name: 'CSI', modelName: 'customer_support_identifier'},
    {name: 'Contract Date', modelName: 'contract_date'},
    {name: 'Contract Status', modelName: 'contract_terminated'},
  ];
//Contract Status 

  constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute,
              private companyService: CompanyService, private contractService: ContractService, private dialog: MatDialog,
              private auditService: AuditService, private fileService: FileService, private optionsService: OptionsService) {}

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = window.innerWidth;
    this.innerHeight = window.innerHeight;
  }

  ngOnInit() {
    this.innerWidth = window.innerWidth;
    this.innerHeight = window.innerHeight;
    this.isLoading = true;
    this.pageChosen = 'FIRST';


    this.getAuth();
    if (localStorage.getItem('compId')) { this.companyId = localStorage.getItem('compId'); }
    this.route.paramMap.subscribe(paramMap => {
      if (paramMap.has('companyId')) { this.companyId = paramMap.get('companyId'); }
    });

    (async () => { this.getCompanies(); })();
    (async () => { this.getContracts(); })();
    this.checkedHeader = this.optionsService.getHeaderOption();
    this.headerOptionSub = this.optionsService.headerOptionListener().subscribe((data) => {
      this.checkedHeader = data;
    });
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
    if (this.companySub) {
      this.companySub.unsubscribe();
    }
    if (this.contractSub) {
      this.contractSub.unsubscribe();
    }
  }


  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }

    if (this.userRole === 'read') {
      this.displayedColumnsSupportContract = ['supportContractName', 'supportTerm', 'LinePrice', 'view'];
    }

  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
        this.companies = companyData.companies;
      });
  }

  getContracts() {
    this.contractService.searchContract(
      this.companyId, this.searchParam, this.pageChosen, this.compareContractId,
      this.contractsPerPage, this.currentPage, this.sortType
    );
    this.contractSub = this.contractService.getContractUpdateListener()
    .subscribe((contractData: {contracts: Contract[]; contractCount: number, hardwareCount: any}) => {
      this.contracts = contractData.contracts;
      this.newHardWareCount = contractData.hardwareCount;
      this.totalContracts = contractData.contractCount;
      this.dataSourceContracts = new MatTableDataSource(this.contracts);
      this.changePageSize = false;
      this.pageChosen = null;
      this.compareContractId = null;
      this.isLoading = false;
    });
  }

  onSearch(search: string) {
    if (search === '') { this.searchParam = undefined; } else { this.searchParam = search; }
    this.pageChosen = 'FIRST';
    this.currentPage = 1;
    this.getContracts();
  }

  setSortType(type) {
    this.pageChosen = 'FIRST';
    this.sortType = type;
    this.getContracts();
  }

  formatBool(element) {
    if (element === true) {
      return 'Yes';
    } else {
      return 'No';
    }
  }

  anyTerminated(licenses) {
    let anyTerminated = false;
    licenses.forEach(license => {
      if (license.migration_date) {
        anyTerminated = true;
      }
    });

    return anyTerminated;
  }

  getColumnsClicked(option, event) {
    if (event === true) {
      this.currentContractColumns.push(option);
    } else {
      const index = this.currentContractColumns.indexOf(option);
      this.currentContractColumns.splice(index, 1);
    }
  }

  getCheckedBoolean(column) {
    return this.currentContractColumns.find(object => object['name'] === column.name);
   }

  onExpand(contract, index) {
   
    this.subNames = [];
    this.contract = contract;
    debugger;
    console.log(this.contract);
    console.log(this.contract.support_contract);
    if (index || index === 0) { this.contractIndex = index; }
    if (!index) { this.contracts[this.contractIndex].oracle_licenses = this.contract.oracle_licenses; }

   // (this.contract.support_contract == undefined) ? this.contract.support_contract = [] : this.contract.support_contract ;

    this.oracleLicenses = this.contract.oracle_licenses;
    this.nonStandardTerms = this.contract.non_standard_terms;
    this.supportContracts = this.contract.support_contract;

    this.contractId = contract._id;
    this.getFileName(contract.contract_imagepath);

    if (contract.end_user_accepted_subsidiaries && contract.end_user_accepted_subsidiaries.length > 0) {
      this.companyService.getListSubNames(contract.end_user).subscribe(result => {
        this.subNames = result.subNameList;
      });
    }

    this.filteredLicenseList = this.contract.oracle_licenses.filter(lic => {
      if (!lic.migration_date && (lic.allowed > 0 || lic.allowed === -1)) { return true; } else { return false; }
    });

    this.dataSourceOracleLicence = new MatTableDataSource(this.filteredLicenseList);
    this.dataSourceNonStandardTerms = new MatTableDataSource(this.nonStandardTerms);
    this.dataSourceSupportContract = new MatTableDataSource(this.supportContracts);

  }

  filterLicences(event): void {
    if (event) {
      this.filteredLicensesBool = !this.filteredLicensesBool;
    }

    if (this.filteredLicensesBool) {
      this.filteredLicenseList = this.contract.oracle_licenses.filter(lic => {
        if (!lic.migration_date && (lic.allowed > 0 || lic.allowed === -1)) { return true; } else { return false; }
      });
     }
    if (!this.filteredLicensesBool) { this.filteredLicenseList = this.oracleLicenses; }

    this.dataSourceOracleLicence = new MatTableDataSource(this.filteredLicenseList);
  }

  onChangePage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    const numOfPages = Math.ceil(this.totalContracts / this.contractsPerPage);
    if (pageData.pageIndex + 1 === numOfPages) {
      this.pageChosen = 'LAST';
    } else if (pageData.pageIndex > pageData.previousPageIndex) {
      this.pageChosen = 'NEXT';
      this.compareContractId = this.contracts[this.contracts.length - 1]._id;
    } else if (pageData.pageIndex === 0) {
      this.pageChosen = 'FIRST';
    } else {
      this.pageChosen = 'PREVIOUS';
      this.compareContractId = this.contracts[0]._id;
    }

    if (pageData.pageSize !== this.contractsPerPage) {
      this.contractsPerPage = pageData.pageSize;
      this.changePageSize = true;
    }

    this.getContracts();
  }

  hardwareByContract(contractId, companyId) {
    localStorage.setItem('contractId', contractId);
    this.router.navigate(['/list-hardware/']);
  }

  databaseByCompany(contractId, companyId) {
    localStorage.setItem('contractId', contractId);
    this.router.navigate(['/list-database/']);
  }

  onDelete(event, contract: Contract) {
    event.stopPropagation();

    const dialogRef = this.dialog.open(DeleteConfirmationComponent, {
      data: {name: contract.customer_support_identifier, pageViewName: 'contract'}
    });

    dialogRef.afterClosed().subscribe(confirmation => {
      if (confirmation) {
        this.contractService.deleteContract(contract._id).subscribe(response => {
          this.getContracts();
        });
      }
    });
  }

  getCompany(companyId) {
    try {
     return this.companies.find(comp => comp._id === companyId).company_name;
    } catch {
      return 'Unknown';
    }
  }

  licenseDialogBox(license: any, mode: String): void {
    let dialogRef;
    let currentPosition;

    if (license) {currentPosition = this.oracleLicenses.indexOf(license); }

    if (mode === 'View') {
      dialogRef = this.dialog.open(OracleLicenseDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {oracle_license: license, mode: mode}
      });
    } else if (license === null) {
      dialogRef = this.dialog.open(OracleLicenseDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {metrics: this.metricList, terms: this.termList, types: this.typeList, mode: mode}
      });
    } else {
      dialogRef = this.dialog.open(OracleLicenseDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {metrics: this.metricList, terms: this.termList, types: this.typeList,
              oracle_license: license, mode: mode}
      });
    }
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (license) {
          this.oracleLicenses.splice(currentPosition, 1 , result);
        } else {
            this.oracleLicenses.push(result);
        }

        this.contract.oracle_licenses = this.oracleLicenses;
        this.contractService.updateContract(this.contract._id, this.contract).subscribe(data => {
          this.onExpand(data.contract, null);
          /*
          if (license) {
            console.log('updated');
          } else {
            const addedOracle = data.contract.oracle_licenses[data.contract.oracle_licenses.length - 1];
            this.auditService.addAudit('contract', data.contract._id, 'add', data.contract.customer_support_identifier,
                                        'oracle', addedOracle._id, addedOracle.product_name);
          }*/
        });

      } else {
        console.log('no data was saved');
      }
    });
  }

  nonStandardTermDialogBox(nonStandard: any, mode: String): void {

    let currentPosition;
    let dialogRef;

    if (nonStandard) { currentPosition = this.nonStandardTerms.indexOf(nonStandard); }

    if (mode === 'View') {
      dialogRef = this.dialog.open(NonStandardTermsDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {non_standard_terms: nonStandard, mode: mode}
      });
    } else if (nonStandard === null) {
      dialogRef = this.dialog.open(NonStandardTermsDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {mode: mode}
      });
    } else {
      dialogRef = this.dialog.open(NonStandardTermsDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {non_standard_terms: nonStandard, mode: mode}
      });
    }

    dialogRef.afterClosed().subscribe( result => {
      if (result) {
        if (nonStandard) {
          this.nonStandardTerms.splice(currentPosition, 1, result);
        } else {
          this.nonStandardTerms.push(result);
        }

        for (const term of this.nonStandardTerms) { // grabs images in nst array and pushes into image array
          if ((term.image !== null) && (term.image !== undefined) && (term.image) !== '') {
            for (const img of term.image) {
              if (this.fileArray === undefined ) {
                this.fileArray = [];
              }
              this.fileArray.push(img); // adding nst images to img array
            }
          }
        }

        this.contract.image = this.fileArray;
        this.fileArray = []; // clears array for another edit/add
        this.contract.non_standard_terms = this.nonStandardTerms;

        this.contractService.updateContract(this.contractId, this.contract).subscribe(data => {
          this.onExpand(data.contract, null);
        });
      } else {
        console.log('no data was saved');
      }
    });
  }

  supportContractDialogBox(supportContract: any, mode: String): void {

    let dialogRef;
    let currentPosition;

    debugger;
    console.log(this.supportContracts);

     if (supportContract) { currentPosition = this.supportContracts.indexOf(supportContract); }

    if (mode === 'View') {
      dialogRef = this.dialog.open(SupportContractDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {support_contract: supportContract, mode: mode} // Filter
      });
    } else if (supportContract === null) {
      dialogRef = this.dialog.open(SupportContractDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {mode: mode}
      });
    } else {
      dialogRef = this.dialog.open(SupportContractDialogComponent, {
        disableClose: true,
        width: '50%',
        data: {support_contract: supportContract, mode: mode} // Filter
      });
    }

    dialogRef.afterClosed().subscribe(result => {
      debugger;
      if (result) {

        if (supportContract) {
          this.supportContracts.splice(currentPosition, 1, result);
        } else {
          if(this.supportContracts == undefined){
            this.supportContracts = result;
          }else{
          this.supportContracts.push(result);
          }
          console.log(this.supportContracts);
        }

        for (const support of this.supportContracts) {
          if ((support.image !== null) && (support.image !== undefined) && (support.image) !== '') {
            for (const img of support.image) {
              if (this.fileArray === undefined ) {
                this.fileArray = [];
              }
              this.fileArray.push(img); // adding support images to img array
            }
          }
        }

        this.contract.image = this.fileArray;
        this.fileArray = [];
        this.contract.support_contract = this.supportContracts;

        this.contractService.updateContract(this.contractId, this.contract).subscribe(data => {
          this.onExpand(data.contract, null);
        });
      } else {
        console.log('no data saved');
      }
    });
  }

  backToCompanies () {
    const compName = this.companies.find(comp => comp._id === this.companyId).company_name;
    this.router.navigate(['/company-details/' + compName]);
  }

  addContract() {
    if (this.companyId !== undefined) {
      this.router.navigate(['/add-contract/' + this.companyId]);
    } else {
      this.router.navigate(['/add-contract/']);
    }
  }

  assignHardware(element) {

    const index = this.contract.oracle_licenses.indexOf(element);

    const dialogRef = this.dialog.open(AssignHardwareDialogComponent, {
      disableClose: true,
      width: '50%',
      data: {oracleLicense: element, company: this.contract.end_user, contractId: this.contract._id}
    });

    dialogRef.afterClosed().subscribe(returnData => {
      if (returnData) {
        const allocated = returnData.data.allocated;
        const license = this.contract.oracle_licenses[index];

        if (license.quantity !== -1) {
          license.allowed -= allocated;
        }
        license.allocated += allocated;

        this.contractService.updateContract(this.contract._id, this.contract).subscribe(data => {
          const indexforHwList = this.contracts.indexOf(this.contract);
          if ( this.newHardWareCount[indexforHwList].length === 0 ||
            !this.newHardWareCount[indexforHwList].includes(returnData.data.hardwareId)) {
            this.newHardWareCount[indexforHwList].push(returnData.data.hardwareId);
          }
          this.onExpand(data.contract, null);
        });

      } else { console.log('closed'); }
    });
   }

   getImageDimensions(i, j) {
    const theImage = new Image();
    theImage.src =  (String) (this.contracts[i].contract_imagepath[j]);
    theImage.onload = () => {
       this.viewContractHeight = theImage.height;
       this.viewContractWidth = theImage.width;
       this.openViewContractFileDialog(i, j);
    };
  }

  openPDF(file: any) {
    this.fileName = file.filepath.split('/files/')[1];
    this.fileService.downloadFile(this.fileName, file.filetype).subscribe(
      data => {
        this.pdfSrc = URL.createObjectURL(data);
        const newWidth = (this.innerWidth / 1.414);
        const dialogRef = this.dialog.open(ViewFileDialogComponent, {
        height: this.innerHeight.toString() + 'px',
        width: newWidth.toString() + 'px',
        data: {pdf: this.pdfSrc, mode: 'File', fileName: this.fileName, file: file }
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      }); },
      error => console.error(error)
    );
  }

  downloadFile(file: any) {
    if (file.filetype === 'images') {
      this.fileName = file.filepath.split('/images/')[1];
    } else {
      this.fileName = file.filepath.split('/files/')[1];
    }
    this.fileService.downloadFile(this.fileName, file.filetype)
    .subscribe(
      data => saveAs(data, this.fileName),
      error => console.error(error)
    );
  }

  openViewContractFileDialog (i: any, j: any): void {
      const dialogRef = this.dialog.open(ViewFileDialogComponent, {
        panelClass: 'app-full-image-dialog', // changes default mat-dialog styling
        height: this.viewContractHeight.toString() + 'px',
        width: this.viewContractWidth.toString() + 'px',
        data: {image: this.contracts[i].contract_imagepath[j], mode: 'Image'}
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      });
  }

  getFileName(filepaths: any) {
    this.fileListByName = [];
    if (filepaths === null || filepaths === undefined || filepaths[0] === '') {
      return;
    }

    for (let file of filepaths ) {
      debugger;
      // if (!file.includes('localhost:3000')) {
      //   console.log("not icluded");
      //   return;
      // }
      this.file = { filename: '', filepath: '', filetype: ''};
      if (file.includes('images')) {
        this.file.filepath = file;
       // file = file.split('localhost:3000/images/')[1];
        file = file.split('/images/')[1];
        this.file.filename = /.*(?=\-)/.exec(file)[0];
        this.file.filetype = 'images';
      } else {
        this.file.filepath = file;
       // file = file.split('localhost:3000/files/')[1];
        file = file.split('/files/')[1];
        this.file.filename = /.*(?=\-)/.exec(file)[0];
        this.file.filetype = 'files';
      }
      this.fileListByName.push(this.file);
    }
  }

  getSubsList() {
    return this.companyService.setSubList();
  }

  getSubs(subs: any) {
    this.substring = '';
    let subIdsList;
    this.contract = this.contracts.find(cont => cont._id === this.contractId);
    subIdsList = this.contract.end_user_accepted_subsidiaries;

    if (subIdsList === null || subIdsList === undefined || subIdsList === '') {
      return;
    }

    subIdsList.forEach(subId => {
      this.companies.forEach(company => {
        if (subs === company._id) {
          this.companyName = company.company_name;
        }
        if (subId === company._id) {
          this.subsidiaryList.push(company.company_name);
          if (this.subsidiaryList.length > 1) {
            this.substring += ', ' + company.company_name;
          } else {
            this.substring = company.company_name;
          }
        }
      });
    });
  }

  migrateContract(event, contract: Contract) {
    event.stopPropagation();

    const dialogRef = this.dialog.open(MigrateContractDialogComponent, {
      // disableClose: true,
      width: '50%',
      data: {contract: contract}
    });

    dialogRef.afterClosed().subscribe(returnData => {
      this.getContracts();
    });
  }

  splitString(string: string) {
    if (string === null) {
      return;
    }
    if (string.length > 10) {
      string = string.substring(0, 15);
    }
    return string;
  }

  stringLength(string: string) {
    if (string === null) {
      return;
    }
    if (string.length < 10) {
      return false;
    } else {
      return true;
    }
  }

  allowedValue(element) {
    if (element.allowed < 0) { return 'Unlimited'; } else { return element.allowed; }
  }

  canMigrateBool(licenses: OracleLicenses[]) {
   return licenses.filter(lic => !lic.migrated_to).length;
  }

}
