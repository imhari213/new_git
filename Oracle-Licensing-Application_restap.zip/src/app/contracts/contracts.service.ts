// angular
import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';

// models
import { Contract, OracleLicenses } from './contract.model';

// services
import { CompanyService } from '../companies/companies.service';

// misc
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const BACKEND_URL = environment.apiUrl  + '/contract/';

@Injectable({providedIn: 'root'})

export class ContractService {
  private contracts: Contract[] = [];
  companyId: String;
  fileName: String;

  private contractsUpdated = new Subject<{contracts: Contract[], contractCount: Number, hardwareCount: any}>();
  private allContractsUpdate = new Subject<{contracts: Contract[], contractCount: Number, hardwareCount: any}>();
  hardwareList: any;
  oracle_licenses: OracleLicenses[];

  constructor(public companyService: CompanyService, private http: HttpClient) {}

  getContractUpdateListener() {
    return this.contractsUpdated.asObservable();
  }

  searchValidContacts(compId) {
    return this.http.get<{message: String, contracts: any}>(BACKEND_URL + 'migrate/' + compId);
  }

  addContract(Value: any) {
    console.log(Value);
    const array = ['order_identifier', 'customer_support_identifier', 'contract_date', 'contract_territory', 'contract_terminated',
    'total_capex_cost_of_contract', 'support_contract', 'oracle_licenses', 'non_standard_terms',
    'end_user', 'end_user_accepted_subsidiaries', 'signed_by', 'signed_by_date', 'contract_filenames_toupload', 'contract_type', 'image'];
    const postData = new FormData();

    for (const index of array) {
      if (((Value[index]) != null) && ((Value[index]) !== undefined) && ((Value[index]) !== '')) {
        if (index === 'image') {
          for ( let i = 0; i < Value[index].length ; i++ ) {
            postData.append('image' , (Value[index])[i] );
          }
         } else if ((index === 'oracle_licenses') || (index === 'non_standard_terms')
            || (index === 'support_contract') || (index === 'contract_filenames_toupload')
            || (index === 'end_user_accepted_subsidiaries')) {
            postData.append(index, JSON.stringify(Value[index]));
      } else {
            postData.append(index, (Value[index]));
        }
      }
    }

    return this.http.post<{messsage: string, contract: Contract}>(BACKEND_URL, postData);
  }

  updateContract(id: string, Value: any) {
    const array = ['order_identifier', 'customer_support_identifier', 'contract_date', 'contract_terroritory', 'contract_terminated',
    'total_capex_cost_of_contract', 'support_contract', 'oracle_licenses', 'non_standard_terms',
    'end_user', 'end_user_accepted_subsidiaries', 'signed_by', 'signed_by_date',
    'contract_filenames_toupload', 'contract_type', 'contract_imagepath', 'image'];
    let updateData: Contract | FormData;

    if (typeof(Value.image) === 'object') {
      updateData = new FormData();
      updateData.append('_id', id);
      for (const index of array) {
        if (((Value[index]) !== null) && ((Value[index]) !== undefined) && ((Value[index]) !== '')) {
          if (index === 'image') {
            for ( let i = 0; i < (Value[index]).length ; i++ ) {
              updateData.append('image' , (Value[index])[i] );
            }
          } else if ((index === 'oracle_licenses') || (index === 'non_standard_terms')
              || (index === 'support_contract') || (index === 'contract_imagepath')
              || (index === 'contract_filenames_toupload') || (index === 'end_user_accepted_subsidiaries')) {
                updateData.append(index, JSON.stringify(Value[index]));
          } else {
            updateData.append(index, (Value[index]));
            }
        }
      }
  } else {
    updateData = {
      _id: id,
      ...Value,
      non_standard_terms: Value.non_standard_terms,
      contract_imagepath: Value.contract_imagepath,
      order_identifier: Value.order_identifier,
    };
  }
    return this.http.put<{messsage: string, contract: Contract}>(BACKEND_URL + id, updateData);
  }

  searchContract(companyId: string, searchParam: string, pageChosen: string, compareContractId: string,
    contractsPerPage: number, currentPage: number, sortType: string) {
    const queryParams = `?pagesize=${contractsPerPage}&page=${currentPage}&company=${companyId}&sort=${sortType}&pagechosen=${pageChosen}&compareid=${compareContractId}`;
    this.http.get<{message: string, contracts: any, maxContracts: number, hardwareCount: any}>
    (BACKEND_URL + 'search/' + searchParam + '/' + queryParams)
      .pipe(map((contractData) => {
        return { contracts: contractData.contracts.map(contract => {
              return {
                ...contract,
                order_identifier: contract.order_identifier,
             };
        }), maxContracts: contractData.maxContracts, hardwareCount: contractData.hardwareCount
      };
      }))
      .subscribe((transformedContractData) => {
      this.contracts = transformedContractData.contracts;
      if (contractsPerPage && currentPage) {
        this.contractsUpdated.next({
          contracts: [...this.contracts], contractCount: transformedContractData.maxContracts,
          hardwareCount: transformedContractData.hardwareCount
        });
      } else {
        this.allContractsUpdate.next({
          contracts: [...this.contracts], contractCount: transformedContractData.maxContracts,
          hardwareCount: transformedContractData.hardwareCount
        });
      }

    });
  }

  createMigratedLicense(license: OracleLicenses) {
    return this.http.post<{message: string, license: OracleLicenses}>(BACKEND_URL + 'new_license/', license);
  }

  getContract(id: string) {
      return this.http.get<{message: string, contract: Contract, licenses: OracleLicenses}>(
        BACKEND_URL + id);
  }
  // find the posts object we're looking at, is it the same as our passing argument id

  deleteContract(contractId: string) {
    return this.http.delete(BACKEND_URL + contractId);
  }

}
