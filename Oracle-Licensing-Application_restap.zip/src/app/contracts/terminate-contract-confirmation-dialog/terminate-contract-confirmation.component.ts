// angular
import { OnInit, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

// models
import { Contract } from '../contract.model';

// services
import { ThemeService } from 'src/app/theme.service';
import { ContractService } from '../contracts.service';

@Component({
  selector: 'app-terminate-contract-dialog',
  templateUrl: './terminate-contract-confirmation.component.html',
  styleUrls: ['./terminate-contract-confirmation.component.css'],
  providers: [ThemeService]
})

export class TerminateContractConfirmationComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<TerminateContractConfirmationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private contractService: ContractService) {}

    contract: Contract;

  ngOnInit() {
    this.contract = this.data;
  }

  confirmationYes() {
    this.contract.contract_terminated = true;
    this.contractService.updateContract(this.contract._id, this.contract).subscribe(() => {
      this.dialogRef.close();
    });
  }

}
