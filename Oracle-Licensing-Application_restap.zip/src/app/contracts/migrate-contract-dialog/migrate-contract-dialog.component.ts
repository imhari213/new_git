// angular
import { Component, ViewEncapsulation, OnInit, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatDialog } from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

// models
import { Contract, OracleLicenses } from '../contract.model';

// services
import { ContractService } from '../contracts.service';
import { HwService } from 'src/app/hardware/hardware.service';
import { ThemeService } from 'src/app/theme.service';

// components
import {TerminateContractConfirmationComponent} from '../terminate-contract-confirmation-dialog/terminate-contract-confirmation.component';

@Component({
  selector: 'app-migrate-contract',
  templateUrl: './migrate-contract-dialog.component.html',
  styleUrls: ['./migrate-contract-dialog.component.css'],
  providers: [ThemeService],
  encapsulation: ViewEncapsulation.None
})

export class MigrateContractDialogComponent implements OnInit {

  form: FormGroup;
  contracts = <any>[];
  contract: Contract;
  filteredContracts: Contract[] = [];
  oracleLicenses = <any>[];
  selectedContract: Contract;
  difference = 0;
  masterCheck = false;
  masterIndeterminate = false;
  userRole = 'read';
  override = false;
  allocatedLicList = <any>[];

  dataSourceOracleLicenses: MatTableDataSource<OracleLicenses>;
  displayedColumnsOracleLicence: string[] = ['select', 'productName', 'Metric', 'License Type', 'Restrictions', 'Allocations',
  'Availability'];

  constructor(public dialogRef: MatDialogRef<MigrateContractDialogComponent>,  @Inject(MAT_DIALOG_DATA) public data: any,
  private contractService: ContractService, private snackBar: MatSnackBar, private hardwareService: HwService, private dialog: MatDialog) {}

  ngOnInit() {
    this.userRole = localStorage.getItem('role');
    this.contract = this.data.contract;
    this.getLicenses();
    this.getContracts();
    this.form = new FormGroup({
      'migration_date': new FormControl( new Date())
    });
  }

  getContracts() {
    this.contractService.searchValidContacts(this.contract.end_user).subscribe(contractData => {
      this.contracts = contractData.contracts.filter(contract => contract._id !== this.contract._id);
    });
  }

  getLicenses() {

    if (this.override === true) {
      this.oracleLicenses = this.contract.oracle_licenses;
    } else {
      this.oracleLicenses = this.contract.oracle_licenses.filter(license => (!license.migrated_to && license.allocated === 0));
    }

    this.dataSourceOracleLicenses = new MatTableDataSource(this.oracleLicenses);
    this.oracleLicenses.map(lic => lic.migrate = false);
    this.difference = this.data.contract.oracle_licenses.filter(license => !license.migrated_to).length - this.oracleLicenses.length;
  }

  searchFilterContracts(search) {
    this.filteredContracts = this.contracts.filter(contract => contract.customer_support_identifier.includes(search));
  }

  onSelectedContract(contract) {
    this.selectedContract = contract;

  }

  masterToggle(event) {
    const updatedLicenses = [];
    this.oracleLicenses.forEach(license => {
      const lic = license;
      lic.migrate = event;
      updatedLicenses.push(lic);
    });
    this.oracleLicenses = updatedLicenses;
    this.dataSourceOracleLicenses = new MatTableDataSource(this.oracleLicenses);
    if (event === true ) { this.masterIndeterminate = false; this.masterCheck = true; }
  }

  toggleElement(index, event) {
    this.oracleLicenses[index].migrate = event;
    const allTrue = this.oracleLicenses.filter(license => license.migrate === true).length;

    if (allTrue === this.oracleLicenses.length) { this.masterCheck = true; this.masterIndeterminate = false;
    } else { this.masterCheck = false; this.masterIndeterminate = true; }

    this.dataSourceOracleLicenses = new MatTableDataSource(this.oracleLicenses);
  }

  migrateContract() {


    const toMigrate: OracleLicenses[] = this.oracleLicenses.filter( lic => lic.migrate === true );

    toMigrate.forEach(license => { license = this.migrate(license); } );

    this.contractService.updateContract(this.contract._id, this.contract).subscribe(() => {
      this.contractService.updateContract(this.selectedContract._id, this.selectedContract).subscribe();
    });

    toMigrate.map(license => license.allocated = 0);

    this.masterCheck = false;
    this.masterIndeterminate = false;
    const snackMessage = 'The license has been migrated to' + this.selectedContract.customer_support_identifier;
    this.snackBar.open( snackMessage , null, {duration: 3000});

    this.getLicenses();

    const validLic = this.contract.oracle_licenses
    .filter(lic => (!lic.migrated_to && (new Date(lic.support_end_date) > new Date()))).length;

    if (!validLic) {
      const dialogRef = this.dialog.open(TerminateContractConfirmationComponent, {
        disableClose: true,
        width: '50%',
        data: this.contract
      });
    }

  }

  migrate(license) {

    license.migration_date = this.form.value.migration_date;
    const migrated_license =  {...license};
    const allocated = license.allocated;
    migrated_license._id = undefined;

    if (license.quantity !== -1) { license.allowed += allocated; }
    license.migrated_to = this.selectedContract._id;
    migrated_license.migrated_from = this.contract._id;

    try {
      this.contractService.createMigratedLicense(migrated_license).subscribe(data => {
        this.selectedContract.oracle_licenses.push(data.license);
        if (allocated > 0) {
          this.hardwareService.migrateLicOnHW(data.license, license, this.selectedContract._id).subscribe();
        }
        return data.license;
      });
    } catch {
      return license;
    }

  }

  valueAllowed(allowed) {
    if (allowed === -1) { return 'unlimited'; } else { return allowed; }
  }

  allowOverride() {
    this.override = !this.override;
    this.getLicenses();
  }

  compareOracleLicenseLengths() {
    const og_lic_len = this.contract.oracle_licenses.length;
    const filtered_lic_len = this.contract.oracle_licenses.filter(license => {
      if (!license.migrated_to && license.allocated === 0) {return true; } else { return false; }
    }).length;

    return og_lic_len - filtered_lic_len;
  }

}
