// angular
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

// models
import { Hardware } from 'src/app/hardware/hardware.model';
import { OracleLicenses } from '../contract.model';

// services
import { HwService } from 'src/app/hardware/hardware.service';
import { ThemeService } from '../../theme.service';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-assign-hardware-dialog',
  templateUrl: './assign-hardware-dialog.component.html',
  styleUrls: ['./assign-hardware-dialog.component.css'],
  providers: [ThemeService],
  encapsulation: ViewEncapsulation.None
})

export class AssignHardwareDialogComponent implements OnInit {

  form: FormGroup;

  oracleLicense: OracleLicenses;
  companyId;
  contractId;

  hardwares: Hardware[];
  hardware: Hardware;
  serverName;
  virtualisationArray;

  input: HTMLElement;

  hardwareSub: Subscription;

  constructor(public dialogRef: MatDialogRef<AssignHardwareDialogComponent>,
    private themeService: ThemeService,
    @Inject(MAT_DIALOG_DATA) public data: any, private hardwareService: HwService) {}

  ngOnInit() {

    if (this.themeService.getThemeSelected() === true ) {
      this.dialogRef.addPanelClass('dark-theme');
    }

    this.oracleLicense = this.data.oracleLicense;
    this.companyId = this.data.company;
    this.contractId = this.data.contractId;

    this.createForm();
    this.getHardwares();

    if (this.oracleLicense.quantity !== -1) {
      this.input = document.getElementById('numInput');
      this.input.setAttribute('max', this.oracleLicense.allowed.toString());
    }

  }

  createForm() {
    this.form = new FormGroup({
      'hardware': new FormControl(null, {validators: [Validators.required]
      }),
      'virtualisation': new FormControl(null
      ),
      'quantity': new FormControl(this.oracleLicense.allowed, {validators: [Validators.required]
      })
    });
  }

  getHardwares() {
    this.hardwareService.searchHardwares(this.companyId, undefined, undefined, undefined, null, null, null, null, null);
    this.hardwareSub = this.hardwareService.getHardwareUpdateListener()
    .subscribe((hardwareData: {hardwares: Hardware[]; hardwareCount: Number}) => {
      this.hardwares = hardwareData.hardwares.filter(hw => !hw.decommission_date);
    });
  }

  setHardware(hardwareId: string) {
    this.hardware = this.hardwares.find(hardware => hardware._id === hardwareId);
    this.serverName = this.hardware.server_name;
    const hwListObj = {_id: this.hardware._id, virtual_server_name: '*' + this.hardware.server_name};
    this.virtualisationArray = [hwListObj];
    let tempArray;
    if (this.hardware.ibm_virt && this.hardware.ibm_virt.length > 0) {
      tempArray = this.hardware.ibm_virt;
    } else if (this.hardware.ovm_virt && this.hardware.ovm_virt.length > 0) {
      tempArray = this.hardware.ovm_virt;
    } else if (this.hardware.kvm_virt && this.hardware.kvm_virt.length > 0) {
      tempArray = this.hardware.kvm_virt;
    } else if (this.hardware.xen_virt && this.hardware.xen_virt.length > 0) {
      tempArray = this.hardware.xen_virt;
    } else if (this.hardware.vmware_virt && this.hardware.vmware_virt.length > 0) {
      tempArray = this.hardware.vmware_virt;
    } else if (this.hardware.solaris_virt && this.hardware.solaris_virt.length > 0) {
      tempArray = this.hardware.solaris_virt;
    } else {
      tempArray = [];
    }

    this.virtualisationArray = this.virtualisationArray.concat(tempArray);
    this.form.patchValue({virtualisation: this.virtualisationArray[0]._id});
  }

  assignHardware() {

    if (this.hardware._id &&  (this.form.value.quantity >= 0 )) {
      this.hardware.license_allocated_to_server.push({
        _id: undefined,
        virtualisation_linked: this.form.value.virtualisation,
        contract_linked: this.contractId,
        license_metric_allocated: this.oracleLicense.metric,
        number_of_licenses_in_use: this.form.value.quantity,
        product_licensed: this.oracleLicense._id,
        restricted_use: this.oracleLicense.restrictions
      });

      this.hardwareService.updateHardware(this.hardware._id, this.hardware).subscribe( () => {
        this.dialogRef.close({data: {allocated: this.form.value.quantity, hardwareId: this.hardware._id}});
      });
    }
  }

}
