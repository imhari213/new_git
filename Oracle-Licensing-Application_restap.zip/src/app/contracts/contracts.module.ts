// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';

// components
import { ContractCreateComponent } from './contracts-create/contracts-create.component';
import { ContractListComponent } from './contracts-list/contracts-list.component';
import { NonStandardTermsDialogComponent } from './non-standard-terms-dialog/non-standard-terms-dialog.component';
import { SupportContractDialogComponent } from './support-contract-dialog/support-contract-dialog.component';
import { OracleLicenseDialogComponent } from './oracle-license-dialog/oracle-license-dialog.component';
import { AssignHardwareDialogComponent } from './assign-hardware-dialog/assign-hardware-dialog.component';
import { ViewFileDialogComponent } from './view-file-dialog/view-file-dialog.component';
import { MigrateContractDialogComponent } from './migrate-contract-dialog/migrate-contract-dialog.component';
import { TerminateContractConfirmationComponent } from './terminate-contract-confirmation-dialog/terminate-contract-confirmation.component';

// misc
import { PdfViewerModule } from 'ng2-pdf-viewer';

@NgModule({
  declarations: [
    ContractCreateComponent,
    ContractListComponent,
    ViewFileDialogComponent,
    NonStandardTermsDialogComponent,
    SupportContractDialogComponent,
    OracleLicenseDialogComponent,
    AssignHardwareDialogComponent,
    MigrateContractDialogComponent,
    TerminateContractConfirmationComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
    PdfViewerModule
  ],
  entryComponents: [SupportContractDialogComponent, OracleLicenseDialogComponent, NonStandardTermsDialogComponent,
     ViewFileDialogComponent, AssignHardwareDialogComponent, MigrateContractDialogComponent, TerminateContractConfirmationComponent]
})

export class ContractModule {}
