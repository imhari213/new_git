// angular
import { Component, OnInit, OnDestroy, ChangeDetectorRef, AfterContentChecked } from '@angular/core';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';

// models
import { Company } from '../companies/company.model';

// services
import { CompanyService } from '../companies/companies.service';
import { HeaderService } from './header.service';
import { AuthService } from '../auth/auth.service';
import { ThemeService } from '../theme.service';
import { DbService } from '../databases/database.service';

// components
import { ResolveRequestsDialogComponent } from '../resolve-requests-dialog/resolve-requests-dialog.component';

// misc
import { Subscription, Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})

export class HeaderComponent implements OnInit, OnDestroy, AfterContentChecked {

  checkedTheme;
  notificationBadge;

  form: FormGroup;
  input: HTMLElement;
  companyName: any;
  notificationList: any;

  searchCompaniesPerPage = 5;
  searchCurrentPage = 1;

  userIsAuthenticated = false;
  userRole = 'read';

  options: string[] = this.headerService.setCompanylist();
  companies: Company[] = [];
  filteredCompanies: Company[] = [];

  constructor(private authService: AuthService, private headerService: HeaderService,
    private companyService: CompanyService, private router: Router,
    private activeRoute: ActivatedRoute, private changeDetector: ChangeDetectorRef,
    private themeService: ThemeService, private dialog: MatDialog,
    private databaseService: DbService) {}

  private authListenerSubs: Subscription;
  private roleListenerSubs: Subscription;
  private notificationSub: Subscription;
  private companySub: Subscription;

  ngOnInit() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authListenerSubs = this.authService
    .getAuthStatusListener()
    .subscribe(isAuthenticated => {
      this.userIsAuthenticated = isAuthenticated;
      if (this.userIsAuthenticated) {
        this.getCompanyNameList();
        this.getNotificationLength();
      }
    });
    this.userRole = this.authService.getRole();
    this.roleListenerSubs = this.authService
    .getRoleListener()
    .subscribe(role => {
      this.userRole = role;
    });
    this.activeRoute.params.subscribe(routeParams => {
      if (this.userIsAuthenticated) {
        this.getCompanyNameList();
        this.getNotifications();
      }
    });
  }

  ngAfterContentChecked() {
    if (localStorage.name === 'undefined') {
      this.companyName = '';
    } else {
      this.companyName = localStorage.name;
    }
    this.changeDetector.detectChanges();
  }

  getNotifications() {
    this.authService.getNotifications(localStorage.email);
    this.notificationSub = this.authService.getNotificationListener().subscribe(result => {
      this.notificationList = result.notifications;
    });
  }

  resolveNotification(notification) {
    const dialogRef = this.dialog.open(ResolveRequestsDialogComponent, {
      width: '50%',
      disableClose: true,
      data: {notification: notification}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.databaseService.migrateDb(result);
      }
    });
  }

  getNotificationLength() {
    if (this.notificationList !== undefined && this.notificationList.length > 0) {
      this.notificationBadge = false;
      return this.notificationList.length;
    } else {
      this.notificationBadge = true;
      return; }
  }

  getCompanyNameList() {
  this.headerService.getCompanyNames();
  this.companyService.getCompaniesHeader();
  this.companySub = this.companyService.getCompanyHeaderListener()
  .subscribe((companyData: {companies: Company[]; companyCount: number}) => {
    this.companies = companyData.companies;
    this.filteredCompanies = companyData.companies;
  });
  }

  onLogout() {
    this.authService.logout();
  }

  onSelectedCompany(form: NgForm, selectedCompany: Company) {
    localStorage.setItem('compId', selectedCompany._id);
    this.router.navigate(['/company-details/' + selectedCompany.company_name]);
    form.reset();
    this.input = document.getElementById('selected');
    this.input.blur();
  }

  // need new search unction in this component to search all application
  onSearch(form: NgForm, searchString: string) {
    this.companyService.searchCompany(form.value.search, this.searchCompaniesPerPage, this.searchCurrentPage, null, null);
  }

  filterCompanies(form: NgForm, event, selected: any) {

    if (event.code === 'Enter') {
      event.target.value = '';
      this.onSelectedCompany(form, selected);
      this.filteredCompanies = [];
    } else {
      this.filteredCompanies = [];
      this.companies.forEach(company => {
        if (company.company_name.toLowerCase().includes(event.target.value)) {
          this.filteredCompanies.push(company);
        }
      });
    }
  }

  getCompanyName() {
    try {
      return this.companies.find(comp => comp._id === localStorage.getItem('compId')).company_name;
    } catch {
      return '';
    }
  }

  getColour() {
    this.checkedTheme = this.themeService.getThemeSelected();
  }

  toggleDarkTheme() {
    this.checkedTheme = !this.checkedTheme;
    this.themeService.setDarkTheme(this.checkedTheme);
    const form = {darkmode: this.checkedTheme};
    this.themeService.updateUserThemeSelected(form);
  }

  ngOnDestroy() {
    this.authListenerSubs.unsubscribe();
    this.roleListenerSubs.unsubscribe();
    this.companySub.unsubscribe();
    this.notificationSub.unsubscribe();
  }

}
