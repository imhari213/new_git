// angular
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

// misc

import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const BACKEND_URL = environment.apiUrl  + '/company/';
const comp_name_list: any  = [];

@Injectable({providedIn: 'root'})
export class HeaderService {

  constructor(private http: HttpClient) {}

  getCompanyNames() {
    this.http.get<{message: string, companies: any, maxCompanies: number}>(BACKEND_URL)
      .pipe(map((companyData) => {
        return { companies: companyData.companies.map(company => {
          let boolFlag = false;
          if (comp_name_list.length === 0 ) {
            comp_name_list.push(company.company_name); //  empty array, add element
          } else {
            for (let i = 0; i < comp_name_list.length; i ++) {
              if (comp_name_list[i] === company.company_name) { //  does frontened list = backend
                boolFlag = true; // yes then set true
              }
            }
            if (boolFlag === false) { // no match, if belongs in backend add it
              comp_name_list.push(company.company_name); // add backend element
            } else {
              comp_name_list.pop(company.company_name); // remove backend element
            }
          }
        })};
      })).subscribe(() => {
      });
  }

  setCompanylist() {
    return comp_name_list;
  }

}
