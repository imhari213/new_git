// angular
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// authentication
import { AuthGuard } from './auth/auth.guard';

// components
import { CompanyCreateComponent } from './companies/companies-create/companies-create.component';
import { CompanyListComponent } from './companies/companies-list/companies-list.component';
import { ContractCreateComponent } from './contracts/contracts-create/contracts-create.component';
import { ContractListComponent } from './contracts/contracts-list/contracts-list.component';
import { DatabaseCreateComponent } from './databases/databases-create/databases-create.component';
import { DatabaseListComponent } from './databases/database-list/database-list.component';
import { CompanyDetailsComponent } from './companies/company-details/company-details.component';
import { HardwareListComponent } from './hardware/hardware-list/hardware-list.component';
import { HardwareCreateComponent } from './hardware/hardware-create/hardware-create.component';
import { VcenterCreateComponent } from './vcenter/vcenter-create/vcenter-create.component';
import { VcenterListComponent } from './vcenter/vcenter-list/vcenter-list.component';
import { ViewConfigComponent } from './config/view-config/view-config.component';
import { MiddlewareListComponent } from './middleware/middleware-list/middleware-list.component';
import { MiddlewareCreateComponent } from './middleware/middleware-create/middleware-create.component';
import { DeclarationListComponent } from './declarations/declaration-list/declaration-list.component';
import { DeclarationCreateComponent } from './declarations/declaration-create/declaration-create.component';
import { ReportingListComponent } from './reporting/reporting-list/reporting-list.component';
import { ReportingCreateComponent } from './reporting/reporting-create/reporting-create.component';

const routes: Routes = [
  {path: '', component: CompanyListComponent, canActivate: [AuthGuard]},
  {path: 'auth', loadChildren: './auth/auth.module#AuthModule'},

  // {path: 'search/:searchparam', component: CompanyListComponent, canActivate: [AuthGuard]},
  {path: 'add-company', component: CompanyCreateComponent, canActivate: [AuthGuard]},
  {path: 'list-company', component: CompanyListComponent, canActivate: [AuthGuard]},
  {path: 'edit-company/:companyId', component: CompanyCreateComponent, canActivate: [AuthGuard] },
  {path: 'company-details/:companyName', component: CompanyDetailsComponent, canActivate: [AuthGuard]},

  // {path: 'search', component: CompanyListComponent, canActivate: [AuthGuard]},
  {path: 'add-contract', component: ContractCreateComponent, canActivate: [AuthGuard]},
  {path: 'add-contract/:companyId', component: ContractCreateComponent, canActivate: [AuthGuard]},
  {path: 'list-contract', component: ContractListComponent, canActivate: [AuthGuard]},
  {path: 'edit-contract/:contractId', component: ContractCreateComponent, canActivate: [AuthGuard]},

  {path: 'add-database', component: DatabaseCreateComponent, canActivate: [AuthGuard]},
  {path: 'add-database/:companyId', component: DatabaseCreateComponent, canActivate: [AuthGuard]},
  {path: 'list-database', component: DatabaseListComponent, canActivate: [AuthGuard]},
  {path: 'edit-database/:databaseId', component: DatabaseCreateComponent, canActivate: [AuthGuard]},

  {path: 'add-hardware', component: HardwareCreateComponent, canActivate: [AuthGuard]},
  {path: 'add-hardware/:companyId', component: HardwareCreateComponent, canActivate: [AuthGuard]},
  {path: 'list-hardware', component: HardwareListComponent, canActivate: [AuthGuard]},
  {path: 'edit-hardware/:hardwareId', component: HardwareCreateComponent, canActivate: [AuthGuard]},

  {path: 'add-vcenter', component: VcenterCreateComponent, canActivate: [AuthGuard]},
  {path: 'add-vcenter/:companyId', component: VcenterCreateComponent, canActivate: [AuthGuard]},
  {path: 'list-vcenter', component: VcenterListComponent, canActivate: [AuthGuard]},
  {path: 'edit-vcenter/:vcenterId', component: VcenterCreateComponent, canActivate: [AuthGuard]},

  {path: 'list-middleware', component: MiddlewareListComponent, canActivate: [AuthGuard]},
  {path: 'add-middleware', component: MiddlewareCreateComponent, canActivate: [AuthGuard]},
  {path: 'edit-middleware/:middlewareId', component: MiddlewareCreateComponent, canActivate: [AuthGuard]},

  {path: 'view-config', component: ViewConfigComponent, canActivate: [AuthGuard]},

  {path: 'list-declarations', component: DeclarationListComponent, canActivate: [AuthGuard]},
  {path: 'add-declaration', component: DeclarationCreateComponent, canActivate: [AuthGuard]},
  {path: 'edit-declaration/:declarationId', component: DeclarationCreateComponent, canActivate: [AuthGuard]},

  {path: 'create-report', component: ReportingCreateComponent, canActivate: [AuthGuard]},
  {path: 'list-report', component: ReportingListComponent, canActivate: [AuthGuard]},

];

@NgModule({ // informing router modules about our routes
 imports: [RouterModule.forRoot(routes)],
 exports: [RouterModule],
 providers: [AuthGuard]
})

export class AppRoutingModule {}
