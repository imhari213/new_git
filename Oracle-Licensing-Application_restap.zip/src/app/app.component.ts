// angular
import { Component, OnInit } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';

// services
import { AuthService } from './auth/auth.service';
import { ThemeService } from '../app/theme.service';
import { OptionsService } from '../app/options.service';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ThemeService, OptionsService]
})
export class AppComponent implements OnInit {

  isDarkTheme;
  isAuthenticated;

  constructor(private authService: AuthService, private themeService: ThemeService,
    private optionsService: OptionsService, private overlayContainer: OverlayContainer) {}

  themeSub: Subscription;
  overlayContainerClasses = this.overlayContainer.getContainerElement().classList;

    ngOnInit() {
      this.authService.autoAuthUser();
      this.isAuthenticated = this.authService.getIsAuth();
      if (this.isAuthenticated === true) {
        this.themeService.getUserThemeSelected();
        this.optionsService.getUserHeaderOption();
      }
      this.isDarkTheme = this.themeService.getThemeSelected();
      this.themeSub = this.themeService.darkThemeListener().subscribe((darkThemeData) => {
        this.isDarkTheme = darkThemeData;
        if (this.isDarkTheme === true) {
          this.overlayContainerClasses.remove('di-theme');
          this.overlayContainerClasses.add('dark-theme');
        } else {
          this.overlayContainerClasses.remove('dark-theme');
          this.overlayContainerClasses.add('di-theme');
        }
      });
    }
}
