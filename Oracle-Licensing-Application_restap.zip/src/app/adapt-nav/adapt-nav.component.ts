// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Router } from '@angular/router';

// services
import { HeaderService } from '../header/header.service';
import { AuthService } from '../auth/auth.service';
import { CompanyService } from '../companies/companies.service';

// misc
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';


@Component({
  selector: 'app-adapt-nav',
  templateUrl: './adapt-nav.component.html',
  styleUrls: ['./adapt-nav.component.css'],
})

export class AdaptNavComponent implements OnInit, OnDestroy {

  userRole = 'read';
  company;
  companyName;
  selectedCompany: string;
  opened: boolean;
  userIsAuthenticated = false;


  constructor(private headerService: HeaderService, private breakpointObserver: BreakpointObserver, private router: Router,
    private authService: AuthService, private companyService: CompanyService) {}

    private authListenerSubs: Subscription;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
  );

  ngOnInit() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authListenerSubs = this.authService
    .getAuthStatusListener()
    .subscribe(isAuthenticated => {
      this.userIsAuthenticated = isAuthenticated;
      if (this.userIsAuthenticated === true) {
        setTimeout(() => {
          this.onOpenSideNav();
        }, 1000);
      }
    });
    if (this.userIsAuthenticated === true) {
      this.onOpenSideNav();
    }
  }

  getSelectedCompany() {
    if (this.companyName == null) {
      this.router.navigate(['/list-company']);
    } else {
      this.router.navigate(['/company-details/' + this.companyName]);
    }
  }

  onOpenSideNav() {
    this.userRole = localStorage.getItem('role');
    this.company = localStorage.getItem('userId');
    this.companyName = localStorage.getItem('name');
  }

  ngOnDestroy() {
    this.authListenerSubs.unsubscribe();
  }

}
