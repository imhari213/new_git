import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface Field {
  name: string;
  completed: boolean;
  subFields?: Field[];
}

@Component({
  selector: 'app-field-selection',
  templateUrl: './field-selection.component.html',
  styleUrls: ['./field-selection.component.css']
})

export class FieldSelectionDialogComponent implements OnInit {

  allComplete = true;
  list?: Field;

  nameList?: String[];

  informationComplete = true;
  specificsComplete = true;
  name;


  constructor(public dialogRef: MatDialogRef<FieldSelectionDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {

    this.list = this.data.fields;
    this.name = this.data.name;
  }

  selectFields() {
    this.dialogRef.close(this.list);
  }

  updateAllComplete() {
    this.allComplete = this.list.subFields != null && this.list.subFields.every(t => t.completed);

  }

  someComplete(): boolean {
    if (this.list.subFields == null) {
      return false;
    }
    return this.list.subFields.filter(t => t.completed).length > 0 && !this.allComplete;
  }

  setAll(completed: boolean) {
    this.allComplete = completed;
    if (this.list.subFields == null) {
      return;
    }
    this.list.subFields.forEach(t => t.completed = completed);
  }




}
