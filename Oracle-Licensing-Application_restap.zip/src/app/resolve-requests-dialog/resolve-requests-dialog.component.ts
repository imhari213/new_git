// angular
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

// components
import { DeleteConfirmationComponent } from '../deletePopUp/delete-confirmation-dialog.component';

@Component({
  selector: 'app-resolve-requests-dialog',
  templateUrl: './resolve-requests-dialog.component.html',
  styleUrls: ['./resolve-requests-dialog.component.css']
})
export class ResolveRequestsDialogComponent implements OnInit {
  requestData: any;
  contentArray: any;
  requestedServer: string;
  currentServer: string;
  databaseName: string;

  constructor(
    public dialogRef: MatDialogRef<DeleteConfirmationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {
    this.requestData = this.data.notification;
    console.log(this.requestData.content);
    this.contentArray = this.requestData.content.split(' ');
    this.databaseName = this.contentArray[8];
    this.currentServer = this.contentArray[11];
    this.requestedServer = this.contentArray[18];
  }

  onConfirmationChange() {
    const reqObj = {
      newServer: this.requestedServer,
      database: this.databaseName,
      company: this.requestData.company,
      db_id: this.requestData.migrate_db.db_id,
      hw_id: this.requestData.migrate_db.hw_id,
      request_id: this.requestData._id

    };
    this.dialogRef.close(reqObj);
  }

}
