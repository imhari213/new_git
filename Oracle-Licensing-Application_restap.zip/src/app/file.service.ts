// angular
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable()

export class FileService { 

  fileName: String;

    constructor(private http: HttpClient) {}

    downloadFile(fileName: String, fileLocation: String) {
      const body = {filename: fileName,
                    filelocation: fileLocation
                    };
      return this.http.post(environment.appDomain +'/download/', body, {
        responseType : 'blob',
        headers: new HttpHeaders().append('Content-Type', 'application/json')
      });
    }
}
