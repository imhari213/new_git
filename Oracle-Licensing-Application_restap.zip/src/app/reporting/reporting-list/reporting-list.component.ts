// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { ConfigService } from 'src/app/config/config.service';
import { ReportingService } from 'src/app/reporting/reporting.service';

// misc
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-reporting-list',
  templateUrl: './reporting-list.component.html',
  styleUrls: ['./reporting-list.component.css'],
  providers: []
})

export class ReportingListComponent implements OnInit, OnDestroy {

  constructor(private authService: AuthService, private router: Router, private dialog: MatDialog) {}

  authStatusSub: Subscription;
  userRole = 'read';
  userIsAuthenticated: Boolean;

  ngOnInit() {
    this.getAuth();
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
  }

}


