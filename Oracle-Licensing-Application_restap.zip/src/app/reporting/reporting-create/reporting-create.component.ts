// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as XLSX from 'xlsx';

// services
import { AuthService } from 'src/app/auth/auth.service';
import { ConfigService } from 'src/app/config/config.service';
import { ReportingService } from 'src/app/reporting/reporting.service';
import { DbService } from 'src/app/databases/database.service';

// misc
import { Subscription } from 'rxjs';
import { _ } from 'lodash';

@Component({
  selector: 'app-reporting-create',
  templateUrl: './reporting-create.component.html',
  styleUrls: ['./reporting-create.component.css'],
  providers: []
})

export class ReportingCreateComponent implements OnInit, OnDestroy {

  constructor(private authService: AuthService, private router: Router, private databaseService: DbService) { }

  authStatusSub: Subscription;
  userRole = 'read';
  userIsAuthenticated: Boolean;

  dataString: any;


  ngOnInit() {
    this.getAuth();
  }

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
  }

  uploadExcel(ev) {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        //  console.log(name);
        //console.log(initial);
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      //  this.dataString = JSON.stringify(jsonData);

      this.dataString = jsonData;
      var databaseSchema = this.dataString.DbSchema;

      databaseSchema.forEach(function (dbs, index) {

        databaseSchema[index].end_user = "5ff333c3de6d155b500ae90e";
        databaseSchema[index].physical_server_name = "5d7d1013b0e350091c1f19ff";

        if (dbs.managements_in_use_packs || dbs.options_in_use_packs) {
          if (dbs.managements_in_use_packs) {
            databaseSchema[index].managements_in_use = [];
            var managements_in_use = dbs.managements_in_use_packs.toString().split(',')
            var packStatus = dbs.management_pack_usage.toString().split(',')
            managements_in_use.forEach(function (element, subIndex) {
              //   getManagementPacks(index, element)
              var obj = {
                "management_in_use": element,
                "active_status": packStatus[subIndex],
                "database_id": databaseSchema[index].dbid,
                "support_status": databaseSchema[index].support_status
              }
              databaseSchema[index].managements_in_use.push(obj)

            });
          }
          if (dbs.options_in_use_packs) {
            databaseSchema[index].options_in_use = [];
            console.log("option schema");
            console.log(databaseSchema[index]);
            var options_in_use = dbs.options_in_use_packs.toString().split(',')
            var packStatus = dbs.optional_pack_usage.toString().split(',')
            options_in_use.forEach(function (element, subIndex) {
              var obj = {
                "option_in_use": element,
                "active_status": packStatus[subIndex],
                "database_id": databaseSchema[index].dbid,
                "support_status": databaseSchema[index].support_status
              }
              databaseSchema[index].options_in_use.push(obj)
            });
          }
        }
        console.log(databaseSchema);
      });






      // console.log(this.dataString.CompanySchema);
      // console.log(this.dataString.EndUserContactSchema);

      function getManagementPacks(database_reference_id, managementPack_reference_id) {
        var managementSchema = jsonData.managementSchema;
        var databaseSchema = jsonData.DbSchema;
        managementSchema.forEach(managementPack => {
          if (managementPack.Ref_ID == managementPack_reference_id) {
            databaseSchema[database_reference_id].managementPacks.push(managementPack)
          }
        })
        console.log("management pack");
        console.log(databaseSchema[database_reference_id]);
      }

      function getOptionalPacks(database_reference_id, optionPack_reference_id) {
        var optionSchema = jsonData.optionSchema;
        var databaseSchema = jsonData.DbSchema;
        optionSchema.forEach(optionPack => {
          if (optionPack.Ref_ID == optionPack_reference_id) {
            databaseSchema[database_reference_id].optionPacks.push(optionPack)
          }
        });
        console.log("optional pack");
        console.log(databaseSchema[database_reference_id]);
      }


      console.log(databaseSchema);



    }
    reader.readAsBinaryString(file);




  }


  submitSheet() {
    console.log(this.dataString.DbSchema[0]);
    this.databaseService.addBulkDb(this.dataString.DbSchema).subscribe((res)=>{
               console.log(res);
    },err => {
      console.log(err);
    })
  }


}
