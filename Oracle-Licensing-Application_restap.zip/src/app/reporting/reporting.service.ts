// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

// misc
import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';

const BACKEND_URL = environment.apiUrl + '/reporting/';

@Injectable({providedIn: 'root'})

export class ReportingService {

  constructor(private http: HttpClient) {}
}
