// angular
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from '../angular-material.module';
import { RouterModule } from '@angular/router';

// components
import { ReportingListComponent } from './reporting-list/reporting-list.component';
import { ReportingCreateComponent } from './reporting-create/reporting-create.component';

@NgModule({
  declarations: [ReportingListComponent,
                ReportingCreateComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
  ],
  entryComponents: []
})

export class ReportingModule {}
