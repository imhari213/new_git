// angular
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import { MatDialog } from '@angular/material';

// services
import { AuthService } from '../auth.service';

// components
import { PasswordResetSenderDialogComponent } from '../password-reset-sender-dialog/password-reset-sender-dialog.component';


@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.css']
})
export class PasswordResetComponent implements OnInit {
  urlArray: string[];
  emailName: string;
  loading: boolean;
  form: any;
  pwdChangeSuccess: boolean;
  status: Boolean;
  emailSent: Boolean;
  snapshotParam : any;

  constructor(public authService: AuthService, private router: Router, private dialog: MatDialog, private readonly route: ActivatedRoute) { }

  ngOnInit() {
    debugger;
    this.snapshotParam = this.route.snapshot.paramMap.get("token");
    this.pwdChangeSuccess = false;
    this.urlArray = (window.location.href.split('/'));
    debugger;
    this.authService.passwordReset(this.urlArray[6]).subscribe(result=> {
      if (result.status === true) {
        debugger;
        this.emailName = result.email;
        this.status = result.status;
        this.setForm();
      } else {
        debugger;
        this.status = result.status;
        this.loading = true;
      }
    });
  }
  passwordReset() {
    const dialogRef = this.dialog.open(PasswordResetSenderDialogComponent, {
      width: '30%',
      minHeight: '35%',
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        this.authService.sendingEmail(result.email);
        this.emailSent = true;
      }
    });
  }

  setForm() {
    this.form = new FormGroup({
      'email': new FormControl(null
        ),
      'new_password': new FormControl(null
        ),
      'confirm_password': new FormControl(null
        ),
      'token': new FormControl(null
        )
    });
    this.loading = true;
  }

  saveNewPassword() {
    if (this.form.controls.confirm_password.value !== this.form.controls.new_password.value) {
      return;
    } else if (this.form.invalid) {
      return;
    } else {
      this.pwdChangeSuccess = true;
      this.form.patchValue({email: this.emailName});
      this.form.patchValue({token: this.urlArray[5]});
      this.authService.resetPassword(this.form.value);
    }

  }
  loginRouter() {
    this.router.navigate(['/auth/login']);
  }

}
