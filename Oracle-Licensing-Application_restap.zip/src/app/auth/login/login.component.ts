// angular
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';

// services
import { AuthService } from '../auth.service';
import { ThemeService } from '../../theme.service';

// components
import { PasswordResetSenderDialogComponent } from '../password-reset-sender-dialog/password-reset-sender-dialog.component';

// misc
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit, OnDestroy {
  isLoading = false;
  private authStatusSub: Subscription;
  emailSent: Boolean;

  constructor(public authService: AuthService, private router: Router, private dialog: MatDialog, private themeService: ThemeService) {}

  ngOnInit() {
    this.emailSent = false;
    // sets up listener which is used to check wether the user is logged in or not
    this.authStatusSub = this.authService.getAuthStatusListener().subscribe(
      authStatus => {
        this.isLoading = false;
      }
    );
    this.themeService.setDarkTheme(false);
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
  }

  // called from the HTMl file, recieves information that the user has filled in
  onLogin(form: NgForm) {
    // checks the form is valid otherwise will not log the user in
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    // sends the users credentials through to the authService so they can be checked to find a valid user.
    this.authService.login(form.value.email, form.value.password);
  }

  passwordReset() {
    const dialogRef = this.dialog.open(PasswordResetSenderDialogComponent, {
      width: '30%',
      minHeight: '35%',
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        this.authService.sendingEmail(result.email);
        this.emailSent = true;
      }
    });
  }
}
