// angular
import { NgModule } from '@angular/core';
import { AngularMaterialModule } from '../angular-material.module';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// components
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { UserDetailEditComponent } from './edit-user-details/edit-user-dialog.component';
import { PasswordResetSenderDialogComponent } from './password-reset-sender-dialog/password-reset-sender-dialog.component';
import { PasswordResetComponent } from './password-reset/password-reset.component';

// misc
import { AuthRoutingModule } from './auth-routing.module';
import { RECAPTCHA_SETTINGS, RecaptchaSettings, RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';

@NgModule({
  declarations: [
    LoginComponent,
    SignupComponent,
    UserDetailEditComponent,
    PasswordResetSenderDialogComponent,
    PasswordResetComponent
  ],
  imports : [
    CommonModule,
    FormsModule,
    AngularMaterialModule,
    AuthRoutingModule,
    ReactiveFormsModule,
    RecaptchaFormsModule,
    FormsModule,
    RecaptchaModule.forRoot()
  ],    exports: [
    RecaptchaModule
 ],
 providers: [
  {provide: RECAPTCHA_SETTINGS, useValue: {siteKey: '6Lfw384UAAAAAIlKP7bEK3-nXOzLEO3L0Db15lzz'} as RecaptchaSettings}
 ],
  entryComponents: [UserDetailEditComponent, PasswordResetSenderDialogComponent],
})

export class AuthModule {}
