export interface AuthData {
  _id: string;
  email: string;
  password: string;
  role: string;
  company: string;
  darkmode: boolean;
  headers: boolean;
}
