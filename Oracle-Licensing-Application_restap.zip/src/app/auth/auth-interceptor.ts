// angular
import { HttpInterceptor, HttpRequest, HttpHandler} from '@angular/common/http';
import { Injectable } from '@angular/core';

// services
import { AuthService } from './auth.service';


@Injectable()

export class AuthInterceptor implements HttpInterceptor {

  constructor(private authService: AuthService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler ) {
    // check token and refresh timer or get new token
    const authToken = this.authService.getToken(); // get token from auth.service.ts
    const authRequest = req.clone({ // cloned outgoing request and added token config to auth header
      headers: req.headers.set('Authorization', 'Bearer ' + authToken)
    });
    return next.handle(authRequest);
  }
}
