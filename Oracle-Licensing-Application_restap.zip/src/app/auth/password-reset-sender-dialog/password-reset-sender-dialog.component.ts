// angular
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';

// misc
import { ReCaptchaV3Service } from 'ng-recaptcha';

@Component({
  selector: 'app-password-reset-sender-dialog',
  templateUrl: './password-reset-sender-dialog.component.html',
  styleUrls: ['./password-reset-sender-dialog.component.css']
})
export class PasswordResetSenderDialogComponent implements OnInit {

  form: FormGroup;
  constructor(public dialogRef: MatDialogRef<PasswordResetSenderDialogComponent>, private recaptchaV3Service: ReCaptchaV3Service) { }

  ngOnInit() {
    this.form = new FormGroup({
      'recaptchaCheck': new FormControl(null, Validators.required),
      'email': new FormControl(null, [Validators.required, Validators.email])
    });
  }

  email(form: any) {
    if (!form.invalid) {
      this.dialogRef.close(form.value);
    } else {
      return;
    }
  }

}
