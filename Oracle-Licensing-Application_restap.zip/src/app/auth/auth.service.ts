// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

// models
import { AuthData } from './auth-data.model';
import { Subject } from 'rxjs';

// services
import { AuditService } from '../audit/audit.service';

// misc
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';


const BACKEND_URL = environment.apiUrl  + '/user';


@Injectable({ providedIn: 'root'})

export class AuthService {
  private isAuthenticated = false;
  private token: string;
  private refreshToken: string;
  private tokenTimer: any;
  private refreshTimer: any;
  private userId: string;
  private notificationListener = new Subject<{notifications: any}>();
  private authStatusListener = new Subject<boolean>();
  private userUpdateProfileListener = new Subject<boolean>();
  private roleListener = new Subject<string>();
  private companyListener = new Subject<string>();
  private userListener = new Subject<{array}>();
  private emailChecker = [];
  private role: string;
  private company: string;
  private companyName: string;
  private usersUpdated = new Subject<{users: AuthData[], userCount: Number}>();

  constructor(private http: HttpClient, private router: Router, private auditService: AuditService) {}

  // multiple get functions to recieve respective values
  getToken() {
    return this.token;
  }

  sendRequest(requestObj) {
    this.http.post<{message: String}>(BACKEND_URL + '/sendRequest', requestObj).subscribe();
  }

  getNotifications(userEmail) {
    this.http.get<{message: String, notifications: any}>(BACKEND_URL + '/getNotifications/' + userEmail).subscribe(result => {
      this.notificationListener.next({notifications: result.notifications});
    });
  }

  getNotificationListener() {
    return this.notificationListener.asObservable();
  }

  getRefreshToken() {
    return this.refreshToken;
  }

  getIsAuth() {
    return this.isAuthenticated;
  }

  getAuthStatusListener() {
    return this.authStatusListener.asObservable();
  }

  getRoleListener() {
    return this.roleListener.asObservable();
  }

  getCompanyListener() {
    return this.companyListener.asObservable();
  }
  getUserListener() {
    return this.userListener.asObservable();
  }

  getUserUpdateProfileListener() {
    return this.userUpdateProfileListener.asObservable();
  }

  getEmailCheckerListener() {
    return this.emailChecker;
  }

  getRole() {
    return this.role;
  }

  getUserId() {
    return this.userId;
  }

  getCompany() {
    return this.company;
  }

  getAllUsersListener() {
    return this.usersUpdated.asObservable();
  }

  getAllUsers() {
    this.http.get<{message: string, users: any}>(BACKEND_URL + '/all-users')
    .pipe(map((userData) => {
      return { users: userData.users };
    })).subscribe((transformedData) => {
      this.usersUpdated.next({users: [...transformedData.users], userCount: transformedData.users.length});
    });
  }

  // function that is called from the signup component
  // this function recieves info from said component and then sends it to the backend via an api call
  createUser( value: any) {
    const authData: AuthData = {_id: undefined, email: value.email, password: value.password,
                                role: value.user_role, company: value.company, darkmode: false, headers: false};
    this.http.post( BACKEND_URL + '/signup', authData)
      .subscribe(() => {
        this.router.navigate(['/']);
      }, error => {
        this.authStatusListener.next(false);
      });
  }

  // function that is called from the login component, recieves info from said component and then sends it to the backend via an api call.
  login(email: string, password: string) {
    const authData = {email: email, password: password};
    this.http.post<{
      token: string, refreshToken: string, expiresIn: number, refreshExpiresIn: number, userId: string, role: string, company: string,
      subsidiaries: any, name: string }>
     ( BACKEND_URL + '/login', authData)
      .subscribe(response => {
        // gets a token from the backend
        // checks to see if a login token is present, if yes then variables are set and the user is naviagted to the home page
        // else an error is thrown
        if (response.token) {
          this.token = response.token;
          this.refreshToken = response.refreshToken;
          this.isAuthenticated = true;
          this.authStatusListener.next(true);
          this.setAuthTimer(response.expiresIn);
          this.setRefreshTimer(response.refreshExpiresIn);
          this.userId = response.userId;
          this.role = response.role;
          this.roleListener.next(response.role);
          this.companyName = response.name;
          const now = new Date();
          const expirationDate = new Date(now.getTime() + response.expiresIn * 1000);
          const refreshExpirationDate = new Date(now.getTime() + response.refreshExpiresIn * 1000);
          this.saveAuthData(
            this.token, this.refreshToken, expirationDate, refreshExpirationDate,
            email, this.userId, this.role, this.companyName);
          // this.auditService.loginAudit(this.userId, authData.email);
          this.router.navigate(['/list-company']);
        }
      }, error => {
        this.authStatusListener.next(false);
      });
  }

  newCompanyRefreshedToken(token: string, expiresIn: number) {
    try {
      this.token = token;
      this.isAuthenticated = true;
      this.authStatusListener.next(true);
      this.setAuthTimer(expiresIn);
      const now = new Date();
      const expirationDate = new Date(now.getTime() + expiresIn * 1000);
      localStorage.setItem('token', token);
      localStorage.setItem('expiration', expirationDate.toISOString());
    } catch (err) {
      this.authStatusListener.next(false);
    }
  }

  refreshTheToken() {
    this.http.post<{
      token: string, expiresIn: number}>
      ( BACKEND_URL + '/token', {refreshToken: localStorage.getItem('refreshToken')})
      .subscribe(response => {
        if (response.token) {
          this.token = response.token;
          this.isAuthenticated = true;
          this.authStatusListener.next(true);
          this.setAuthTimer(response.expiresIn);
          const now = new Date();
          const expirationDate = new Date(now.getTime() + response.expiresIn * 1000);
          localStorage.setItem('token', response.token);
          localStorage.setItem('expiration', expirationDate.toISOString());
        }
      }, err => {
        this.authStatusListener.next(false);
      });
  }

  autoAuthUser() {
    const authInformation = this.getAuthData();
    if (!authInformation) {
      return;
    }
    const now = new Date();
    const expiresIn = authInformation.expirationDate.getTime() - now.getTime();
    if (expiresIn > 0) {
      this.token = authInformation.token;
      this.isAuthenticated = true;
      this.userId = authInformation.userId;
      this.role = authInformation.role;
      this.setAuthTimer(expiresIn / 1000);
      this.authStatusListener.next(true);
    }
  }

  updateUserProfilePassword(form: any) {
    this.http.put<{message: string, user: any}>(BACKEND_URL + '/updateUserProfilePassword/' + form._id, form).subscribe(response => {
      if (response.user) {
        this.userUpdateProfileListener.next(true);
      }
    });
  }

  getEmailCheckedList(emailList) {
    return this.http.post<{messsage: string, email: any}>(BACKEND_URL + '/emailCheck', emailList);
  }

  getEmails(email: any) {
  this.emailChecker = [];
   this.http.get<{message: string, users: any}>( BACKEND_URL + '/users/' + email).subscribe(response => {
      if (response.users === email) {
        this.emailChecker.push(response.users);
      }
    });
  }

  getUsersByCompany(id: string) {
    this.http.get<{message: string, users: any}>(BACKEND_URL + '/userByCompany/' + id).subscribe((response) => {
      this.userListener.next({array: response});
    });
  }
  // called whenever the
  logout() {
    this.token = null;
    this.refreshToken = null;
    this.isAuthenticated = false;
    this.authStatusListener.next(false);
    this.userId = null;
    this.role = 'read';
    clearTimeout(this.tokenTimer);
    clearTimeout(this.refreshTimer);
    this.clearAuthData();
    this.router.navigate(['/auth/login']);
  }

  // function for saving data into localstorage to be used throughout the app
  private saveAuthData(
    token: string, refreshToken: string, expirationDate: Date,
    refreshExpirationDate: Date, email: string, userId: string, role: string, name: string
    ) {
    localStorage.setItem('token', token);
    localStorage.setItem('refreshToken', refreshToken);
    localStorage.setItem('expiration', expirationDate.toISOString());
    localStorage.setItem('refreshExpiration', refreshExpirationDate.toISOString());
    localStorage.setItem('email', email);
    localStorage.setItem('userId', userId);
    localStorage.setItem('role', role);
    localStorage.setItem('name', name);
  }

  // function to remove data from local storage
  private clearAuthData() {
    localStorage.removeItem('token');
    localStorage.removeItem('expiration');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('refreshExpiration');
    localStorage.removeItem('email');
    localStorage.removeItem('userId');
    localStorage.removeItem('role');
    localStorage.removeItem('name');
    localStorage.removeItem('compId');
    localStorage.removeItem('contractId');
    localStorage.removeItem('hardwareId');
  }

  setRefreshTimer(duration: number) {
    this.refreshTimer = setTimeout(() => {
      this.logout();
    }, duration * 1000);
  }

  // sets a timer
  setAuthTimer(duration: number) {
    this.tokenTimer = setTimeout(() => {
        this.refreshTheToken();
    }, (duration - 60) * 1000);
  }

  private getAuthData() {
    const token = localStorage.getItem('token');
    const refreshToken = localStorage.getItem('refreshToken');
    const expirationDate = localStorage.getItem('expiration');
    const refreshExpirationDate = localStorage.getItem('refreshExpiration');
    const email = localStorage.getItem('email');
    const userId = localStorage.getItem('userId');
    const role = localStorage.getItem('role');
    const name = localStorage.getItem('name');
    if (! token || !expirationDate) {
      return;
    }
    return {
      token: token,
      refreshToken: refreshToken,
      expirationDate: new Date(expirationDate),
      refreshExpirationDate: new Date(refreshExpirationDate),
      email: email,
      userId: userId,
      role: role,
      name: name
    };
  }

  sendingEmail(email) {
    const emailObj = {email: email};
    this.http.post(BACKEND_URL + '/sendEmail', emailObj).subscribe(result => {
    });
  }


  passwordReset(token) {
    const tokenObj = {token: token};
    return this.http.post<{email: string, emailId: string, status: Boolean}>(BACKEND_URL + '/passwordReset', tokenObj);
  }

  resetPassword(form) {
    this.http.post(BACKEND_URL + '/savingNewPassword', form).subscribe();
  }

  deleteUser(userId: string) {
    return this.http.delete<{message: string}>(BACKEND_URL + '/delete/' + userId);
  }

  updateMasterUser(userDetails) {
    return this.http.put(BACKEND_URL + '/update-user/' + userDetails.user._id, userDetails);
  }

}
