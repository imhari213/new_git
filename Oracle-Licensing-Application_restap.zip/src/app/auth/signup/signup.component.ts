// angular
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

// models
import { Company } from '../../companies/company.model';

// services
import { AuthService } from '../auth.service';
import { CompanyService } from 'src/app/companies/companies.service';

// misc
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})

export class SignupComponent implements OnInit, OnDestroy {

  form: FormGroup;
  userIsAuthenticated: Boolean;
  userRole = 'read';

  rolesAllowed = ['write', 'read'];
  companies: Company[];

  dataSourceEndUserContact: any;
  displayedColumnsEndUserContact =  ['Email', 'Role', 'Edit'];
  contacts = [];
  companyId;
  company;
  hide = true;

  authStatusSub: Subscription;
  companySub: Subscription;

  constructor(private authService: AuthService, private router: Router,
    private companyService: CompanyService, private location: Location) {}

  ngOnInit() {
    this.getAuth();
    this.createForm();
    this.getCompanies();
  }

  ngOnDestroy() {}

  getAuth() {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService.getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });
    if (this.userIsAuthenticated === false) {
      this.router.navigate(['/auth/login']);
    }
    this.userRole = this.authService.getRole();
    if (!this.userRole) {
      this.userRole = 'read';
    }

    if (['master', 'admin'].includes(this.userRole)) {
      this.rolesAllowed = ['admin'].concat(this.rolesAllowed);
    }
    if (this.userRole === 'master') {
      this.rolesAllowed = ['master'].concat(this.rolesAllowed);
    }
  }

  createForm() {
    this.form = new FormGroup({
      'email': new FormControl(null, Validators.email),
      'password': new FormControl(null),
      'user_role': new FormControl(null),
      'company': new FormControl(null)
    });
  }

  onCancel() {
    this.location.back();
  }

  getCompanies() {
    this.companyService.getCompanies(null, null);
    this.companySub = this.companyService.getCompanyUpdateListener()
      .subscribe((companyData: {companies: Company[]; companyCount: Number}) => {
        this.companies = companyData.companies;
      });
  }

  setCompany(companyId) {

    try {
      this.companyId = companyId;
      this.company = this.companies.find(comp => comp._id === companyId);
      this.contacts = this.company.end_user_contacts;
    } catch {
      this.company = null;
      this.contacts = [];
    }

    this.dataSourceEndUserContact = new MatTableDataSource(this.contacts);

  }

  onSignup() {
    if (this.form.invalid) {
      return;
    }
    this.authService.createUser(this.form.value);
    this.router.navigate(['/list-company']);
  }
}
