// angular
import { OnInit, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-user-dialog',
    templateUrl: './edit-user-dialog.component.html',
    styleUrls: ['./edit-user-dialog.component.css']
  })
  export class UserDetailEditComponent implements OnInit {

    form: FormGroup;
    roleOptions = ['read', 'write', 'admin'];
    selected;

    constructor(public dialogRef: MatDialogRef<UserDetailEditComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any) {}

    ngOnInit() {
      this.form = new FormGroup({
        '_id': new FormControl(null),
        'email': new FormControl(null, Validators.email),
        'password': new FormControl(null),
        'role': new FormControl(null),
        'company': new FormControl(null)
      });
      this.selected = this.data.role;
      this.form.patchValue({
        '_id': this.data._id,
        'email': this.data.email,
        'password': this.data.password,
        'role': this.data.role,
        'company': this.data.company,
      });
    }

    onSignup() {
      if (this.form.invalid) {
        return;
      } else {
        this.dialogRef.close(this.form.value);
      }
    }
  }
