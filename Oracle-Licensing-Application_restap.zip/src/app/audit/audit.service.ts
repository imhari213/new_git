// angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

// misc
import { environment } from '../../environments/environment';


const BACKEND_URL = environment.apiUrl  + '/audit';

@Injectable({providedIn: 'root'})

export class AuditService {

  constructor(private http: HttpClient, private router: Router) {}

  loginAudit(userId: string, email: string) {
    const data = {userId: userId, email: email};
    this.http.post(BACKEND_URL + '/login', data).subscribe();
  }

  addAudit(database: string, objId: string, action: string, relatedString, subDatabase: string, subId: string, subRelatedString) {
    const object = {userId: localStorage.getItem('userId'),
                    databaseChanged: database,
                    relatedId: objId,
                    relatedString: relatedString,
                    subDatabase: subDatabase,
                    subId: subId,
                    subRelatedString: subRelatedString,
                    action: action};
    this.http.post(BACKEND_URL, object).subscribe();
  }

}
