// server
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');

// database
const mongoose = require('mongoose');

// routes
const userRoutes = require('./routes/user');
const companyRoutes = require('./routes/company');
const contractRoutes = require('./routes/contract');
const DbRoutes = require('./routes/database');
const hwRoutes = require('./routes/hardware');
const vcenterRoutes = require('./routes/vcenter');
const configRoutes = require('./routes/config');
const auditRoutes = require('./routes/audit');
const declarationRoutes = require('./routes/declarations');
const middlewareRoutes = require('./routes/middleware');

const bulkUploadRoutes = require('./routes/bulkUpload');

const app = express(); //returns an express app
const dotenv = require('dotenv');
dotenv.config();

mongoose.connect('mongodb+srv://' + process.env.MONGO_USER + ':' + process.env.MONGO_PW + '@applicationdevelopment-o6lnv.mongodb.net/demo?retryWrites=true&w=majority', {useFindAndModify:false, useCreateIndex: true, useNewUrlParser: true, useUnifiedTopology: true})
  .then(() => {
    console.log('Connected to Database!');
  })
  .catch(error => {
    console.log('Connection failed!');
    console.log(error.message)
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/images', express.static(path.join('backend/images')));
app.use('/files', express.static(path.join('backend/files')));

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); //allows which domains are able to access our resources
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  ); //Allow these extra headers access
  res.setHeader(
    'Access-Control-Allow-Methods',
    'GET, POST, PATCH, PUT, DELETE, OPTIONS'
  );
  next();
});

// download file method
app.post('/download', function(req, res, next) {
  filepath = path.join(__dirname,'../backend/' + req.body.filelocation) + '/' + req.body.filename;
  res.sendFile(filepath);
});

app.use('/api/user', userRoutes);
app.use('/api/company', companyRoutes);
app.use('/api/contract', contractRoutes);
app.use('/api/database', DbRoutes);
app.use('/api/hardware', hwRoutes);
app.use('/api/vcenter', vcenterRoutes);
app.use('/api/config', configRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/declarations', declarationRoutes);
app.use('/api/middleware', middlewareRoutes);

app.use('/api/bulkUpload', bulkUploadRoutes);

module.exports = app;
