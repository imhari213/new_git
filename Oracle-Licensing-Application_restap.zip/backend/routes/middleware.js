const express = require('express');
const router = express.Router();
const checkAuth = require('../middleware/check-auth');
const middlewareController = require('../controllers/middleware');

router.post('', checkAuth, middlewareController.createMiddleware);

router.get('', checkAuth, middlewareController.searchMiddleware);
router.get('/:id', checkAuth,middlewareController.getMiddlewareById);

router.put('/:id', checkAuth, middlewareController.updateMiddleware);

router.delete('/:id', checkAuth, middlewareController.deleteMiddleware);

module.exports = router;
