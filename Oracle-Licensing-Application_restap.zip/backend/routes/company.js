const express = require('express');
const router = express.Router();
const companyController = require ('../controllers/companies');
const checkAuth = require('../middleware/check-auth');


router.post('', checkAuth, companyController.createCompany);

router.get('/subNames/:compId', checkAuth, companyController.getSubNameList);

router.get('', checkAuth, companyController.getAllCompanies);
router.get('/:id', checkAuth, companyController.getCompanyById);
router.get('/search/:searchQuery', checkAuth,  companyController.searchCompany);
router.get('/companyData/:companyName', checkAuth, companyController.getCompanyByName);

router.put('/:id', checkAuth, companyController.updateCompany);

router.delete('/:id', checkAuth, companyController.deleteCompany);

module.exports = router;
