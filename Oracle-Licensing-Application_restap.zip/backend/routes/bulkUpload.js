const express = require('express');
const router = express.Router();
const bulkController = require ('../controllers/bulkUpload');

router.post('',  bulkController.createCompany);
router.post('/createDatabase', bulkController.createDatabase);


 
module.exports = router;
