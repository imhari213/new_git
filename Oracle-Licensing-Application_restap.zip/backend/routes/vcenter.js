const express = require('express');
const router = express.Router();
const checkAuth = require('../middleware/check-auth');
const vcenterController = require('../controllers/vcenters');

router.get('', checkAuth, vcenterController.getVCenters);
router.get('/search/:searchParam/', checkAuth, vcenterController.searchVCenters);
//router.get('/:searchType/:id', checkAuth, vcenterController.getVCenters);
router.get('/:id', checkAuth, vcenterController.getVCenter);

router.post('', checkAuth, vcenterController.createVCenter);

router.put('/:id', checkAuth, vcenterController.updateVCenter);

router.delete('/vcenter/:id', checkAuth, vcenterController.deleteVCenter);
router.delete('/cluster/:id', checkAuth, vcenterController.deleteCluster);

module.exports = router;
