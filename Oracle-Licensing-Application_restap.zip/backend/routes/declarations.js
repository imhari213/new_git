const express = require('express');
const router = express.Router();
const declarationController = require ('../controllers/declarations');
const checkAuth = require('../middleware/check-auth');

router.post('', checkAuth, declarationController.createDeclaration);

router.get('/search/:searchQuery', checkAuth, declarationController.getDeclarations);
router.get('/declaration/:declarationId', checkAuth, declarationController.getDeclaration);

router.put('/update/:declarationId', checkAuth, declarationController.updateDeclaration);

router.delete('/delete/:declarationId', checkAuth, declarationController.deleteDeclaration);




module.exports = router;
