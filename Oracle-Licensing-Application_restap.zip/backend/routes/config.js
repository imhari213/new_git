const express = require('express');
const router = express.Router();
const configController = require ('../controllers/config');
const checkAuth = require('../middleware/check-auth');

// Contract Variables
router.get('/supportStatus', configController.getAllSupportStatus);
router.post('/supportStatus', configController.createSupportStatus);
router.delete('/supportStatus/:id', configController.deleteSupportStatus);

router.get('/currency', configController.getAllCurrencies);
router.post('/currency', configController.createCurrency);
router.delete('/currency/:id', configController.deleteCurrency);

// Database Variables
router.get('/managementPacks', configController.getAllManagementPacks);
router.post('/managementPacks', configController.createManagementPack);
router.delete('/managementPacks/:id', configController.deleteManagementPack);

router.get('/optionsInUse', configController.getAllOptionsInUse);
router.post('/optionsInUse', configController.createOptionInUse);
router.delete('/optionsInUse/:id', configController.deleteOptionInUse);

router.get('/productEdition', configController.getAllProductEdition);
router.post('/productEdition', configController.createProductEdition);
router.delete('/productEdition/:id', configController.deleteProductEdition);

router.get('/enviromentalUsage', configController.getAllEnviromentalUsage);
router.post('/enviromentalUsage', configController.createEnviromentalUsage);
router.delete('/enviromentalUsage/:id', configController.deleteEnviromentalUsage);

module.exports = router;
