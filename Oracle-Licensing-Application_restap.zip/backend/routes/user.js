const express = require('express');
const UserController = require ('../controllers/user');
const CheckAuth = require('../middleware/check-auth');
const router = express.Router();

router.get('/test', UserController.test);

router.post('/signup', CheckAuth, UserController.createUser);
router.post('/login', UserController.userLogin);
router.post('/sendEmail', UserController.sendEmail);
router.post('/passwordReset', UserController.passwordReset);
router.post('/savingNewPassword', UserController.savingNewPassword);
router.post('/emailCheck', CheckAuth, UserController.emailCheck);

//for notification / request stuff
router.post('/sendRequest', CheckAuth, UserController.sendUserRequest);
router.get('/getNotifications/:userEmail', CheckAuth, UserController.getNotifications);

router.get('/users/:email', CheckAuth, UserController.getUsersEmails);
router.get('/userByCompany/:id', CheckAuth, UserController.getUsersByCompany);
router.get('/all-users', CheckAuth, UserController.getAllUsers);
router.get('/getTheme/:id', CheckAuth, UserController.getUserTheme);
router.get('/getHeaderOption/:id', CheckAuth, UserController.getUserHeaderOption);

router.put('/updateUserProfilePassword/:id', CheckAuth, UserController.updateUserProfilePassword);
router.put('/updateUserTheme/:id', CheckAuth, UserController.updateUserTheme);
router.put('/updateUserHeaderOption/:id', CheckAuth, UserController.updateUserHeaderOption);

router.put('/update-user/:id', CheckAuth, UserController.updateUserMaster);

router.post('/token', CheckAuth, UserController.refreshToken);

router.delete('/delete/:id', CheckAuth, UserController.deleteUser);

module.exports = router;

