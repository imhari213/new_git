const express = require('express');
const router = express.Router();
const hardwareController = require ('../controllers/hardware');
const checkAuth = require('../middleware/check-auth');

router.post('', checkAuth, hardwareController.createHardware);

router.get('', checkAuth, hardwareController.getAllHardware);
router.get('/:id', checkAuth, hardwareController.getHwById);
router.get('/search/:searchParam', checkAuth, hardwareController.searchHardware);
// router.get('/hardwareBySpecificId/:id', hardwareController.getHardwaresBySpecificId);
router.get('/hardwareByServerName/:serverId', hardwareController.getServerName);
router.get('/serverNameList/:compId', hardwareController.getServerNameList)

router.put('/update/:id', checkAuth, hardwareController.updateHardware);
router.put('/update_allocations', checkAuth, hardwareController.migrateAllocatedLicense);

router.delete('/:id', checkAuth, hardwareController.deleteHardware);

module.exports = router;
