const express = require('express');
const router = express.Router();
const databaseController = require ('../controllers/databases');
const checkAuth = require('../middleware/check-auth');

router.post('', checkAuth, databaseController.createDatabase);
router.post('/migrateDb/', checkAuth, databaseController.migrateDb);

router.get('/:id', checkAuth, databaseController.getDbById);
router.get('/search/:searchParam', checkAuth, databaseController.searchDatabases);

router.delete('/:id', checkAuth, databaseController.deleteDatabase);

router.put('/:id', checkAuth, databaseController.updateDatabase);



module.exports = router;
