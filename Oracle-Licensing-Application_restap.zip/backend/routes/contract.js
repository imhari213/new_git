const express = require('express');
const router = express.Router();
const contractController = require ('../controllers/contracts');
const checkAuth = require('../middleware/check-auth');
const extractFile = require('../middleware/file');

router.post('', checkAuth, extractFile, contractController.createContract);
router.post('/new_license', checkAuth, contractController.createLicense);

// router.get('', checkAuth, contractController.getAllContracts);
router.get('/search/:searchQuery', checkAuth, contractController.searchContracts);
router.get('/:id', checkAuth, contractController.getContractById);
router.get('/migrate/:compId', checkAuth, contractController.getValidContracts);
router.put('/:id', extractFile, checkAuth, contractController.updateContract);

router.delete('/:id', checkAuth, contractController.deleteContract);




module.exports = router;
