const express = require('express');
const router = express.Router();
const auditController = require ('../controllers/audit');
const checkAuth = require('../middleware/check-auth');

router.post('', checkAuth, auditController.addAudit);
router.post('/login', auditController.login)

module.exports = router;
