const mongoose = require('mongoose');

const vcenterSchema = mongoose.Schema({
   //  _id: {type: mongoose.Schema.Types.ObjectId},
    company: {type: mongoose.Schema.Types.ObjectId, ref: "Comp"},
    vcenter_server_name: {type: String, unique: true},
    vcenter_version: {type: String},
    dataCenters: [{type: mongoose.Schema.Types.ObjectId, ref: "DataCenter"}],
})

module.exports = mongoose.model('Vmware', vcenterSchema);
