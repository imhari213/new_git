const mongoose = require('mongoose');

const clusterSchema = mongoose.Schema({
    cluster: String
})

module.exports = mongoose.model('Cluster', clusterSchema);
