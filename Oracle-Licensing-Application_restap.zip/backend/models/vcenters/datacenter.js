const mongoose = require('mongoose');

const clusterSchema = mongoose.Schema({
  cluster: String
})

const dataCenterSchema = mongoose.Schema({
    data_center: String,
    clusters: [{type: mongoose.Schema.Types.ObjectId, ref: "Cluster"}]
})

module.exports = mongoose.model('DataCenter', dataCenterSchema);
