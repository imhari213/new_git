const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const PartitionEvSchema = new Schema({
  owner: String,
  segment_type: String,
  segment_name: String,
  min_created: Date,
  min_last_dll_time: Date,
})

const ADGEvSchema = new Schema({
  dest_id: Number,
  dest_name: String,
  status: String,
  type: String,
  database_mode: String,
  recovery_mode: String,
})

const SpatialEvSchema = new Schema({
  sdo_geom_metadata_table: Number,
})

const OlapEvSchema = new Schema({
  owner: String,
  aw_number: Number,
  aw_name: String,
  pagespaces: Number,
  generations: Number,
})

const AdvancedCompEvSchema = new Schema({
  version: String,
  name: String,
  currently_used: Boolean,
  last_usage_date: Date,
  last_sample_date: Date,
})

const RealAppClusEvSchema = new Schema({
  oracle_rac_installed: String,
  value: String,
  inst_id_status: String,
})

const MultiTenantEvSchema = new Schema({
  cbd: String,
  con_id_name: String,
  open_mode: String,
  open_time: String,
  container: String,
})

const AdvancedSecurityEvSchema = new Schema({
  tablespace_name: String,
  enc: String
})

const ManagementEvSchema = new Schema({
  name: String,
  created: Date,
  last_modified: Date,
  description: String,
  type: String,
  status: String,
})

const evidenceSchema = new Schema({
  location: String,
  comments: String,
  partition_ev: [PartitionEvSchema],
  active_data_guard_ev: [ADGEvSchema],
  spatial_ev: [SpatialEvSchema],
  olap_ev: [OlapEvSchema],
  advanced_comp_ev: [AdvancedCompEvSchema],
  real_app_cluster_ev: [RealAppClusEvSchema],
  multitenant_ev: [MultiTenantEvSchema],
  advanced_security_ev: [AdvancedSecurityEvSchema],
  management_ev: [ManagementEvSchema]
})

const optionSchema = new Schema({
  option_in_use: String,
  host_name: String,
  instance: String,
  version: String,
  support_status: String,
  usage: String,
  bugs: String,
  detected_usages: Number,
  total_samples: Number,
  currently_used: Boolean,
  aux_count: Number,
  feature_information: String,
  last_sample_date: Date,
  last_sample_period: String,
  sample_interval: String,
  description: String,
  sys_date: Date,
  feature_mapped: String,
  evidence: evidenceSchema

});

const managementSchema = new Schema({
    management_in_use: String,
    host_name: String,
    instance: String,
    version: String,
    support_status: String,
    usage: String,
    bugs: String,
    detected_usages: Number,
    total_samples: Number,
    currently_used: Boolean,
    aux_count: Number,
    feature_information: String,
    last_sample_date: Date,
    last_sample_period: String,
    sample_interval: String,
    description: String,
    sys_date: Date,
    evidence: evidenceSchema
});

const DbSchema = new Schema({
    database_instance_name: String,
    physical_server_name: {type: mongoose.Schema.Types.ObjectId, ref: "hardware",required: true},
    virtual_server_name: String,
    pluggable_databases: String,
    environment_usage: String,
    options_in_use: [optionSchema],
    managements_in_use: [managementSchema],
    rac_nodes: String,
    fal_server: String,
    fal_client: String,
    cpu_count: Number,
    cpu_count_default: Boolean,
    installation_date: Date,
    users_defined: Number,
    product_edition: String,
    product_version: String,
    control_management_pack_access: String,
    current_sessions: Number,
    highwater_sessions: String,
    database_cloned_from: String,
    database_cloned_date: Date,
    application_name: String,
    application_vendor: String,
    application_type: String,
    architecture_type: String,
    user_type: String,
    web_or_app_tier_server_name: String,
    ebs_release: String,
    end_user: {type: mongoose.Schema.Types.ObjectId, ref: "Comp",required: true},
    virtualisation_tech: String,
    migrated_from: String,
    migration_date: Date,
    spatial_and_graph: Boolean,
    advanced_analytics: Boolean
});

const Database = mongoose.model('Db', DbSchema);

module.exports = Database;
