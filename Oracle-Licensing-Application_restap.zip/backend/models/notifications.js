const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const migrateDbSchema = mongoose.Schema({
    "db_id": {type: mongoose.Schema.Types.ObjectId, ref: "Db"},
    "hw_id": {type: mongoose.Schema.Types.ObjectId, ref: "Hardware"},
});

const notificationSchema = mongoose.Schema({
    "made_by" : String,
    "made_for": String,
    "time_requested": Date,
    "content": String,
    "severity": String,
    "marked_resolved": Boolean,
    "company": String,
    "type_of_request": String,
    "migrate_db": migrateDbSchema
});


module.exports = mongoose.model('Notification', notificationSchema);