const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AdditionalOracleProductsSchema = new Schema({
  'product': String,
  'license_metric': String,
  'existing_license_level': String,
  'customer_support_identifier': String,
  'license_grant': Number,
  'declared_usage': Number,
  'additional_comments': String,
  'company': {type: Schema.Types.ObjectId, ref: 'Comp'}
});

const AdditionalOracleProducts = mongoose.model('AdditionalOracleProducts', AdditionalOracleProductsSchema);

module.exports = AdditionalOracleProducts;
