const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const auditLogSchema = new Schema({
  userId: {type: mongoose.Schema.Types.ObjectId, ref: 'users'},
  email: String,
  datetime: Date,
  databaseChanged: String,
  relatedId: {type: mongoose.Schema.Types.ObjectId},
  relatedString: String,
  // add, edit, delete, decommission
  action: String,
  subDatabase: String,
  subId: {type: mongoose.Schema.Types.ObjectId},
  subRelatedString: String
})

module.exports = mongoose.model('AuditLog', auditLogSchema);
