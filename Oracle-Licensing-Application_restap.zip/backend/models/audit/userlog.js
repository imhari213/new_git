const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userLogSchema = new Schema({
  userId: {type: mongoose.Schema.Types.ObjectId, ref: 'users'},
  email: String,
  datetime: Date
})

module.exports = mongoose.model('UserLog', userLogSchema);
