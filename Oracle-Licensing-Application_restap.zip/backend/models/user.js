const mongoose = require('mongoose');
const uniqueValidator = require ('mongoose-unique-validator');

const userSchema = mongoose.Schema({
  email: { type: String, required: true, unique: true }, // unique not a validator, allows mongoose to know its unique data for querying
  password: { type: String, required: true},
  role: {type: String, required: true, defaultValue: false},
  company: {type: mongoose.Schema.Types.ObjectId, ref: "Comp"},
  darkmode: {type: Boolean, defaultValue: false},
  headers: {type: Boolean, defaultValue: false}
});

userSchema.plugin(uniqueValidator);

module.exports = mongoose.model('User', userSchema);
