const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const EndUserCommentSchema = new Schema({
  comment_date: Date,
  comment_message: String,
  comment_contact: String,
  entered_by: {
    id: {type: Schema.Types.ObjectId, ref: 'User'},
    email: String
  }
});

const EndUserContactSchema = new Schema({
  end_user_name: String,
  end_user_role: String,
  end_user_type: String,
  end_user_pnumber: String,
  end_user_email: String,
  end_user_location: String,
});

//Create Schema
const CompanySchema = new Schema({
    company_name: {type: String, unique: true},
    hq_location: String,
    end_user_contacts: [EndUserContactSchema],
    end_user_comments: [EndUserCommentSchema],
    end_user_subsidiaries: [{type: Schema.Types.ObjectId, ref: 'Comp'}],
    oma_reference_number: String,
    vad_name: String,
    vad_contact: String
});

//Model
module.exports = mongoose.model('Comp', CompanySchema);
 