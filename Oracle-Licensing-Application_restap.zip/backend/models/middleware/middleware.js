const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const componentsInstalledSchema = new Schema({
  "component_installed": String,
  "location_of_evidence": String
});

const optionSchema = new Schema({
  "option_in_use": String,
  "start_date": Date,
  "end_date": Date
});

const managementSchema = new Schema({
  "management_in_use": String,
  "start_date": Date,
  "end_date": Date
});

const MiddlewareSchema = new Schema({
  // "product": String,
  "company": {type: mongoose.Schema.Types.ObjectId, ref: "Comp"},
  "components_installed": [componentsInstalledSchema],
  // "licensable_product": String,
  // "product_version": String,
  "environment_usage": String,
  // "physical_server": String,
  "physical_server": {type: mongoose.Schema.Types.ObjectId, ref: "hardware"},
  // "primary_server_for_failover_dr_backup_testing": {type: mongoose.Schema.Types.ObjectId, ref: "hardware"},
  "virtual_server_for_failover_dr_backup_testing": String,
  "managements_in_use": [managementSchema],
  "options_in_use": [optionSchema]
});

const Middleware = mongoose.model('middleware', MiddlewareSchema);

module.exports = Middleware;
