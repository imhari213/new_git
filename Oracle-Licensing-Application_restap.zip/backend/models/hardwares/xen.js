const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const xenSchema = new Schema({
  virtual_server_name: String,
  cpu_affiniity: String,
  vcpus: String,
  dedicated_vcpus: String,
  notes: String
})

module.exports = mongoose.model('Xen', xenSchema);
