const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PoolSchema = new Schema ({
  pool_name: String,
  pset_value_for_zone_from_physical: String,
  pset_value_for_zone_from_virtual: String,
  total_count_core_id: String,
})

const LocalZoneSchema = new Schema({
  dedicated_cpu: String,
  capped_cpus: String,
  ncpus: String
})

const OvmForSparcSchema = new Schema({
  constraint: String,
  whole_core: String,
  max_cores: String,
  pinned: String,
})

const SolarisSchema = new Schema ({
  virtual_server_name: String,
  type_of_solaris_partitioning: String,
  pool_type: PoolSchema,
  local_zone_type: LocalZoneSchema,
  ovm_for_sparc_type: OvmForSparcSchema,
  notes: String,
})

module.exports = mongoose.model('Solaris', SolarisSchema);
