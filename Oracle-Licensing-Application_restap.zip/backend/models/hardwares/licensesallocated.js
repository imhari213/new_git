const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const licenseSchema = new Schema({
  virtualisation_linked: {type: mongoose.Schema.Types.ObjectId},
  product_licensed:  {type: mongoose.Schema.Types.ObjectId, ref: "OracleLicense"},
  license_metric_allocated: String,
  number_of_licenses_in_use: Number,
  contract_linked:  {type: mongoose.Schema.Types.ObjectId, ref: "Contract"},
  restricted_use: String
})

module.exports = mongoose.model('LicensesAllocated', licenseSchema);
