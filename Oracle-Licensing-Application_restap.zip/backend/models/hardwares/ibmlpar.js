const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const IbmLparSchema = new Schema({
  virtual_server_name: String,
  machine_serial_number: String,
  partition_name: String,
  partition_number: String,
  partition_type: String,
  mode: String,
  entitled_capacity: String,
  shared_pool_id: String,
  online_virtual_cpus: String,
  maximum_physical_cpus_in_system: String,
  active_physical_cpus_in_system: String,
  shared_physical_cpus_in_system: String,
  notes: String,
})

module.exports = mongoose.model('IbmLpar', IbmLparSchema);
