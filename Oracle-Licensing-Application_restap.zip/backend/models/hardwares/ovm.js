const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const OvmSchema = new Schema({
  virtual_server_name: String,
  uuid: String,
  max_vcpus: String,
  vcpus: String,
  cpu_affinity: String,
  total_cpus: String,
  live_migration: Boolean,
  ovm_high_availability: Boolean,
  notes: String,
  dom0_max_vcpus: Number,
  dom0_cpu_affinity: String,
  ovm_ha: String,
  cpus: String,
  physical_server_mapping: String,
  total_threads: Number,
  threads_per_core: Number,
  licensable_cores: Number,
  same_pool_procs: String,
  virtual_procs: String,
})

module.exports = mongoose.model('Ovm', OvmSchema);
