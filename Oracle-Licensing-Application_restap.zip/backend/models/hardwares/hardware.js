const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//
// cloud schemas need extracting
//
const CloudSchema = new Schema ({
  virtual_server_name: String,
  description: String,
  instance_type: String,
  vcpus: Number,
  hyperthreaded: Boolean,
  license_method: String
})

const OtherVirt = new Schema ({
  virtual_server_name: String,
  description: String
})

const OtherCloud = new Schema ({
  virtual_server_name: String,
  description: String
})

const HardwareSchema = new Schema({
  cluster_id: {type: mongoose.Schema.Types.ObjectId, ref: "Vmware"},
  company: {type: mongoose.Schema.Types.ObjectId, ref: "Comp"},
  server_name: String,
  server_model: String,
  virtualisation_name: String,
  virtualisation_description: String,
  operating_system: String,
  processor_model: String,
  processors: Number,
  cores_per_processor: Number,
  total_physical_cores: Number,
  cores_enabled: Number,
  threads_per_core: Number,
  multi_core_chip_or_multi_chip_model: String,
  processor_speed: String,
  server_purchase_date: Date,
  server_location: String,
  commission_date: Date,
  decommission_date: Date,
  hardware_refresh_term_or_date: String,
  license_allocated_to_server: [{type: mongoose.Schema.Types.ObjectId, ref: "LicensesAllocated"}],
  ibm_virt: [{type: mongoose.Schema.Types.ObjectId, ref: "IbmLpar"}],
  ovm_virt: [{type: mongoose.Schema.Types.ObjectId, ref: "Ovm"}],
  xen_virt: [{type: mongoose.Schema.Types.ObjectId, ref: "Xen"}],
  vmware_virt: [{type: mongoose.Schema.Types.ObjectId, ref: "VMachines"}],
  solaris_virt: [{type: mongoose.Schema.Types.ObjectId, ref: 'Solaris'}],
  kvm_virt: [{type: mongoose.Schema.Types.ObjectId, ref: "Kvm"}],
  hp_ux_virt: [{type: mongoose.Schema.Types.ObjectId, ref: "Hpux"}],
  other_virt: OtherVirt,
  aws_cloud:[CloudSchema],
  azure_cloud:[CloudSchema],
  oracle_cloud:[CloudSchema],
  di_cloud:[CloudSchema],
  other_cloud: OtherCloud
});

module.exports = mongoose.model('hardware', HardwareSchema);
