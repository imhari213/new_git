const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const virtualMachineSchema = mongoose.Schema({
  vm_host_name: String,
  virtual_server_name: String,
  vm_guest_host_name: String,
  vm_guest_os: String,
  vm_ip_address: String,
  is_stand_alone: Boolean,
  data_center: String,
  cluster: String,
  full_name: String,
  version: String,
  power_state: String,
  connection_state_datastores: String,
  managed_by_server: String,
  vcenter_server_name: String,
  vendor: String,
  esx_version: String,
  connection_state: String,
  datastores: String,
});

module.exports = mongoose.model('VMachines', virtualMachineSchema);
