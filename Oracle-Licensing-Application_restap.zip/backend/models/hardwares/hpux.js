const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ActProcCountSchema = new Schema({
  number_of_sockets: Number,
  cores_per_socket: Number,
  logical_processors: Number,
  lcpu_attribute: String,
})

const ComplexInfoSchema = new Schema({
  complex_name: String,
  complex_serial_number: String,
  complex_product_order_number: String,
  complex_id_number: String,
})

const CoreUsageDetsSchema = new Schema({
  total_core_usage_rights: String,
  committed_core_usage_rights: String,
  available_core_usage_rights: String,
  number_of_partitions_present: Number,
})

const NPartitionSummSchema = new Schema({
  npar_id: String,
  npar_name: String,
  npar_state: String,
  npar_has_vpars: Boolean,
  npar_intended_active: Boolean,
  npar_total_cores: Number,
  npar_actual_active: Number,
  npar_assigned_cores: Number,
})

const VPartitionSummSchema = new Schema({
  vpar_id: String,
  vpar_name: String,
  vpar_state: String,
  vpar_assigned_cores: Number,
  vpar_actual_active: Number,
  vpar_committed_rights: String,
})

const VirtualPartSummSchema = new Schema({
  capped: Boolean,
  cpu_min: Number,
  cpu_max: Number,
  licensable_cores: Number,
})

const SecureResourcepartitionSchema = new Schema({
  cpu_entitlements_fss: String,
  cpu_entitlements_pset: String,
  srp_name: String,
  prm_id: String,
  pset: String,
  licensables_cores: Number,
  notes: String,
})

const HPUXSchema = new Schema({
  virtual_server_name: String,
  // machine_information: MachineInfo;
  active_processor_count: ActProcCountSchema,
  complex_information: ComplexInfoSchema,
  core_usage_right_details: CoreUsageDetsSchema,
  npartition_resource_summary: NPartitionSummSchema,
  vpartition_resource_summary: VPartitionSummSchema,
  virtual_partition_resource_summary: VirtualPartSummSchema,
  secure_resource_partitions: SecureResourcepartitionSchema,
})



module.exports = mongoose.model('Hpux', HPUXSchema);
