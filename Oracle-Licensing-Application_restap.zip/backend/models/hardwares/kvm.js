const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const KvmSchema = new Schema({
  virtual_server_name: String,
  vcpus: String,
  cpu_affinity: String,
  total_cpus: String,
  pinned: Boolean,
})

module.exports = mongoose.model('Kvm', KvmSchema);
