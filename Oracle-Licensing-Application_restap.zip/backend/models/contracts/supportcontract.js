const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SupportContractSchema = new Schema({
  support_contract_number: Number,
  support_start_date: Date,
  support_end_date: Date,
  support_term: String,
  support_offer_expiration: Date,
  support_representive: String,
  support_service_number: Number,
  total_price: Number,
  currency: String,
  line_price: Number,
  support_filepaths: [String]
})

const SupportContract = mongoose.model('SupportContract', SupportContractSchema);

module.exports = SupportContract;
