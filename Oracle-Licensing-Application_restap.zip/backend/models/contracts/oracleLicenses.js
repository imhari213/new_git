const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const OracleLicenseSchema = new Schema({
    product_name: String,
    quantity: Number,
    metric: String,
    term: String,
    license_type: String,
    restrictions: String,
    license_notes: String,
    support_status: String,
    support_end_date: Date,
    unit_price: Number,
    total_cost: Number,
    discount: String,
    allowed: Number,
    allocated: Number,
    migrated_to:  {type: mongoose.Schema.Types.ObjectId, ref: 'Contract'},
    migrated_from:  {type: mongoose.Schema.Types.ObjectId, ref: 'Contract'},
    migration_date: Date
  })

const OracleLicense = mongoose.model('OracleLicense', OracleLicenseSchema);

module.exports = OracleLicense;
