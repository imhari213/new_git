const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const NonStandardTermsSchema = new Schema({
  term_name: String,
  term_description: String,
  term_filepaths: [String]
})

const NST = mongoose.model('NonStandardTerm', NonStandardTermsSchema);

module.exports = NST;
