const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const ContractSchema = new Schema({
    order_identifier: String,
    customer_support_identifier: String,
    contract_date: Date,
    contract_territory: String,
    non_standard_terms: [{type: mongoose.Schema.Types.ObjectId, ref: 'NonStandardTerm'}],
    contract_terminated: Boolean,
    total_capex_cost_of_contract: String,
    support_contract: [{type: mongoose.Schema.Types.ObjectId, ref: 'SupportContract'}],
    oracle_licenses: [{type: mongoose.Schema.Types.ObjectId, ref: 'OracleLicense'}],
    end_user:  {type: mongoose.Schema.Types.ObjectId, ref: "Comp"},
    end_user_accepted_subsidiaries: [{type: Schema.Types.ObjectId, ref: 'Comp'}],
    signed_by: String,
    signed_by_date: Date,
    contract_upload: String,
    contract_type: String,
    contract_imagepath: [String],
});

const Contract = mongoose.model('Contract', ContractSchema);

module.exports = Contract;
