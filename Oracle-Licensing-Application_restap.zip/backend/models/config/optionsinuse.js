const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const OptionsInUseSchema = new Schema({
  option: String
});

const OptionsInUse = mongoose.model('Optionsinuse', OptionsInUseSchema);

module.exports = OptionsInUse;
