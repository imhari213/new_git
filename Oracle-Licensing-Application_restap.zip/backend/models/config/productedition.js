const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const ProductEditionSchema = new Schema({
  edition: String
});

const ProductEdition = mongoose.model('ProductEdition', ProductEditionSchema);

module.exports = ProductEdition;
