const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const ManagementPackSchema = new Schema({
  pack: String
});

const ManagementPack = mongoose.model('ManagementPack', ManagementPackSchema);

module.exports = ManagementPack;
