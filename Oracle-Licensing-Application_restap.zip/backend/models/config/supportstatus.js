const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const SupportStatusSchema = new Schema({
  reference: Number,
  value: String
});

const SupportStatus = mongoose.model('SupportStatuses', SupportStatusSchema);

module.exports = SupportStatus;
