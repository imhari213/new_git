const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//Create Schema
const CurrencySchema = new Schema({
    country: String,
    currency: String,
    symbol: String,
});

const Currency = mongoose.model('Currencys', CurrencySchema);

module.exports = Currency;
