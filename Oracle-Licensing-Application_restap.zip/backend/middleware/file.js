const multer = require('multer');

const MIME_TYPE_MAP = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/gif': 'gif',
  'image/webp': 'webp',
  'application/pdf': 'pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/x-zip-compressed': 'zip',
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const isValid = MIME_TYPE_MAP[file.mimetype];
    let error = new Error('Invalid mime type' + file.mimetype);
    if (isValid) {
      error = null;
    }
    if (file.mimetype.startsWith('image/')){
      cb(error, 'backend/images');
    } else {
      cb(error, 'backend/files');
    }
  },
  filename: (req, file, cb) => {
    let isMatched = false;
    if (req.body.non_standard_terms) {
      req.body.non_standard_terms = JSON.parse(req.body.non_standard_terms);
    }
    if (req.body.contract_filenames_toupload) {
      req.body.contract_filenames_toupload = JSON.parse(req.body.contract_filenames_toupload);
    }
    if (req.body.support_contract) {
      req.body.support_contract = JSON.parse(req.body.support_contract);
    }

    while(isMatched != true){
      if (req.body.non_standard_terms && isMatched === false) {
        for (let i = 0; i < req.body.non_standard_terms.length; i++) {
          if (req.body.non_standard_terms[i].term_filenames_toupload !== 0 && req.body.non_standard_terms[i].term_filenames_toupload !== undefined && req.body.non_standard_terms[i].term_filenames_toupload !== ''  && req.body.non_standard_terms[i].term_filenames_toupload !== null && isMatched === false) {
            for( let j = 0; j < req.body.non_standard_terms[i].term_filenames_toupload.length; j++) {
              if (req.body.non_standard_terms[i].term_filenames_toupload[j] === file.originalname && isMatched === false) {
                const name = file.originalname.toLowerCase().split(' ').join('-');
                const ext = MIME_TYPE_MAP[file.mimetype];
                const newName = name + '-' + Date.now() + '.' + ext;
                req.body.non_standard_terms[i].term_filenames_toupload[j] = newName;
                cb(null, newName);
                isMatched = true;
              }
            }
          }
        }
      }
      if(req.body.support_contract && isMatched === false) {
        for (let k = 0; k < req.body.support_contract.length; k++) {
          if (req.body.support_contract[k].support_filenames_toupload !== 0 && req.body.support_contract[k].support_filenames_toupload !== undefined && req.body.support_contract[k].support_filenames_toupload !== '' && req.body.support_contract[k].support_filenames_toupload !== null && isMatched === false){
            for( let l = 0; l < req.body.support_contract[k].support_filenames_toupload.length; l++) {
              if (req.body.support_contract[k].support_filenames_toupload[l] === file.originalname && isMatched === false) {
                const name = file.originalname.toLowerCase().split(' ').join('-');
                const ext = MIME_TYPE_MAP[file.mimetype];
                const newName = name + '-' + Date.now() + '.' + ext;
                req.body.support_contract[k].support_filenames_toupload[l] = newName;
                cb(null, newName);
                isMatched = true;
              }
            }
          }
        }
      }
      if (req.body.contract_filenames_toupload && isMatched === false) {
        for (let x = 0; x < req.body.contract_filenames_toupload.length; x++) {
          if (req.body.contract_filenames_toupload[x] === file.originalname && isMatched === false){
            const name = file.originalname.toLowerCase().split(' ').join('-');
            const ext = MIME_TYPE_MAP[file.mimetype];
            const newName = name + '-' + Date.now() + '.' + ext;
            req.body.contract_filenames_toupload[x] = newName;
            cb(null, newName);
            isMatched = true;
          }
        }
      }
    }
    req.body.non_standard_terms = JSON.stringify(req.body.non_standard_terms);
    req.body.contract_filenames_toupload = JSON.stringify(req.body.contract_filenames_toupload);
    req.body.support_contract = JSON.stringify(req.body.support_contract);
    }
});

module.exports = multer({storage: storage}).array('image');
