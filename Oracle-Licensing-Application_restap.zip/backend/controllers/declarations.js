const AdditionalOracleProductsSchema = require('../models/declaration/declaration');
const AuditLog = require('../models/audit/auditlog');

exports.createDeclaration = (req, res, next) => {
    additionalOracleProductsSchema = new AdditionalOracleProductsSchema({
        'product': req.body.product,
        'license_metric': req.body.license_metric,
        'existing_license_level': req.body.existing_license_level,
        'customer_support_identifier': req.body.customer_support_identifier,
        'license_grant': req.body.license_grant,
        'declared_usage': req.body.declared_usage,
        'additional_comments': req.body.additional_comments,
        'company': req.body.company       
    });
    additionalOracleProductsSchema.save().then(result=> {
        if (result) {
            addAudit(result._id, result.product);
            res.status(201).json({
                message: "successfully added declaration!"
            });
        } else {
            res.status(400).json({
                message: "unsuccessfully added declaration!"
            });
        }
    });

    async function addAudit(decId, product) {
    
        const object = new AuditLog({
          userId: req.userData.userId,
          email: req.userData.email,
          datetime: new Date(),
          databaseChanged: "declaration",
          relatedId: decId,
          relatedString: product,
          action: "add"
        })
        try {
          object.save();
        } catch(error) {
          res.status(500).json({
            message: error.toString()
          });
        }
      }
}

exports.deleteDeclaration = (req,res, next) => {
    AdditionalOracleProductsSchema.findByIdAndDelete({"_id": req.params.declarationId}, {product:1}).then(result => {
        if (result) {
            addAudit(result._id, result.product);
            res.status(200).json({message: 'declaration deleted'});
        } else {
            res.status(400).json({
                message: "Couldnt delete"
            });
        }
    });

    async function addAudit(decId, product) {
    
        const object = new AuditLog({
          userId: req.userData.userId,
          email: req.userData.email,
          datetime: new Date(),
          databaseChanged: "declaration",
          relatedId: decId,
          relatedString: product,
          action: "delete"
        })
        try {
          object.save();
        } catch(error) {
          res.status(500).json({
            message: error.toString()
          });
        }
      }
}

exports.updateDeclaration = (req, res, next) => {
    AdditionalOracleProductsSchema.findByIdAndUpdate({"_id": req.params.declarationId}, req.body).then(result => {
        if (result) {
            addAudit(result._id, result.product);
            res.status(201).json({
                message: "Declaration has been updated"
            });
        } else {
            res.status(400).json({
                message: "Declaration has not been updated"
            });
        }
    });

    async function addAudit(decId, product) {
    
        const object = new AuditLog({
          userId: req.userData.userId,
          email: req.userData.email,
          datetime: new Date(),
          databaseChanged: "declaration",
          relatedId: decId,
          relatedString: product,
          action: "edit"
        })
        try {
          object.save();
        } catch(error) {
          res.status(500).json({
            message: error.toString()
          });
        }
      } 
}

exports.getDeclaration = (req, res, next) => {
    AdditionalOracleProductsSchema.findById({"_id": req.params.declarationId}).then(result => {
        if(result) {
            res.status(201).json({
                message: "declaration found!",
                declaration: result
            });
        } else {
            res.staus(400).json({
                message: "no declaration found!"
            });
        }
    })
}

exports.getDeclarations = (req, res, next) => {
    let declarationCount;
    let foundDeclarations;
    let searchParam = '';
    let sortBy = 0;

    const compId = req.query.company;
    const pageSize = +req.query.pagesize;
    const currentPage = +req.query.page;
    const sortType = req.query.sort;
    
    
    if (req.params.searchQuery !== 'undefined' && req.params.searchQuery !== 'null') {
         searchParam = req.params.searchQuery.toString(); 
    }
    
    main();
    async function main() {
        await sortDeclarations();
        await fetchDeclarations();

        await res.status(201).json({
            message: "declarations found!",
            declarations: foundDeclarations,
            declarationCount: declarationCount
        });
    }

    async function sortDeclarations() {
        if (sortType && sortType !== 'undefined') {
            switch(sortType) {
              case 'Ascending':
                sortBy = 1;
                break;
              case 'Descending':
                sortBy = -1;
                break;
            }
          }
    }

    async function fetchDeclarations() {
        if(compId === 'undefined') {
            declarationCount = await AdditionalOracleProductsSchema.find({
                $or: [
                    {'product': {$regex: searchParam, $options: 'i'}},
                    {'customer_support_identifier': {$regex: searchParam, $options: 'i'}}
                ]
            }).countDocuments();
            await AdditionalOracleProductsSchema.find({
                $or: [
                    {'product': {$regex: searchParam, $options: 'i'}},
                    {'customer_support_identifier': {$regex: searchParam, $options: 'i'}}
                ]
            }).skip(pageSize * (currentPage - 1)).limit(pageSize).sort({'customer_support_identifier': sortBy}).then(result => {
                if (result) {
                    foundDeclarations = result;
                } else {
                    res.status(400).json({
                        message: "no declarations found!"
                    });     
                }
            })
        } else {
            declarationCount = await AdditionalOracleProductsSchema.find({
                $and: [
                    {'company': compId},
                    {'company': {$in:req.userData.subsidiaries }},
                ]
            }).countDocuments();
            await AdditionalOracleProductsSchema.find({
                $and: [
                    {'company': compId},
                    {'company': {$in:req.userData.subsidiaries }},
                    {$or: [
                        {'product': {$regex: searchParam, $options: 'i'}},
                        {'customer_support_identifier': {$regex: searchParam, $options: 'i'}}
                    ]}
                ]               
            }).skip(pageSize * (currentPage - 1)).limit(pageSize).sort({'customer_support_identifier': sortBy}).then(result => {
                if(result) {
                    foundDeclarations = result;
                } else {
                    res.status(400).json({
                        message: "no declarations found!"
                    });                    
                }
            });
        }
    }

}