const Contract = require('../models/contracts/contract');
const Hardware = require('../models/hardwares/hardware');
const Oracle = require('../models/contracts/oracleLicenses');
const Support = require('../models/contracts/supportcontract');
const NST = require('../models/contracts/nonstandardterms');
const LicAllocated = require('../models/hardwares/licensesallocated');
const AuditLog = require('../models/audit/auditlog');

exports.createContract = (req, res, next) => {

  const contractObj = req.body;
  formatFiles();
  addContract();

  async function addContract() {
    const setorclids = await createLic();
    const setSupportIds = await createSupport();
    const setNsts = await createNST();

   

    const contract = new Contract({
      ...contractObj,
      order_identifier: contractObj.order_identifier,
      customer_support_identifier: contractObj.customer_support_identifier,
      non_standard_terms: setNsts,
      support_contract: setSupportIds,
      oracle_licenses: setorclids,
      contract_imagepath: contractObj.contract_filenames_toupload
    });

    contract.save().then(createdContract => {
      addAudit(createdContract._id, createdContract.customer_support_identifier);
      res.status(201).json({
        message: 'Contract added successfully',
        contract: {
          ...createdContract
        }
      });
    })
    .catch(error => {
      res.status(500).json({
        message: 'Creating a contract failed! ' + error
      });
  });
  }
  async function addAudit(contId, csi) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "contract",
      relatedId: contId,
      relatedString: csi,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }

  function formatFiles (){
    if (contractObj.oracle_licenses) {
      contractObj.oracle_licenses = JSON.parse(contractObj.oracle_licenses);
    }
    if (contractObj.non_standard_terms) {
      contractObj.non_standard_terms = JSON.parse(contractObj.non_standard_terms);
    }
    if (contractObj.support_contract) {
      contractObj.support_contract = JSON.parse(contractObj.support_contract);
    }
    if (contractObj.contract_filenames_toupload) {
      contractObj.contract_filenames_toupload = JSON.parse(contractObj.contract_filenames_toupload);
    }
    if (contractObj.end_user_accepted_subsidiaries) {
      contractObj.end_user_accepted_subsidiaries = JSON.parse(contractObj.end_user_accepted_subsidiaries);
    }

    if (req.files) {

      const url = req.protocol + '://' + req.get('host');
      for (let file of req.files) {
        if (contractObj.contract_filenames_toupload){
          for (let y = 0; y < contractObj.contract_filenames_toupload.length; y++){
            if (contractObj.contract_filenames_toupload[y] === file.filename ){
              if (file.mimetype.includes('image')) {
                contractObj.contract_filenames_toupload[y] =  url + '/images/' + file.filename;
              } else {
                contractObj.contract_filenames_toupload[y] =  url + '/files/' + file.filename;
              }
            }
          }
        }
        if (contractObj.non_standard_terms){
          for (let i = 0; i < contractObj.non_standard_terms.length; i++){
            if (contractObj.non_standard_terms[i].term_filenames_toupload){
              for (let j = 0; j < contractObj.non_standard_terms[i].term_filenames_toupload.length; j++){
                if (contractObj.non_standard_terms[i].term_filenames_toupload[j] === file.filename){
                  if (file.mimetype.includes('image')) {
                    contractObj.non_standard_terms[i].term_filenames_toupload[j]  =  url + '/images/' + file.filename;
                    contractObj.non_standard_terms[i].term_filepaths = contractObj.non_standard_terms[i].term_filenames_toupload;
                  } else {
                    contractObj.non_standard_terms[i].term_filenames_toupload[j]  =  url + '/files/' + file.filename;
                    contractObj.non_standard_terms[i].term_filepaths = contractObj.non_standard_terms[i].term_filenames_toupload;
                  }
                }
              }
            }
          }
        }
        if (contractObj.support_contract) {
          for (let k = 0; k < contractObj.support_contract.length; k++){
            if (contractObj.support_contract[k].support_filenames_toupload){
              for (let l = 0; l < contractObj.support_contract[k].support_filenames_toupload.length; l++){
                if (contractObj.support_contract[k].support_filenames_toupload[l] === file.filename){
                  if (file.mimetype.includes('image')) {
                    contractObj.support_contract[k].support_filenames_toupload[l]  =  url + '/images/' + file.filename;
                    contractObj.support_contract[k].support_filepaths = contractObj.support_contract[k].support_filenames_toupload;
                  } else {
                    contractObj.support_contract[k].support_filenames_toupload[l]  =  url + '/files/' + file.filename;
                    contractObj.support_contract[k].support_filepaths = contractObj.support_contract[k].support_filenames_toupload;
                  }
                }
              }
            }
          }

        }
      }
    }
  }

  async function createLic() {
    let licIds = [];

    for (let i = 0; i < contractObj.oracle_licenses.length; ++i) {
      const license = new Oracle({
        ...contractObj.oracle_licenses[i],
       //  _id: contractObj.oracle_licenses[i]._id,
        product_name: contractObj.oracle_licenses[i].product_name,
        allocated: 0,
        allowed: contractObj.oracle_licenses[i].quantity
      })

     await license.save().then(newLic => {
        licIds.push(newLic._id);
      }).catch(error => {
        res.status(500).json({
          message: 'Creating a license failed! ' + error
        });
    });
    }

    return licIds;
  }

  async function createSupport() {
    let supIds = [];

    for (let i = 0; i < contractObj.support_contract.length; ++i) {
      const support = new Support({
        ...contractObj.support_contract[i],
        support_term: contractObj.support_contract.support_term
      })

      await support.save().then(newsup => {
        supIds.push(newsup._id);
      }).catch(error => {
        res.status(500).json({
          message: 'Creating a support contract failed! ' + error
        });
    });
    }

    return supIds;
  }

  async function createNST() {
    let nstIds = [];

    for (let i = 0; i < contractObj.non_standard_terms.length; ++i) {
      const nst = new NST({
        ...contractObj.non_standard_terms[i],
        term_name: contractObj.non_standard_terms[i].term_name
      })

      await nst.save().then(newNst => {
        nstIds.push(newNst._id);
      }).catch(error => {
        res.status(500).json({
          message: 'Creating a non standard term failed! ' + error
        });
      })
    }
  }

}

exports.createLicense = (req, res, next) => {

  try {
    license = new Oracle({...req.body});
    license.save().then(newLic => {
      res.status(201).json({
        message: 'Created new license',
        license: newLic
      })
    })
  } catch(err) {
    res.status(500).json({
      message: 'Unable to create license'
    })
  }

}



exports.getValidContracts = (req, res, next) => {
  const compId = req.params.compId;
  const subs = req.userData.subsidiaries;

  const foundContracts = Contract.find({$and: [
                                        {end_user: compId},
                                        {contract_terminated: false},
                                        {end_user: { $in: subs }}
                                        ]
                                      }, {customer_support_identifier: 1}).populate('oracle_licenses').lean();

  foundContracts.then(result => {
    result.forEach(con => {
      if (!con.customer_support_identifier) { con.customer_support_identifier = ''; }
    })
    if (result) {
      res.status(201).json({
        message: "Contracts Found",
        contracts: result
      });
    } else {
      res.status(401).json({
        message: "No contracts Found"
      })
    }
  })

}

exports.updateContract = (req, res, next) => {

formatFiles();
update();


function formatFiles() {
  if (req.files) {

    if (req.body.oracle_licenses ) {
      req.body.oracle_licenses = JSON.parse(req.body.oracle_licenses);
    }
    if (req.body.non_standard_terms) {
      req.body.non_standard_terms = JSON.parse(req.body.non_standard_terms);
    }
    if (req.body.support_contract) {
      req.body.support_contract = JSON.parse(req.body.support_contract);
    }
    if (req.body.contract_filenames_toupload) {
      req.body.contract_filenames_toupload = JSON.parse(req.body.contract_filenames_toupload);
    }
    if (req.body.contract_imagepath) {
      req.body.contract_imagepath = JSON.parse(req.body.contract_imagepath);
    }
    if (req.body.end_user_accepted_subsidiaries) {
      req.body.end_user_accepted_subsidiaries = JSON.parse(req.body.end_user_accepted_subsidiaries);
    }

    const url = req.protocol + '://' + req.get('host');
    for (let file of req.files) {
      if (req.body.contract_filenames_toupload){
        for (let y = 0; y < req.body.contract_filenames_toupload.length; y++){
          if (req.body.contract_filenames_toupload[y] === file.filename ){
            if (req.body.contract_imagepath === null || req.body.contract_imagepath === undefined) {
              req.body.contract_imagepath = [];
            }
            if (file.mimetype.includes('image')) {
              req.body.contract_imagepath.push(url + '/images/' + file.filename);
            } else {
              req.body.contract_imagepath.push(url + '/files/' + file.filename);
            }
          }
        }
      }
      if (req.body.non_standard_terms){
        for (let i = 0; i < req.body.non_standard_terms.length; i++){
          if (req.body.non_standard_terms[i].term_filenames_toupload){
            for (let j = 0; j < req.body.non_standard_terms[i].term_filenames_toupload.length; j++){
              if (req.body.non_standard_terms[i].term_filenames_toupload[j] === file.filename){
                if (req.body.non_standard_terms[i].term_filepaths === null){
                  req.body.non_standard_terms[i].term_filepaths = [];
                }
                if (file.mimetype.includes('image')) {
                  req.body.non_standard_terms[i].term_filenames_toupload[j]  =  url + '/images/' + file.filename;
                  req.body.non_standard_terms[i].term_filepaths.push(req.body.non_standard_terms[i].term_filenames_toupload[j]);
                } else {
                  req.body.non_standard_terms[i].term_filenames_toupload[j]  =  url + '/files/' + file.filename;
                  req.body.non_standard_terms[i].term_filepaths.push(req.body.non_standard_terms[i].term_filenames_toupload[j]);
                }
              }
            }
          }
        }
      }
      if (req.body.support_contract) {
        for (let k = 0; k < req.body.support_contract.length; k++){
          if (req.body.support_contract[k].support_filenames_toupload){
            for (let l = 0; l < req.body.support_contract[k].support_filenames_toupload.length; l++){
              if (req.body.support_contract[k].support_filenames_toupload[l] === file.filename){
                if (req.body.support_contract[k].support_filepaths === null){
                  req.body.support_contract[k].support_filepaths = [];
                }
                if (file.mimetype.includes('image')) {
                  req.body.support_contract[k].support_filenames_toupload[l]  =  url + '/images/' + file.filename;
                  req.body.support_contract[k].support_filepaths.push(req.body.support_contract[k].support_filenames_toupload[l]);
                } else {
                  req.body.support_contract[k].support_filenames_toupload[l]  =  url + '/files/' + file.filename;
                  req.body.support_contract[k].support_filepaths.push(req.body.support_contract[k].support_filenames_toupload[l]);
                }
              }
            }
          }
        }

      }
    }
  }
}

async function compareToDelete(newContract) {
  const originalContract = await Contract.findById(req.params.id).lean();
  let originalLicenses = [];
  let originalSupport = [];
  let originalNst = [];

  if (originalContract.oracle_licenses) { originalLicenses = originalContract.oracle_licenses.filter(lic => !newContract.oracle_licenses.includes(lic)); }
  if (originalContract.support_contract) { originalSupport = originalContract.support_contract.filter(sup => !newContract.support_contract.includes(sup)); }
  if (originalContract.non_standard_terms) { originalNst = originalContract.non_standard_terms.filter(nst => !newContract.non_standard_terms.includes(nst)); }

  for (let i = 0; i < originalLicenses.length; ++i) { await Oracle.deleteOne({_id: originalLicenses[i]}); }
  for (let i = 0; i < originalSupport.length; ++i) { await Support.deleteOne({_id: originalSupport[i]}); }
  for (let i = 0; i < originalNst.length; ++i) { await NST.deleteOne({_id: originalNst._id}); }

}

async function update() {

  updatedContract = new Contract({
    ...req.body,
    _id: req.body._id,
    customer_support_identifier: req.body.customer_support_identifier,
    oracle_licenses: await createIdList(req.body.oracle_licenses, 'lic'),
    support_contract: await createIdList(req.body.support_contract, 'sup'),
    non_standard_terms: await createIdList(req.body.non_standard_terms, 'nst')
  })

  await compareToDelete(updatedContract);

  try {
    const updatedcontract = await  Contract.findByIdAndUpdate({_id: updatedContract._id}, updatedContract);
    addAudit(updatedcontract._id, updatedcontract.customer_support_identifier);
    const updated = await Contract.findById(updatedContract._id).lean().populate('oracle_licenses non_standard_terms support_contract');
    res.status(200).json({
      message: 'contract updated successfully',
      contract: updated
    });
  } catch(error) {
    res.status(500).json({
      message: 'contract failed to update'
    });
  }
}

async function addAudit(contId, csi) {

  const object = new AuditLog({
    userId: req.userData.userId,
    email: req.userData.email,
    datetime: new Date(),
    databaseChanged: "contract",
    relatedId: contId,
    relatedString: csi,
    action: "edit"
  })
  try {
    object.save();
  } catch(error) {
    res.status(500).json({
      message: error.toString()
    })
  }
}

async function calcLic(license) {
  const licAllocated = await LicAllocated.find({product_licensed: license._id.toString()}).lean();
  license.allocated = 0;
  for (let i = 0; i < licAllocated.length; ++i) {
    license.allocated += parseInt(licAllocated[i].number_of_licenses_in_use);
  }


  if (license.quantity > 0) {
    // ideally should be -1 but >0 to compensate for previous errors in calculations
  // if (license.quantity !== -1) {
    license.allowed = license.quantity - license.allocated;
  }

  await Oracle.updateOne({_id: license._id}, license);
}

async function createIdList(objectList, type) {
  const idList = [];
  if (objectList) {

    for(let i = 0; i < objectList.length; ++i) {
      const object = objectList[i];
      if (object._id) {
        idList.push(object._id);
        if (type === 'lic') { await calcLic(object); }
        if (type === 'sup') { await Support.updateOne({_id: object._id}, object); }
        if (type === 'nst') { await  NST.updateOne({_id: object._id}, object); }
      } else {
        if (type === 'lic') {
          lic = new Oracle({...object});
          if (!lic.quantity) { lic.quantity = 0 }
          lic.allowed = lic.quantity;
          lic.allocated = 0;
          newLic = await lic.save();
          await idList.push(newLic._id.toString());
        }
        if (type === 'sup') {
          sup = new Support({...object});
          newSup = await sup.save();
          idList.push(newSup._id);
        }
        if (type === 'nst') {
          nst = new NST({...object});
          newNst = await nst.save();
          idList.push(newNst._id);
        }
      }
    }

  }
  return idList;
}

}

exports.getContractById = (req, res, next ) => {
  const contractId = req.params.id;
  const contract = Contract.findById(contractId).lean().populate('oracle_licenses non_standard_terms support_contract');

  contract.then(con => {
    res.status(200).json({message: 'Contract found by id!', contract: con});
  }).catch(error => {
    res.status(500).json({message: "Unable to retreive contract!"});
  });

}

exports.deleteContract = (req, res, next) => {
  Contract.findByIdAndDelete({_id: req.params.id}, {customer_support_identifier:1}).then(result => {
    if (result) {
      addAudit(result._id, result.customer_support_identifier);
      res.status(200).json({message: 'Contract deleted!'});
    } else {
      res.status(401).json({message: 'no contract found!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting contract failed!"
    });
  });

  async function addAudit(contId, csi) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "contract",
      relatedId: contId,
      relatedString: csi,
      action: "delete"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.searchContracts = (req, res, next) => {

    const pageSize = +req.query.pagesize;
    const currentPage = +req.query.page;

    let searchParam = '';
    let foundContracts;
    let fetchedContracts;
    let company;
    let sortType;
    let pageType;
    let count;
    let compareContract;

    const hardwareCountList = [];

    if (req.params.searchQuery !== 'undefined' && req.params.searchQuery !== 'null') { searchParam = req.params.searchQuery.toString(); }
    if (req.query.company !== 'undefined' && req.query.company !== 'null') { company = req.query.company; }
    if (req.query.sort !== 'undefined' && req.query.sort !== 'null') { sortType = req.query.sort; }
    if (req.query.pagechosen !== 'null') { pageType = req.query.pagechosen; }


    try {
      MainMethod();
    } catch(error) {
      res.status(500).json({ message: 'Unable to retrieve contracts'});
    }

    async function MainMethod() {
      count = await getContracts().countDocuments();
      if (req.query.compareid !== 'null') {
        compareContract = await Contract.findById(req.query.compareid, {customer_support_identifier: 1, contract_date: 1});
      }

      foundContracts = getContracts();

      if (pageType === 'FIRST') {
        foundContracts.limit(pageSize);
        if (sortType && sortType !== 'undefined') {
          switch(sortType) {
            case 'Date added (oldest)':
              foundContracts
              .sort({contract_date: 1});
              break;
            case 'Date added (newest)':
              foundContracts
              .sort({contract_date: -1});
              break;
            case 'Ascending':
              foundContracts
              .sort({customer_support_identifier: 1});
              break;
            case 'Descending':
              foundContracts
              .sort({customer_support_identifier: -1});
              break;
          }
        }
      }

      if (pageType === 'NEXT') {
        foundContracts.limit(pageSize);
        if (sortType && sortType !== 'undefined') {
          switch(sortType) {
            case 'Date added (oldest)':
              foundContracts.sort({contract_date: 1});
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$gt: compareContract._id}}]}, {contract_date: {$gt: compareContract.contract_date}}]});
              break;
            case 'Date added (newest)':
              foundContracts.sort({contract_date: -1});
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$gt: compareContract._id}}]}, {contract_date: {$lt: compareContract.contract_date}}]});
              break;
            case 'Ascending':
              foundContracts.sort({customer_support_identifier: 1});
              foundContracts.find({customer_support_identifier: {$gt: compareContract.customer_support_identifier}});
              break;
            case 'Descending':
              foundContracts.sort({customer_support_identifier: -1});
              foundContracts.find({customer_support_identifier: {$lt: compareContract.customer_support_identifier}});
              break;
          }
        } else {
          foundContracts.find({_id: {$gt: req.query.compareid}});
        }

      }

      if (pageType === 'PREVIOUS') {
        foundContracts.limit(pageSize);
        if (sortType && sortType !== 'undefined') {
          switch(sortType) {
            case 'Date added (oldest)':
              foundContracts.sort({contract_date: -1});
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$lt: compareContract._id}}]}, {contract_date: {$lt: compareContract.contract_date}}]});
              break;
            case 'Date added (newest)':
              foundContracts.sort({contract_date: 1});
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$lt: compareContract._id}}]}, {contract_date: {$gt: compareContract.contract_date}}]});
              break;
            case 'Ascending':
              foundContracts.sort({customer_support_identifier: -1});
              foundContracts.find({customer_support_identifier: {$lt: compareContract.customer_support_identifier}});
              break;
            case 'Descending':
              foundContracts.sort({customer_support_identifier: 1});
              foundContracts.find({customer_support_identifier: {$gt: compareContract.customer_support_identifier}});
              break;
          }
        } else {
          foundContracts.sort({_id: -1});
          foundContracts.find({_id: {$lt: req.query.compareid}});
        }
      }

      if (pageType === 'LAST') {
        foundContracts.limit(count - (pageSize * (currentPage -1)));
        if (sortType && sortType !== 'undefined') {
          switch(sortType) {
            case 'Date added (oldest)':
              foundContracts
              .sort({contract_date: -1});
              break;
            case 'Date added (newest)':
              foundContracts
              .sort({contract_date: 1});
              break;
            case 'Ascending':
              foundContracts
              .sort({customer_support_identifier: -1});
              break;
            case 'Descending':
              foundContracts
              .sort({customer_support_identifier: 1});
              break;
          }
        } else {
          foundContracts.sort({_id: -1});
        }
      }

      foundContracts.populate({path: 'oracle_licenses', populate: {path: 'migrated_to migrated_from'}});
      foundContracts.populate('non_standard_terms support_contract');


      foundContracts.then(documents => {
        if (pageType === 'PREVIOUS' || pageType === 'LAST') {
          fetchedContracts = documents.reverse();
        } else {
          fetchedContracts = documents;
        }
        getAllInfo();

        async function getAllInfo() {

          await countHW(documents);
          res.status(200).json({
            message: 'contracts fetched successfully',
            contracts: fetchedContracts,
            maxContracts: count,
            hardwareCount: hardwareCountList
          });
        }
      })


    }

    async function countHW(documents) {
      for (document of documents) {
        licIds = await LicAllocated.find({contract_linked: document._id}).lean();
        hardwareIdList = await Hardware.find({license_allocated_to_server: {$elemMatch: { $in: licIds} }}, {_id: 1}).lean();
        hardwareCountList.push(hardwareIdList);
      }
    }



    function getContracts() {
      let contracts;

      if (company) {
        contracts = Contract.find({$and: [
                                          {end_user: company},
                                          {end_user: {$in:req.userData.subsidiaries }},
                                          {$or: [
                                            {order_identifier: {$regex: searchParam, $options: 'i'}},
                                            {customer_support_identifier: {$regex: searchParam, $options: 'i'}}
                                          ]}
                                        ]}).lean();
      } else {
        contracts = Contract.find({$and: [
                                          {end_user: {$in:req.userData.subsidiaries }},
                                          {$or: [
                                            {order_identifier: {$regex: searchParam, $options: 'i'}},
                                            {customer_support_identifier: {$regex: searchParam, $options: 'i'}}
                                          ]}
                                        ]}).lean();
      }

      return contracts;

    }


    /*


    async function MainMethod() {

      foundContracts = getContracts();

      console.log(pageSize * (currentPage -1));
      if (pageSize && currentPage) {
        foundContracts.limit(pageSize);
        if (req.query.pagechosen === 'PREVIOUS') {
          foundContracts.skip(pageSize * (currentPage - 1));
        }
        if (req.query.pagechosen === 'LAST') {
          foundContracts.skip(pageSize * (currentPage - 1));
        }
      }

      if (sortType && sortType !== 'undefined') {
        let compareContract;
        if (req.query.compareid !== 'null') {
          compareContract = await Contract.findById(req.query.compareid);
        }
        switch(sortType) {
          case 'Date added (oldest)':
            foundContracts.sort({contract_date: 1});
            if (compareContract && req.query.pagechosen === 'NEXT') {
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$gt: compareContract._id}}]}, {contract_date: {$gt: compareContract.contract_date}}]});
            }

            if (compareContract && req.query.pagechosen === 'PREVIOUS') {
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$lt: compareContract._id}}]}, {contract_date: {$lt: compareContract.contract_date}}]});
             }
            break;
          case 'Date added (newest)':
            foundContracts
            .sort({contract_date: -1});
            if (compareContract && req.query.pagechosen === 'NEXT') {
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$gt: compareContract._id}}]}, {contract_date: {$lt: compareContract.contract_date}}]});
              }
              if (compareContract && req.query.pagechosen === 'PREVIOUS') {
              foundContracts.find({$or: [{$and: [{contract_date: compareContract.contract_date}, {_id: {$lt: compareContract._id}}]}, {contract_date: {$gt: compareContract.contract_date}}]});
            }
            break;
          case 'Ascending':
            foundContracts
            .sort({customer_support_identifier: 1});
            if (compareContract && req.query.pagechosen === 'NEXT') {
              foundContracts.find({customer_support_identifier: {$gt: compareContract.customer_support_identifier}});
            }
            if (compareContract && req.query.pagechosen === 'PREVIOUS') {
              foundContracts.find({customer_support_identifier: {$lt: compareContract.customer_support_identifier}});
            }
            break;
          case 'Descending':
            foundContracts
            .sort({customer_support_identifier: -1});
            if (compareContract && req.query.pagechosen === 'NEXT') {
              foundContracts.find({customer_support_identifier: {$lt: compareContract.customer_support_identifier}});
            }
            if (compareContract && req.query.pagechosen === 'PREVIOUS') {
              foundContracts.find({customer_support_identifier: {$gt: compareContract.customer_support_identifier}});
            }
            break;
        }
      } else {
        if (req.query.pagechosen === 'NEXT'){
          foundContracts.find({_id: {$gt: req.query.compareid}});
        }
        if (req.query.pagechosen === 'PREVIOUS'){
          foundContracts.find({_id: {$lt: req.query.compareid}});
        }

      }



      foundContracts.then(documents => {
        getAllInfo();

        async function getAllInfo() {

          fetchedContracts = documents;

          const count = await getContracts().countDocuments();
          await countHW(documents);
          res.status(200).json({
            message: 'contracts fetched successfully',
            contracts: fetchedContracts,
            maxContracts: count,
            hardwareCount: hardwareCountList
          });
        }
      })

    }



    /*
    async function calcLic(documents) {

      for(let i = 0; i < documents.length; ++i) {
        for(let j = 0; j < documents[i].oracle_licenses.length; ++j) {
          const licAllList = await LicAllocated.find({product_licensed:  documents[i].oracle_licenses[j]._id.toString()}).lean();

          if (! documents[i].oracle_licenses[j].quantity) {  documents[i].oracle_licenses[j].quantity = 0; }
          documents[i].oracle_licenses[j].allocated =  0;
          documents[i].oracle_licenses[j].allowed =  documents[i].oracle_licenses[j].quantity;
          if (licAllList.length > 0) {
            licAllList.forEach(license => {
              if (documents[i].oracle_licenses[j].quantity !== -1) {
                documents[i].oracle_licenses[j].allowed -= parseInt(license.number_of_licenses_in_use);
              }
              documents[i].oracle_licenses[j].allocated += parseInt(license.number_of_licenses_in_use);
            });
          }
        }
      }
      return documents;
    }
    * /

    async function countHW(documents) {
      for (document of documents) {
        licIds = await LicAllocated.find({contract_linked: document._id}).lean();
        hardwareIdList = await Hardware.find({license_allocated_to_server: {$elemMatch: { $in: licIds} }}, {_id: 1}).lean();
        hardwareCountList.push(hardwareIdList);
      }
    }
    */
}


