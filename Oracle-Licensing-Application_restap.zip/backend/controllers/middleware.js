
const Middleware = require('../models/middleware/middleware');
const AuditLog = require('../models/audit/auditlog');

exports.createMiddleware = (req, res, next) => {
  const newMiddleware = new Middleware({ ...req.body });

  try {
    newMiddleware.save().then(createdMw => {
      // addAudit(createdMw._id, createdMw.product)
      res.status(201).json({
        message: 'Middleware added successfully',
        middleware: createdMw
      })
    })
  } catch(err) {
    res.status(500).json({
      message: 'Creating middleware failed!'
    })
  }

  async function addAudit(mwId, product) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "middleware",
      relatedId: mwId,
      // relatedString: product,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }

}

exports.getMiddlewareById = (req, res, next) => {
  // const middleware = Middleware.findById(req.params.id).lean().populate('primary_server_for_failover_dr_backup_testing company')
  const middleware = Middleware.findById(req.params.id).lean().populate('company')


  middleware.then(doc => {
    res.status(201).json({
      message: 'Middleware retreived successfully',
      middleware: doc
    })
  }).catch(error => {
    res.status(500).json({
      message: 'Unable to retreive middleware'
    })
  })

}

exports.searchMiddleware = (req, res, next) => {

  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  let foundMiddleware;
  let fetchedMiddleware;

  let company;
  let searchParam = '';
  let sortType;

  if (!(req.query.company === 'undefined' || req.query.company === 'null')) { company = req.query.company; }
  if (!(req.query.searchparam === 'undefined' || req.query.searchparam === 'null')) { searchParam = req.query.searchparam; }
  if (!(req.query.sort === 'undefined' || req.query.sort === 'null')) { sortType = req.query.sort; }

  try {
    MainMethod();
  } catch(err) {
    res.status(500).json({message: 'Unable to retreive middleware'});
  }

  async function MainMethod() {
    foundMiddleware = getMiddleware();

    /*
    if (sortType) {
      switch(sortType) {
        case 'Alphabetically':
          foundMiddleware
          .sort({product: 1});
          break;
        case 'Non Alphabetically':
          foundMiddleware
          .sort({product: -1});
          break;
      }

    }
    */

    if (pageSize && currentPage) {
      foundMiddleware
      .skip(pageSize * (currentPage - 1))
      .limit(pageSize);
    }

    // foundMiddleware.populate({path: 'primary_server_for_failover_dr_backup_testing', populate: {path: 'ibm_virt ovm_virt xen_virt vmware_virt solaris_virt kvm_virt other_virt'}});
    foundMiddleware.populate('company physical_server');
    foundMiddleware.populate({path: 'virtual_server_for_failover_dr_backup_testing', populate: {path: 'ibm_virt ovm_virt xen_virt vmware_virt solaris_virt kvm_virt other_virt hp_ux_virt'}});

    foundMiddleware.then(documents => {
      fetchedMiddleware = documents;
      response();

      async function response() {
        res.status(200).json({
          message: 'middleware fetched successfully',
          middlewares: fetchedMiddleware,
          maxMiddlewares: await getMiddleware().countDocuments()
        })
      }
    })

  }

  function getMiddleware() {
    let middleware;
    if (company) {
      middleware = Middleware.find({$and: [
                                          {company: company},
                                          {company: {$in: req.userData.subsidiaries}},
                                          // {product: {$regex: searchParam, $options: 'i'}}
                                          ]}).lean();
    } else {
      middleware = Middleware.find({$and: [
                                           {company: {$in: req.userData.subsidiaries}},
                                          // {product: {$regex: searchParam, $options: 'i'}}
                                          ]}).lean();
    }

    return middleware;
  }

}

exports.updateMiddleware = (req, res, next) => {

  const updatedMiddleware = new Middleware({
    ...req.body,
    _id: req.body._id,
    // primary_server_for_failover_dr_backup_testing: req.body.primary_server_for_failover_dr_backup_testing._id
  });

  Middleware.findByIdAndUpdate({_id: updatedMiddleware._id}, updatedMiddleware).then(result => {
    if (result) {
      // addAudit(result._id, result.product);
      res.status(200).json({
        message: 'Middleware updated successfully',
        middleware: updatedMiddleware
      });
    } else {
      res.status(401).json({message: 'Not authorized'});
    }
  }).catch( error => {
    res.status(500).json({
      message: 'Unable to update middleware'
    })
  });

  async function addAudit(mwId, product) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "middleware",
      relatedId: mwId,
     // relatedString: product,
      action: "edit"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.deleteMiddleware = (req, res, next) => {
  Middleware.findByIdAndDelete({_id: req.params.id}).then(result => {
    if (result) {
      // addAudit(result._id, result.product)
      res.status(200).json({message: 'middleware deleted'});
    } else {
      res.status(401).json({message: 'not authorized'})
    }
  }).catch(error => {
    res.status(500).json({
      message: 'deleting middleware failed'
    });
  });

  async function addAudit(mwId, product) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "middleware",
      relatedId: mwId,
      // relatedString: product,
      action: "delete"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}
