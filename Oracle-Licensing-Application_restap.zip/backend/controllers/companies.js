const Company = require('../models/company');
const VCenter = require('../models/vcenters/vmware');
const AuditLog = require('../models/audit/auditlog');
const jwt = require('jsonwebtoken');

exports.createCompany = (req, res, next) => {

  createSchema();

  function createSchema () {

    const company = new Company({
      company_name: req.body.company.company_name,
      hq_location: req.body.company.hq_location,
      end_user_contacts: req.body.company.end_user_contacts,
      end_user_comments: req.body.company.end_user_comments,
      end_user_subsidiaries: req.body.company.end_user_subsidiaries,
      oma_reference_number: req.body.company.oma_reference_number,
      vad_name: req.body.company.vad_name,
      vad_contact: req.body.company.vad_contact
    });
    company.save().then(createdCompany => {
      addAudit(createdCompany._id, createdCompany.company_name);
      updateSubs();
    })
    .catch(error => {
      console.log(error);
      res.status(500).json({
        message: 'Creating a company failed!'
      });
    });
  }

   function updateSubs() {

      userData = req.userData;
      let findCompany;
      let subsidiaries = [];

      if(req.body.refreshToken) {
        calcSubs();
      } else {
        res.status(404).send('Invalid request');
      }

      async function calcSubs() {
        if (userData.role === 'master') {
          Company.find().then(comps => {
            comps.forEach(sub => subsidiaries.push(sub._id));
            sendResponse();
          });
        } else {
          if (userData.company) {
            subsidiaries.push(userData.company);
            count = 0;
            (async () => {
              while (count < subsidiaries.length) {
                findCompany = await Company.findOne({_id: subsidiaries[count]}).lean();
                if (findCompany !== null) {
                  findCompany.end_user_subsidiaries.forEach(sub => {
                    if (!subsidiaries.includes(String(sub))) {
                      subsidiaries.push(String(sub));
                    }
                  });
                }
              count += 1;
              }
              sendResponse();
            })();
          } else {
            sendResponse();
          }
        }
      }

      async function sendResponse() {
        res.status(201).json({
          token: await getToken(),
          expiresIn: 300,
          message: 'Company added successfully'
        });
      }

      function getToken() {
        return jwt.verify(req.body.refreshToken, process.env.JWT_REFRESH_KEY, (err, user) => {
          return (err ? res.status(403).send('Validification failed for request') : jwt.sign(
            {email: userData.email, userId: userData.userId, role: userData.role, subsidiaries: subsidiaries, name: userData.name},
            process.env.JWT_KEY,
            {expiresIn: '300s' }
          ));
        })
      }
  }


  async function addAudit(compId, compName) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "company",
      relatedId: compId,
      relatedString: compName,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.updateCompany = (req, res, next) => {

  const company = new Company({
    _id: req.body._id,
    company_name: req.body.company_name,
    hq_location: req.body.hq_location,
    end_user_contacts: req.body.end_user_contacts,
    end_user_comments: req.body.end_user_comments,
    oma_reference_number: req.body.oma_reference_number,
    end_user_subsidiaries: req.body.end_user_subsidiaries,
    vad_name: req.body.vad_name,
    vad_contact: req.body.vad_contact
  });
  Company.findByIdAndUpdate({_id: req.params.id}, company).then(result => {
    if (result) {
      addAudit(result._id, result.company_name);
      res.status(200).json({message: 'Update successful!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  })
  .catch(error => {
    res.status(500).json({
      message: "Couldn't update company! " + error
    })
  });
  async function addAudit(compId, compName) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "company",
      relatedId: compId,
      relatedString: compName,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.getSubNameList = (req, res, next) => {

  try {
    const company = Company.findById(req.params.compId).lean().populate('end_user_subsidiaries');

    company.then(comp => {
      subNameList = [];
      comp.end_user_subsidiaries.forEach(sub => {
        subNameList.push(sub.company_name);
      });
      res.status(201).json({ subNameList: subNameList })
    });
  } catch (error) {
    res.status(500).json({
      message: "Couldn't get subsidiaries"
    })
  }

}

exports.getAllCompanies = (req, res, next) => {

  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  let findCompanies;
  let fetchedCompanies;
  let count;
  let matchList = [];

  try {
    findCompanies = getCompanies();
    if (pageSize && currentPage) {
      findCompanies
      .skip(pageSize * (currentPage - 1))
      .limit(pageSize);
    }
    findCompanies.then(documents => {
      getInfo();
      async function getInfo() {
        fetchedCompanies = documents;
        count = await getCompanies().countDocuments();
        await checkVCenters();
        res.status(200).json({
          message: 'companies fetched successfully',
          companies: fetchedCompanies,
          maxCompanies: count,
          matched: matchList
      });
      }
    })

  } catch(error) {
    res.status(500).json({
      message: "Fetching companies failed!" + error.toString()
    });
  }

  function getCompanies() {
    let foundCompanies;
    if (req.userData.role === 'master') {
      foundCompanies = Company.find().lean().sort({'company_name':1});
    } else {
      foundCompanies = Company.find(({_id: { $in : req.userData.subsidiaries}})).lean().sort({'company_name':1});
    }
    return foundCompanies;
  }

  async function checkVCenters() {
    for(let i = 0; i < fetchedCompanies.length; ++i) {
      const vc = await VCenter.findOne({company: fetchedCompanies[i]._id}).lean();
      if (vc) { matchList.push(true); } else { matchList.push(false); }
    }
  }


}


exports.getCompanyByName = (req, res, next ) => {

  getCompany();

  async function getCompany() {
    const company = await Company.findOne({$and: [{company_name: req.params.companyName}, {_id: {$in: req.userData.subsidiaries}}]}).lean();
    if (company) {
      setVcenter(company);
    } else {
      res.status(404).json({message: 'Company not found!'});
    }
  }

  async function setVcenter(company) {
    let vcenterBool = false;
    const vcenters = await VCenter.find({company: company._id});
    if (vcenters.length > 0) { vcenterBool = true }
    res.status(200).json({
      company: company,
      message: 'Company found!',
      vcenter: vcenterBool
    });

  }
}


exports.getCompanyById = (req, res, next ) => {

  getCompany();

  async function getCompany() {
    const company =  await Company.findOne({$and: [{_id: req.params.id}, {_id: {$in: req.userData.subsidiaries}}]}).lean();
    // .populate('end_user_subsidiaries');
    if (company) {
      res.status(200).json(company);
    } else {
      res.status(404).json({message: 'company not found!'});
    }
  }

}

exports.deleteCompany = (req, res, next) => {
  Company.findByIdAndDelete({_id: req.params.id}, {company_name: 1}).then(result =>{
      if (result) {
        addAudit(result._id, result.company_name);
        res.status(200).json({message: 'Company deleted!'});
      } else {
        res.status(401).json({message: 'No company found!'});
      }
    }).catch(error => {
      res.status(500).json({
        message: "Deleting companies failed!"
      });
    });

  async function addAudit(compId, compName) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "company",
      relatedId: compId,
      relatedString: compName,
      action: "delete"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.searchCompany = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  const searchParam = req.params.searchQuery;
  const compareCompany = req.params.compareCompanyId;

  let findCompanies;
  let fetchedCompanies;
  let count;
  let matchList = [];
  let pageType;

  if (req.query.pagechosen !== 'null') { pageType = req.query.pagechosen; }

  try {
    findCompanies = getCompanies();
    if (pageType === 'FIRST') {
      foundCompanies.limit(pageSize);
    }
    if (pageType === 'NEXT') {
      foundCompanies.limit(pageSize);
      foundCompanies.find({_id: {$gt: compareCompany}});
    }

    if (pageType === 'PREVIOUS') {
      foundCompanies.limit(pageSize);
      foundCompanies.find({_id: {$lt: compareCompany}});
    }
    if (pageType === 'LAST') {
      foundCompanies.limit(count - (pageSize * (currentPage -1)));
    }

    findCompanies.then(documents => {
      getInfo();
      async function getInfo() {
        fetchedCompanies = documents;
        count = await getCompanies().countDocuments();
        await checkVCenters();
        res.status(200).json({
          message: 'companies fetched successfully',
          companies: fetchedCompanies,
          maxCompanies: count,
          matched: matchList
      });
      }
    })

  } catch(error) {
    res.status(500).json({
      message: "Fetching companies failed!" + error.toString()
    });
  }

  function getCompanies() {
    let foundCompanies;
    if (req.userData.role === 'master') {
      foundCompanies = Company.find( {company_name: { $regex: searchParam, $options: 'i'}}).lean().sort({'company_name':1});
    } else {
      foundCompanies = Company.find(({$and: [
                                        {company_name: { $regex: searchParam, $options: 'i'}},
                                        {_id: {$in: req.userData.subsidiaries}}
                                      ]})).lean().sort({'company_name':1});
    }
    return foundCompanies;
  }

  async function checkVCenters() {
    for(let i = 0; i < fetchedCompanies.length; ++i) {
      const vc = await VCenter.findOne({company: fetchedCompanies[i]._id}).lean();
      if (vc) { matchList.push(true); } else { matchList.push(false); }
    }
  }

}
