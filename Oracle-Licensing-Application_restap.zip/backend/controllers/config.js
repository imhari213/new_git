const Currency = require('../models/config/currency');
const EnviromentalUsage = require('../models/config/enviromentalusage');
const ManagementPack = require('../models/config/managementpack');
const OptionsInUse = require('../models/config/optionsinuse');
const ProductEdition = require('../models/config/productedition');
const SupportStatus = require('../models/config/supportstatus');

exports.getAllCurrencies = (req, res, next) => {
  let findCurrency;

  findCurrency = Currency.find().sort({'country':1});

  findCurrency.then(documents => {
    fetchedCurrency = documents;
    return Currency.countDocuments();
  })
  .then(countDocuments => {
    res.status(200).json({
      message: 'Currency fetched successfully!',
      currency: fetchedCurrency,
      maxCurrency: countDocuments
    });
  }).catch(error => {
    res.status(500).json({
      message: "Fetching Currency failed! Error: " + error
    });
  });
}

exports.createCurrency = (req, res, next) => {

  const currency = new Currency({
    country: req.body.country,
    currency: req.body.currency,
    symbol: req.body.symbol
  });
  currency.save().then(createdCurrency => {
    res.status(201).json({
      message: 'Currency added successfully',
      currency: {
        ...createdCurrency,
        id: createdCurrency._id
      }
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a Currency failed!'
    });
  });
}

exports.deleteCurrency = (req, res, next) => {
  Currency.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'Currency deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting a currency failed!"
    });
  });
}

exports.getAllSupportStatus = (req, res, next) => {
  let findSupportStatus;

  findSupportStatus = SupportStatus.find().sort({'reference':1});

  findSupportStatus.then(documents => {
    fetchedSupportStatus = documents;
    return SupportStatus.countDocuments();
  })
  .then(countDocuments => {
    res.status(200).json({
      message: 'Support Status fetched successfully!',
      supportStatus: fetchedSupportStatus,
      maxSupportStaus: countDocuments
    });
  }).catch(error => {
    res.status(500).json({
      message: "Fetching Support Status failed! Error: " + error
    });
  });
}

exports.createSupportStatus = (req, res, next) => {

  const supportStatus = new SupportStatus({
    reference: req.body.reference,
    value: req.body.value,
  });
  supportStatus.save().then(createdStatus => {
    res.status(201).json({
      message: 'Support Status added successfully',
      supportStatus: {
        ...createdStatus,
        id: createdStatus._id
      }
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a Support Status failed!'
    });
  });
}

exports.deleteSupportStatus = (req, res, next) => {
  SupportStatus.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'Support Status deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting a Support Status failed!"
    });
  });
}

exports.getAllEnviromentalUsage = (req, res, next) => {
  let findEnviromentalUsage;

  findEnviromentalUsage = EnviromentalUsage.find().sort({'type':1});

  findEnviromentalUsage.then(documents => {
    fetchedEnviromentalUsage = documents;
    return EnviromentalUsage.countDocuments();
  })
  .then(countDocuments => {
    res.status(200).json({
      message: 'Enviromental Usage fetched successfully!',
      enviromentalUsages: fetchedEnviromentalUsage,
      maxEnviromentalUsages: countDocuments
    });
  }).catch(error => {
    res.status(500).json({
      message: "Fetching Enviromental Usage failed! Error: " + error
    });
  });
}

exports.createEnviromentalUsage = (req, res, next) => {

  const enviromentalUsage = new EnviromentalUsage({
    type: req.body.type,
  });
  enviromentalUsage.save().then(createdEnviromentalUsage => {
    res.status(201).json({
      message: 'Enviromental Usage added successfully',
      enviromentalUsage: {
        ...createdEnviromentalUsage,
        id: createdEnviromentalUsage._id
      }
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a Enviromental Usage failed!'
    });
  });
}

exports.deleteEnviromentalUsage = (req, res, next) => {
  EnviromentalUsage.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'Enviromental Usage deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting a Enviromental Usage failed!"
    });
  });
}

exports.getAllProductEdition = (req, res, next) => {
  let findProductEdition;

  findProductEdition = ProductEdition.find().sort({'edition':1});

  findProductEdition.then(documents => {
    fetchedEditions = documents;
    return ProductEdition.countDocuments();
  })
  .then(countDocuments => {
    res.status(200).json({
      message: 'Product Editions fetched successfully!',
      productEditions: fetchedEditions,
      maxProductEditons: countDocuments
    });
  }).catch(error => {
    res.status(500).json({
      message: "Fetching Product Editions failed! Error: " + error
    });
  });
}

exports.createProductEdition = (req, res, next) => {
  const productEdition = new ProductEdition({
    edition: req.body.edition,
  });
  productEdition.save().then(createdProductEdition => {
    res.status(201).json({
      message: 'Product Edition added successfully',
      productEdition: {
        ...createdProductEdition,
        id: createdProductEdition._id
      }
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a Product Edition failed!'
    });
  });
}

exports.deleteProductEdition = (req, res, next) => {
  ProductEdition.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'Product Edition deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting a Product Edition failed!"
    });
  });
}

exports.getAllOptionsInUse = (req, res, next) => {
  let findOptionsInUse;

  findOptionsInUse = OptionsInUse.find().sort({'option':1});

  findOptionsInUse.then(documents => {
    fetchedOptions = documents;
    return OptionsInUse.countDocuments();
  })
  .then(countDocuments => {
    res.status(200).json({
      message: 'Options fetched successfully!',
      optionsInUse: fetchedOptions,
      maxOptions: countDocuments
    });
  }).catch(error => {
    res.status(500).json({
      message: "Fetching options failed! Error: " + error
    });
  });
}

exports.createOptionInUse = (req, res, next) => {

  const optionInUse = new OptionsInUse({
    option: req.body.option,
  });
  optionInUse.save().then(createdOptionInUse => {
    res.status(201).json({
      message: 'Product Edition added successfully',
      optionInUse: {
        ...createdOptionInUse,
        id: createdOptionInUse._id
      }
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a Option In Use failed!'
    });
  });
}

exports.deleteOptionInUse = (req, res, next) => {
  OptionsInUse.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'Option In Use deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting an Option In Use failed!"
    });
  });
}

exports.getAllManagementPacks = (req, res, next) => {
  let findManagementPacks;

  findManagementPacks = ManagementPack.find().sort({'pack':1});

  findManagementPacks.then(documents => {
    fetchedPacks = documents;
    return ManagementPack.countDocuments();
  })
  .then(countDocuments => {
    res.status(200).json({
      message: 'Packs fetched successfully!',
      managementPacks: fetchedPacks,
      maxPacks: countDocuments
    });
  }).catch(error => {
    res.status(500).json({
      message: "Fetching packs failed! Error: " + error
    });
  });
}

exports.createManagementPack = (req, res, next) => {

  const managementPack = new ManagementPack({
    pack: req.body.pack,
  });
  managementPack.save().then(createdManagementPack => {
    res.status(201).json({
      message: 'Management Pack added successfully',
      managementPack: {
        ...createdManagementPack,
        id: createdManagementPack._id
      }
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a Management Pack failed!'
    });
  });
}

exports.deleteManagementPack = (req, res, next) => {
  ManagementPack.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'Management Pack deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Deleting a Management Pack failed!"
    });
  });
}

