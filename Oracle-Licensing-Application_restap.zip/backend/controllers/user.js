const bcrypt = require ('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const Company = require('../models/company');
const nodemailer = require("nodemailer");
const UserLog = require('../models/audit/userlog');
//const fs = require('fs');
const AWS = require('aws-sdk');
const Notification = require ('../models/notifications');

exports.test = (req, res, next) => {

  console.log("in");
  res.send({"test":"message"});
}

exports.getNotifications = (req, res, next) => {
  Notification.find({"made_for": req.params.userEmail, "marked_resolved": false}).then(result => {
    if (result) {
      res.status(201).json({
        message: "notifications found!",
        notifications: result
      });
    } else {
      res.status(400).json({
        message: "no notifications Found"
      });
    }
  });
}

exports.sendUserRequest = (req, res, next) => {

  const notification = new Notification ({
    "made_by" : req.body.userEmail,
    "made_for": req.body.contact,
    "time_requested": new Date(),
    "content": req.body.message,
    "severity": req.body.severity,
    "marked_resolved": false,
    "company": req.body.company,
    "type_of_request": req.body.typeOfRequest,
    "migrate_db": req.body.migrateDb
  });
  notification.save();

  let transporter = nodemailer.createTransport({
    SES: new AWS.SES({
      apiVersion: '2010-12-01',
      region: 'eu-west-1',
      accessKeyId: process.env.AWS_SES_ACCESS_KEY,
      secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY
  })
  });
  const subjectText = 'SEVERITY: ' + req.body.severity + '... Request to change database.';
  let mailOptions = {
    from: req.body.userEmail,
    to: req.body.contact,
    subject: subjectText,
    text: req.body.message
  }
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      res.status(401).json({
        message: error
      });
    } else {
      console.log('Email sent: ' + info.response);
      res.status(201).json({
        message: "request sent"
      });
    }
  });
}

exports.emailCheck = (req, res, next) => {
  let emailList = [];
  main();

  async function main() {
    await getEmailList();
    try {
      res.status(201).json({
        messsage: "returning email check list",
        email: emailList
      });
    } catch(err){
      res.status(500).json({
        messsage: `A problem occurred! Error: ${err}`
      });
    }

  }

  async function getEmailList (){
    for (element of req.body) {
      try {
        let email = await User.find({email: element.end_user_email});
        emailList.push(email[0].email);
      } catch(err) {
        emailList.push('');
      }
    }
  }
}

exports.savingNewPassword = (req,res,next) => {
  /*
  console.log(req.body.token)
  token = req.body.token
  var publicKey = "-----BEGIN PUBLIC KEY-----\n" + process.env.EMAIL_PUBLIC_KEY + "\n-----END PUBLIC KEY-----"
  jwt.verify(token, publicKey, function(err, verifiedToken){
    console.log(verifiedToken);
    verifiedToken.checkToken = "not ok"
  });*/
  bcrypt.hash(req.body.confirm_password, 10)
  .then(hash => {
    User.updateOne({email: req.body.email}, {$set: {password: hash}}).then(result => {
      if(result.n > 0) {
        res.status(200).json({
          message: 'User Has Been Updated.'
        });
      } else {
        res.status(401).json({
          message: 'Unable to Update.'
        })
      }
    }).catch(error => {
      res.status(500).json({
        message: 'Email Is already in use'
      });
    });
  });
}

exports.passwordReset = (req, res, next) => {
  token = req.body.token;
  let email;
  let emailId;
  // let publicKey = fs.readFileSync("C:/Users/dsteyn/Documents/GitHub/Oracle-Licensing-Application/backend/controllers/public.txt", 'utf8');
  let publicKey = "-----BEGIN PUBLIC KEY-----\n" + process.env.EMAIL_PUBLIC_KEY + "\n-----END PUBLIC KEY-----"
  jwt.verify(token, publicKey, function(err, verifiedToken){
    if (err) {
      res.status(201).json({message: err.message, status: false});
    } else {
      email = verifiedToken.email;
      res.status(201).json({email: email, emailId: emailId, status: true});
    }
  });

  async function getUser() {
    User.find({email: email}).then(result => {
      emailId = result._id;
      res.status(201).json({email: email, emailId: emailId, status: true});
    });
  }
}

exports.sendEmail = (req, res, next) => {
  let payload = {email: req.body.email, checkToken: 'Ok'};
  // let privateKey = fs.readFileSync("C:/Users/scmilne/Documents/private.txt", 'utf8');
  let privateKey = "-----BEGIN PRIVATE KEY-----\n" + process.env.EMAIL_PRIVATE_KEY + "\n-----END PRIVATE KEY-----"
  jwt.sign(payload, privateKey, {algorithm: 'RS256', expiresIn:'900s'}, function(err, token){
    let transporter = nodemailer.createTransport({
      SES: new AWS.SES({
        apiVersion: '2010-12-01',
        region: 'eu-west-1',
        accessKeyId: process.env.AWS_SES_ACCESS_KEY,
        secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY
    })
    });
    
    let mailOptions = {
      from:  'scmilne@dataintensity.com', //'' pbuckley@dataintensity.com,
      to: req.body.email,
      subject:'O.L.A password reset',
      html:
        '<h2>Password reset link</h2> <br>' +
        '<a href="http://localhost:4200/auth/passwordReset/' + token +'">Reset Link</a>' +
        '<br> <h3>If you havent requested this, then please ignore</h3>'
    }
  User.findOne({"email": req.body.email}).then(result => {
    if(result) {
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    } else {
      console.log("email doesnt exist");
    }
  })

  });
  res.status(201).json({});
}

exports.createUser = (req, res, next) => {
  bcrypt.hash(req.body.password, 10)
    .then(hash => {
      const user = new User({
        email: req.body.email,
        password: hash,
        role: req.body.role,
        company: req.body.company,
        darkmode: req.body.darkmode,
      });
      user.save()
        .then(result => {
          res.status(201).json({
            message: 'User created!',
            result: result
          });
        })
        .catch(err => {
          res.status(500).json({
              message: "Invalid authentication credentials!"
          });
        });
    });
}

exports.userLogin = (req, res, next) => {

  let findCompany;
  let subsidiaries = [];

  let fetchedUser;
  User.findOne({ email: req.body.email}).lean()  // does email used to login match one in db
    .then(user => {
      if (!user) {  // does user exist in db
        return res.status(401).json({
          message: 'Authentication failed, User not found!'
        });
      }
      fetchedUser = user;
      return bcrypt.compare(req.body.password, user.password); // get password hash entered and password hash in db and compare
    })
    .then(result => {
      if (!result) {
        return res.status(401).json({
          message: 'Authentication failed, Password not valid!'
        });
      } // create web token with user details and secret for encryption

      if (fetchedUser.role === 'master') {
        Company.find().then(comps => {
          comps.forEach(sub => subsidiaries.push(sub._id));
          createToken();
        });

      } else {
        if (fetchedUser.company) {
          subsidiaries.push(fetchedUser.company);
          count = 0;
          (async () => {
            while (count < subsidiaries.length) {
              findCompany = await Company.findOne({_id: subsidiaries[count]}).lean();
              if (findCompany !== null) {
                findCompany.end_user_subsidiaries.forEach(sub => {
                  if (!subsidiaries.includes(String(sub))) {
                    subsidiaries.push(String(sub));
                  }
                });
            }
            count += 1;
          }

          createToken();
        })();
      } else {
          createToken();
        }
      }
      async function loginAudit(email, userId) {
        const log = new UserLog({
          userId: userId,
          email: email,
          datetime: new Date()
        })

        try {
          log.save();
        } catch(error) {
          res.status(500).json({
            message: error.toString()
          })
        }

      }

        async function createToken() {

          let companyName;
          loginAudit(fetchedUser.email, fetchedUser._id)
          if (fetchedUser.company) {
            userCompany = await Company.findOne({_id: String(fetchedUser.company)});
            companyName = userCompany.company_name;

          }

        const token = jwt.sign(
          {email: fetchedUser.email, userId: fetchedUser._id, role: fetchedUser.role, company: fetchedUser.company, subsidiaries: subsidiaries, name: companyName},
           process.env.JWT_KEY,
          { expiresIn: '300s' }
        );

        const refreshToken = jwt.sign(
          {email: fetchedUser.email, userId: fetchedUser._id, role: fetchedUser.role, company: fetchedUser.company, subsidiaries: subsidiaries, name: companyName},
           process.env.JWT_REFRESH_KEY,
          { expiresIn: '1d' }
        );

        res.status(200).json({
          token: token,
          refreshToken: refreshToken,
          expiresIn: 300, // 5 minutes
          refreshExpiresIn: 86400, // a day 86400
          userId: fetchedUser._id, //
          role: fetchedUser.role, //
          company: fetchedUser.company, //
          subsidiaries: subsidiaries, //
          name: companyName, //
          message: 'Authentication Valid'
        })
      }

      })
      .catch(err => {
        return res.status(401).json({
          message: 'Authentication failed, invalid credentials!'
        });
      });
}

exports.refreshToken = (req,res,next) => {
  userData = req.userData;
  let findCompany;
  let subsidiaries = [];


  if(req.body.refreshToken) {
    calcSubs();
  } else {
    res.status(404).send('Invalid request');
  }

  async function calcSubs() {
    if (userData.role === 'master') {
      Company.find().then(comps => {
        comps.forEach(sub => subsidiaries.push(sub._id));
        response();
      });

    } else {
      if (userData.company) {
        subsidiaries.push(userData.company);
        count = 0;
        (async () => {
          while (count < subsidiaries.length) {
            findCompany = await Company.findOne({_id: subsidiaries[count]}).lean();
            if (findCompany !== null) {
              findCompany.end_user_subsidiaries.forEach(sub => {
                if (!subsidiaries.includes(String(sub))) {
                  subsidiaries.push(String(sub));
                }
              });
            }
          count += 1;
          }
          response();
        })();
      } else {
        //subsidiaries = userData.subsidiaries;
        response();
      }
    }
  }

  async function response() {
    res.status(200).json({
      token: await getToken(),
      expiresIn: 300,
      message: 'Authentication Valid'
    });
  }

  function getToken() {
    return jwt.verify(req.body.refreshToken, process.env.JWT_REFRESH_KEY, (err, user) => {
      return (err ? res.status(403).send('Validification failed for request') : jwt.sign(
        {email: userData.email, userId: userData.userId, role: userData.role, subsidiaries: subsidiaries, name: userData.name},
        process.env.JWT_KEY,
        {expiresIn: '300s' }
      ));
    })
  }

}

exports.getAllUsers = (req, res, next) => {

  mainMethod();

  async function mainMethod() {

    let users;

    try {
      if (req.userData.role === 'master'){
        users = await User.find();
      } else {
        users = await User.find({company: {$in: req.userData.subsidiaries}});
      }
      res.status(200).json({
        users:  users,
        message: 'Users Found'
      });
    }
    catch(err) {
      res.status(500).json({
        message: "no Users Found"
      });
    }
  }
}

exports.getUsersEmails = (req,res,next) => {
  User.findOne({email: req.params.email}).then((data) => {
    if (data) {
      res.status(200).json({
        users: data.email,
        message: 'Users Found'
      });
    } else {
      res.status(200).json({
        message: "no Users Found"
      });
    }
  });
}

exports.getUsersByCompany = (req,res,next) => {
  User.find({company: {$in: req.params.id}}).then(data => {
    if (data) {
      res.status(200).json({
        users: data,
        message: 'Users Found'
      })
    } else {
      res.status(200).json({
        message: 'Users Not Found'
      })
    }
  });
}

exports.updateUserMaster = (req, res, next) => {
  const user = req.body.user;

  mainMethod();

  async function mainMethod() {
    if (req.body.newpassword === true) { await hashPassword(); }
    User.updateOne({_id: user._id}, user).then(result => {
      if(result.n > 0) {
        res.status(200).json({
          message: 'User Has Been Updated.'
        });
      } else {
        res.status(401).json({
          message: 'Unable to Update.'
        })
      }
    }).catch(error => {
      res.status(500).json({
        message: error.toString()
      });
    });

    async function hashPassword() {
      user.password = await bcrypt.hash(req.body.user.password, 10);
    }
  }


}

exports.updateUserProfilePassword = (req,res,next) => {

  let currentPassword;

  User.findById({_id: req.body._id}).then(user => {
    if (!user) {  // does user exist in db
      return res.status(401).json({
        message: 'Authentication failed, User not found!'
      });
    }
    return bcrypt.compare(req.body.current_password, user.password);
  }).then(match => {
    if (match) {

      if (req.body.new_password) {

        bcrypt.hash(req.body.new_password, 10)
        .then(hashedPassword => {
          currentPassword = hashedPassword;
          sendData(currentPassword);
        });
      } else {
        currentPassword = req.body.current_password;
        sendData(currentPassword);
      }
    } else {
      return res.status(401).json({
        message: 'Authentication failed, Password not correct!'
      });
    }
  });


  function sendData(password) {

    const user = { email: req.body.new_email,
                  password: password
    }

    User.updateOne({_id: req.body._id}, user).then(result => {
      if(result.n > 0) {
        res.status(200).json({
          message: 'User Has Been Updated.',
          user: user
        });
      } else {
        res.status(401).json({
          message: 'Unable to Update User'
        })
      }
    }).catch(error => {
      res.status(500).json({
        message: 'Error occured while attempting to update user'
      });
    });
  }

}

exports.updateUserTheme = (req, res, next) => {

  const user = { darkmode: req.body.darkmode}

  User.updateOne({_id: req.params.id}, user).then(result => {
    if(result.n > 0) {
      res.status(200).json({
        message: 'User Theme Has Been Updated.',
        user: user
      });
    } else {
      res.status(401).json({
        message: 'Unable to Update User Theme'
      })
    }
  }).catch(error => {
    res.status(500).json({
      message: 'Error occured while attempting to update User Theme'
    });
  });
}

exports.getUserTheme = (req, res, next) => {
  User.findOne({_id: req.params.id}).then((data) => {
    if (data) {
      res.status(200).json({
        darkmode: data.darkmode,
        message: 'User Theme Found'
      });
    } else {
      res.status(200).json({
        message: "no User Theme Found"
      });
    }
  });
}

exports.updateUserHeaderOption = (req, res, next) => {

  const user = { headers: req.body.headers}

  User.updateOne({_id: req.params.id}, user).then(result => {
    if(result.n > 0) {
      res.status(200).json({
        message: 'User Header Option has been Updated.',
        user: user
      });
    } else {
      res.status(401).json({
        message: 'Unable to Update Header Option'
      })
    }
  }).catch(error => {
    res.status(500).json({
      message: 'Error occured while attempting to update User Header Option'
    });
  });
}

exports.getUserHeaderOption = (req, res, next) => {
  User.findOne({_id: req.params.id}).then((data) => {
    if (data) {
      res.status(200).json({
        headers: data.headers,
        message: 'User Header Option Found'
      });
    } else {
      res.status(200).json({
        message: "No User Header Option Found"
      });
    }
  });
}

exports.deleteUser = (req, res, next) => {
  User.deleteOne({_id: req.params.id}).then(result => {
    if (result.n > 0) {
      res.status(200).json({message: 'User deleted!'});
    } else {
      res.status(401).json({message: 'Not authorized!'});
    }
  }).catch(error => {
    res.status(500).json({
      message: "Fetching users failed!"
    });
  });

}
