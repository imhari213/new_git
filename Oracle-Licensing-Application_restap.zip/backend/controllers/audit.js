const UserLog = require('../models/audit/userlog');
const AuditLog = require('../models/audit/auditlog');

exports.addAudit = (req, res, next) => {

  const object = new AuditLog({
    userId: req.body.userId,
    email: req.userData.email,
    datetime: new Date(),
    databaseChanged: req.body.databaseChanged,
    relatedId:  req.body.relatedId,
    relatedString: req.body.relatedString,
    action: req.body.action,
    subDatabase: req.body.subDatabase,
    subId: req.body.subId,
    subRelatedString: req.body.subRelatedString
  })
  try {
    object.save().then(() => {
      res.status(200).json({
        message: 'successful'
      })
    })
  } catch(error) {
    res.status(500).json({
      message: error.toString()
    })
  }


}

exports.login = (req, res, next) => {
  const log = new UserLog({
    userId: req.body.userId,
    email: req.body.email,
    datetime: new Date()
  })

  try {
    log.save().then(() => {
      res.status(200).json({
        message: 'session logged'
      })
    })
  } catch(error) {
    res.status(500).json({
      message: error.toString()
    })
  }


}
