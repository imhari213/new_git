const Company = require('../models/company');
const VCenter = require('../models/vcenters/vmware');
const AuditLog = require('../models/audit/auditlog');
const jwt = require('jsonwebtoken');


const Database = require('../models/databases/database');
const Hardware = require('../models/hardwares/hardware');
const Notification = require('../models/notifications');



exports.createCompany = (req, res, next) => {

    const company = new Company({
      company_name: req.body.company.company_name,
      hq_location: req.body.company.hq_location,
      end_user_contacts: req.body.company.end_user_contacts,
      end_user_comments: req.body.company.end_user_comments,
      end_user_subsidiaries: req.body.company.end_user_subsidiaries,
      oma_reference_number: req.body.company.oma_reference_number,
      vad_name: req.body.company.vad_name,
      vad_contact: req.body.company.vad_contact
    });
    company.save().then(createdCompany => {
       res.status(201).json({"message":"company created successfully"});
    })
    .catch(error => {
      console.log(error);
      res.status(500).json({
        message: 'Creating a company failed!'
      });
    });
  //}

//    function updateSubs() {

//       userData = req.userData;
//       let findCompany;
//       let subsidiaries = [];

      
//     calcSubs();
      

//       async function calcSubs() {
//         if (userData.role === 'master') {
//           Company.find().then(comps => {
//             comps.forEach(sub => subsidiaries.push(sub._id));
//             sendResponse();
//           });
//         } else {
//           if (userData.company) {
//             subsidiaries.push(userData.company);
//             count = 0;
//             (async () => {
//               while (count < subsidiaries.length) {
//                 findCompany = await Company.findOne({_id: subsidiaries[count]}).lean();
//                 if (findCompany !== null) {
//                   findCompany.end_user_subsidiaries.forEach(sub => {
//                     if (!subsidiaries.includes(String(sub))) {
//                       subsidiaries.push(String(sub));
//                     }
//                   });
//                 }
//               count += 1;
//               }
//               sendResponse();
//             })();
//           } else {
//             sendResponse();
//           }
//         }
//       }


    //   async function sendResponse() {
    //     res.status(201).json({
    //       token: await getToken(),
    //       expiresIn: 300,
    //       message: 'Company added successfully'
    //     });
    //   }



    //   function getToken() {
    //     return jwt.verify(req.body.refreshToken, process.env.JWT_REFRESH_KEY, (err, user) => {
    //       return (err ? res.status(403).send('Validification failed for request') : jwt.sign(
    //         {email: userData.email, userId: userData.userId, role: userData.role, subsidiaries: subsidiaries, name: userData.name},
    //         process.env.JWT_KEY,
    //         {expiresIn: '300s' }
    //       ));
    //     })
    //   }
//   }


 
}


exports.createDatabase = (req, res, next) => {
  // database = new Database({
  //   database_instance_name: req.body.database_instance_name,
  //   physical_server_name: req.body.physical_server_name,
  //   virtual_server_name: req.body.virtual_server_name,
  //   pluggable_databases: req.body.pluggable_databases,
  //   environment_usage: req.body.environment_usage,
  //   options_in_use: req.body.options_in_use,
  //   managements_in_use: req.body.managements_in_use,
  //   rac_nodes: req.body.rac_nodes,
  //   fal_server: req.body.fal_server,
  //   fal_client: req.body.fal_client,
  //   cpu_count: req.body.cpu_count,
  //   cpu_count_default: req.body.cpu_count_default,
  //   installation_date: req.body.installation_date,
  //   users_defined: req.body.users_defined,
  //   product_edition: req.body.product_edition,
  //   product_version: req.body.product_version,
  //   control_management_pack_access: req.body.control_management_pack_access,
  //   current_sessions: req.body.current_sessions,
  //   highwater_sessions: req.body.highwater_sessions,
  //   database_cloned_from: req.body.database_cloned_from,
  //   database_cloned_date: req.body.database_cloned_date,
  //   license_allocated_to_server: req.body.license_allocated_to_server,
  //   application_name: req.body.application_name,
  //   application_vendor: req.body.application_vendor,
  //   application_type: req.body.application_type,
  //   architecture_type: req.body.architecture_type,
  //   user_type: req.body.user_type,
  //   web_or_app_tier_server_name: req.body.web_or_app_tier_server_name,
  //   ebs_release: req.body.ebs_release,
  //   end_user: req.body.end_user,
  //   virtualisation_tech: req.body.virtualisation_tech
  // });
  // database.save().then(createdDb => {
  //   addAudit(createdDb._id, createdDb.database_instance_name);
  //   res.status(201).json({
  //     message: 'added successfully',
  //     database: createdDb
  //   });
  // })
  // .catch(error => {
  //   console.log(error);
  //   res.status(500).json({
  //     message: 'Creating a database failed!'
  //   });
  // });

  // async function addAudit(dbId, database_instance_name) {

  //   const object = new AuditLog({
  //     userId: req.userData.userId,
  //     email: req.userData.email,
  //     datetime: new Date(),
  //     databaseChanged: "database",
  //     relatedId: dbId,
  //     relatedString: database_instance_name,
  //     action: "add"
  //   })
  //   try {
  //     object.save();
  //   } catch(error) {
  //     res.status(500).json({
  //       message: error.toString()
  //     })
  //   }
  // }


  Database.insertMany(req.body).then(createdDb => {
     // addAudit(createdDb._id, createdDb.database_instance_name);
      res.status(201).json({
        message: 'added successfully',
        database: createdDb
      });
    })
    .catch(error => {
      console.log(error);
      res.status(500).json({
        message: 'Creating a database failed!'
      });
    });

}




exports.createContract = (req, res, next) => {

  const contractObj = req.body;
  formatFiles();
  addContract();

  async function addContract() {
    const setorclids = await createLic();
    const setSupportIds = await createSupport();
    const setNsts = await createNST();

    const contract = new Contract({
      ...contractObj,
      order_identifier: contractObj.order_identifier,
      customer_support_identifier: contractObj.customer_support_identifier,
      non_standard_terms: setNsts,
      support_contract: setSupportIds,
      oracle_licenses: setorclids,
    });

    contract.save().then(createdContract => {
      addAudit(createdContract._id, createdContract.customer_support_identifier);
      res.status(201).json({
        message: 'Contract added successfully',
        contract: {
          ...createdContract
        }
      });
    })
    .catch(error => {
      res.status(500).json({
        message: 'Creating a contract failed! ' + error
      });
  });
  }
  async function addAudit(contId, csi) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "contract",
      relatedId: contId,
      relatedString: csi,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }

  function formatFiles (){
    if (contractObj.oracle_licenses) {
      contractObj.oracle_licenses = JSON.parse(contractObj.oracle_licenses);
    }
    if (contractObj.non_standard_terms) {
      contractObj.non_standard_terms = JSON.parse(contractObj.non_standard_terms);
    }
    if (contractObj.support_contract) {
      contractObj.support_contract = JSON.parse(contractObj.support_contract);
    }
    if (contractObj.contract_filenames_toupload) {
      contractObj.contract_filenames_toupload = JSON.parse(contractObj.contract_filenames_toupload);
    }
    if (contractObj.end_user_accepted_subsidiaries) {
      contractObj.end_user_accepted_subsidiaries = JSON.parse(contractObj.end_user_accepted_subsidiaries);
    }

    if (req.files) {
      const url = req.protocol + '://' + req.get('host');
      for (let file of req.files) {
        if (contractObj.contract_filenames_toupload){
          for (let y = 0; y < contractObj.contract_filenames_toupload.length; y++){
            if (contractObj.contract_filenames_toupload[y] === file.filename ){
              if (file.mimetype.includes('image')) {
                contractObj.contract_filenames_toupload[y] =  url + '/images/' + file.filename;
              } else {
                contractObj.contract_filenames_toupload[y] =  url + '/files/' + file.filename;
              }
            }
          }
        }
        if (contractObj.non_standard_terms){
          for (let i = 0; i < contractObj.non_standard_terms.length; i++){
            if (contractObj.non_standard_terms[i].term_filenames_toupload){
              for (let j = 0; j < contractObj.non_standard_terms[i].term_filenames_toupload.length; j++){
                if (contractObj.non_standard_terms[i].term_filenames_toupload[j] === file.filename){
                  if (file.mimetype.includes('image')) {
                    contractObj.non_standard_terms[i].term_filenames_toupload[j]  =  url + '/images/' + file.filename;
                    contractObj.non_standard_terms[i].term_filepaths = contractObj.non_standard_terms[i].term_filenames_toupload;
                  } else {
                    contractObj.non_standard_terms[i].term_filenames_toupload[j]  =  url + '/files/' + file.filename;
                    contractObj.non_standard_terms[i].term_filepaths = contractObj.non_standard_terms[i].term_filenames_toupload;
                  }
                }
              }
            }
          }
        }
        if (contractObj.support_contract) {
          for (let k = 0; k < contractObj.support_contract.length; k++){
            if (contractObj.support_contract[k].support_filenames_toupload){
              for (let l = 0; l < contractObj.support_contract[k].support_filenames_toupload.length; l++){
                if (contractObj.support_contract[k].support_filenames_toupload[l] === file.filename){
                  if (file.mimetype.includes('image')) {
                    contractObj.support_contract[k].support_filenames_toupload[l]  =  url + '/images/' + file.filename;
                    contractObj.support_contract[k].support_filepaths = contractObj.support_contract[k].support_filenames_toupload;
                  } else {
                    contractObj.support_contract[k].support_filenames_toupload[l]  =  url + '/files/' + file.filename;
                    contractObj.support_contract[k].support_filepaths = contractObj.support_contract[k].support_filenames_toupload;
                  }
                }
              }
            }
          }

        }
      }
    }
  }

  async function createLic() {
    let licIds = [];

    for (let i = 0; i < contractObj.oracle_licenses.length; ++i) {
      const license = new Oracle({
        ...contractObj.oracle_licenses[i],
       //  _id: contractObj.oracle_licenses[i]._id,
        product_name: contractObj.oracle_licenses[i].product_name,
        allocated: 0, 
        allowed: contractObj.oracle_licenses[i].quantity
      })

     await license.save().then(newLic => {
        licIds.push(newLic._id);
      }).catch(error => {
        res.status(500).json({
          message: 'Creating a license failed! ' + error
        });
    });
    }

    return licIds;
  }

  async function createSupport() {
    let supIds = [];

    for (let i = 0; i < contractObj.support_contract.length; ++i) {
      const support = new Support({
        ...contractObj.support_contract[i],
        support_term: contractObj.support_contract.support_term
      })

      await support.save().then(newsup => {
        supIds.push(newsup._id);
      }).catch(error => {
        res.status(500).json({
          message: 'Creating a support contract failed! ' + error
        });
    });
    }

    return supIds;
  }

  async function createNST() {
    let nstIds = [];

    for (let i = 0; i < contractObj.non_standard_terms.length; ++i) {
      const nst = new NST({
        ...contractObj.non_standard_terms[i],
        term_name: contractObj.non_standard_terms[i].term_name
      })

      await nst.save().then(newNst => {
        nstIds.push(newNst._id);
      }).catch(error => {
        res.status(500).json({
          message: 'Creating a non standard term failed! ' + error
        });
      })
    }
  }

}