const VCenter = require('../models/vcenters/vmware');
const DataCenter = require('../models/vcenters/datacenter');
const Cluster = require('../models/vcenters/cluster');

exports.createVCenter = (req, res, next) => {

  let vcenter;
  VCCreate();

  async function VCCreate() {
    vcenter = new VCenter({
      company: req.body.company,
      vcenter_server_name: req.body.vcenter_server_name,
      vcenter_version: req.body.vcenter_version,
      dataCenters: await DCCreate()
    });

    SaveVCenter();
  }

  async function DCCreate() {

    idList = [];
    dcList = req.body.dataCenters;
    await GenerateDC();

    async function GenerateDC() {
      for(let i = 0; i < dcList.length; i++) {
        dcItem = dcList[i];
        dc = new DataCenter({
          data_center: dcItem.data_center,
          clusters: await ClusterCreate(dcItem.clusters)
        })
        saved = await dc.save();
        idList.push(saved._id);

      }
    }
    return idList;
  }


    async function ClusterCreate(clusters) {
      clusterIds = [];
      if (clusters) {
         await SaveCluster();
      }
      return clusterIds

      async function SaveCluster() {
        for(let i = 0; i < clusters.length; i++) {
          clusterItem = clusters[i];
          cluster = new Cluster({
            cluster: clusterItem.cluster
          })
          saved = await cluster.save();
          clusterIds.push(saved._id);
        }
      }
    }




  function SaveVCenter() {
    vcenter.save().then(createdVC => {
      res.status(201).json({
        message: 'Added VCenter',
        vCenter: createdVC
      });
    })
    .catch(error => {
      res.status(500).json({
        message: error.toString()
      });
    });
  }


}

exports.searchVCenters = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  let findVcenters;
  let fetchedVCenters;
  let company;
  let searchParam = '';

  if (!(req.query.company === 'undefined' || req.query.company === 'null')) { company = req.query.company; }
  if (!(req.params.searchParam === 'undefined' || req.params.searchParam === 'company' )) { searchParam = req.params.searchParam; }

  main();

  async function main() {

    try {
      if (company) {
        findVcenters = await VCenter.find({$and: [
                                            {company: company},
                                            {company: {$in: req.userData.subsidiaries}},
                                            {vcenter_server_name: {$regex: searchParam, $options: 'i'}}
                                           ]}).lean().populate({path: 'dataCenters', populate: {path: 'clusters'}})
      } else {
        findVcenters = await VCenter.find({$and: [
                                            {company: {$in: req.userData.subsidiaries}},
                                            {vcenter_server_name: {$regex: searchParam, $options: 'i'}}
                                          ]}).lean().populate({path: 'dataCenters', populate: {path: 'clusters'}})
      }

      if (pageSize && currentPage) {
        let start = (pageSize * (currentPage - 1));
        fetchedVCenters = findVcenters.slice(start, start + pageSize);
      } else {
        fetchedVCenters = findVcenters;
      }

      res.status(200).json({
        message: 'Successfully fetched VCenters',
        vcenters: fetchedVCenters,
        maxVCenters: findVcenters.length
      })
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }

  }



}

exports.getVCenters = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  const searchType = req.params.searchType;
  const searchParam = req.params.id;

  let allvcenters;
  let vcenters;
  let company;

  MainMethod();

  async function MainMethod() {
    if (searchType === 'company' && searchParam !== 'undefined' && searchParam !== 'null') { company = searchParam; }

    let authorizedVC;
    if (req.userData.role === 'master') {
      authorizedVC = await VCenter.find();
    } else {
      authorizedVC = await VCenter.find({company: { $in : req.userData.subsidiaries}});
    }

    if (company) {
      allvcenters = authorizedVC.filter(vc => vc.company.toString() === company);
    } else {
      allvcenters = authorizedVC;
    }

    if (pageSize && currentPage) {
      const start = pageSize * (currentPage -1);
      vcenters = allvcenters.slice(start, start + pageSize);
    } else {
      vcenters = allvcenters;
    }


    for(let i = 0; i < vcenters.length; ++i) {
      const dcObjArray = [];
      if (vcenters[i].dataCenters) {
        for (let j = 0; j < vcenters[i].dataCenters.length; ++j) {
          const dcObject = await DataCenter.findById(vcenters[i].dataCenters[j]);
          if (dcObject) {
            const clusterObjArray = [];
            if (dcObject.clusters) {
              for (let k = 0; k < dcObject.clusters.length; ++k) {
                const clusterObj = await Cluster.findById(dcObject.clusters[k]);
                if (clusterObj) {
                  clusterObjArray.push(clusterObj);
                }
              }
            }
            dcObject.clusters = clusterObjArray;

          }
          dcObjArray.push(dcObject);

        }
        vcenters[i].dataCenters = dcObjArray;
      }

    }

    if (vcenters) {
      res.status(200).json({
        message: 'Successfully fetched VCenters',
        vcenters: vcenters,
        maxVCenters: allvcenters.length
      })
    } else {
      res.status(200).json({
        message: 'VCenters Not Found'
      })
    }


  }
}

exports.getVCenter = (req, res, next) => {

  const vcid = req.params.id;
  let vcenter;

  MainMethod();

  async function MainMethod() {

    await getVCenter();
    await getDataCenters();

    res.status(200).json({
      message: 'successfully fetched VCenter',
      vcenter: vcenter
    })


    async function getVCenter(){
      vcenter = await VCenter.findOne({$and: [{_id: vcid}, {company: {$in: req.userData.subsidiaries}}]});
    }
    async function getDataCenters() {
      if (vcenter.dataCenters) {
        const dcObjectList = [];
        for (let i = 0; i < vcenter.dataCenters.length; ++i) {
          const dcObj = await DataCenter.findById(vcenter.dataCenters[i]);
          if (dcObj) {
            const clusterObjList = [];
            if (dcObj.clusters) {
              for (let j = 0; j < dcObj.clusters.length; ++j) {
                const clusterObj = await Cluster.findById(dcObj.clusters[j]);
                if (clusterObj) {
                  clusterObjList.push(clusterObj);
                }
              }
              dcObj.clusters = clusterObjList;
            }
            dcObjectList.push(dcObj);
          }
        }
        vcenter.dataCenters = dcObjectList;
      }


/*
      if (vcenter.dataCenters) {
        for(let i = 0; i < vcenter.dataCenters.length; ++i) {
          vcenter.dataCenters[i] = await DataCenter.findById(vcenter.dataCenters[i]);
          for(let j = 0; j < vcenter.dataCenters[i].clusters.length; ++j) {
            const clusterObj = await Cluster.findById(vcenter.dataCenters[i].clusters[j]);
            if (clusterObj) {
              vcenter.dataCenters[i].clusters[j] = clusterObj;
            }
          }
        }
      }
*/
    }

  }

}

exports.deleteCluster = (req, res, next) => {

  const clusterId = req.params.id;

  MainMethod();

  async function MainMethod() {

    await Cluster.deleteOne({_id: clusterId});

    res.status(200).json({
      message: 'successfully deleted cluster'
    });
  }


}

exports.deleteVCenter = (req, res, next) => {

  const vcId = req.params.id;
  MainMethod();

  async function MainMethod() {

    const vcenter = await VCenter.findById(vcId);
    for(let i = 0; i < vcenter.dataCenters.length; ++i) {
      const data_center = await DataCenter.findById(vcenter.dataCenters[i]);
      for (j = 0; j < data_center.clusters.length; ++j) {
        await Cluster.deleteOne({_id: data_center.clusters[j]});
      }
      await DataCenter.deleteOne({_id: vcenter.dataCenters[i]});
    }
    await VCenter.deleteOne({_id: req.params.id});
    res.status(200).json({
      message: 'successfully deleted VCenter'
    });
  }

}

exports.updateVCenter = (req, res, next) => {
  vcenter = req.body;

  MainMethod();

  async function MainMethod() {
    updatedVC = new VCenter({
      ...vcenter,
      _id: vcenter._id,
      company: vcenter.company,
      dataCenters: await DataCenterList(vcenter.dataCenters)
    });

    await VCenter.updateOne({_id: updatedVC._id}, updatedVC);

    res.status(200).json({
      message: 'successfully saved VCenter',
      vcenter:  updatedVC
    })

    async function DataCenterList(data_centers) {
      dcList = [];
      for(let i = 0; i < data_centers.length; ++i) {
        updatedDC =  new DataCenter({
          ...data_centers[i],
          _id: data_centers[i]._id,
          clusters: await ClusterList(data_centers[i].clusters)
        })

        if (data_centers[i]._id) {
          await DataCenter.updateOne({_id: updatedDC._id}, updatedDC);
          dcList.push(updatedDC._id);
        } else {
          saved = await updatedDC.save();
          dcList.push(saved._id);
        }


        async function ClusterList(clusters) {
          clusterList = [];
          if (clusters) {
            for(let i = 0; i < clusters.length; ++i) {
              updatedCl = new Cluster({
                ...clusters[i],
                _id: clusters[i]._id,
                cluster: clusters[i].cluster
              })

              if (clusters[i]._id) {
                await Cluster.updateOne({_id: updatedCl._id}, updatedCl);
                clusterList.push(updatedCl._id);
              } else {
                saved = await updatedCl.save();
                clusterList.push(saved._id);
              }
            }
          }

          return clusterList;
        }
      }
      return dcList
    }


  }
}
