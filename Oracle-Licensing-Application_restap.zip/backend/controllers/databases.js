const Database = require('../models/databases/database');
const Hardware = require('../models/hardwares/hardware');
const Company = require('../models/company');
const Notification = require('../models/notifications');
const AuditLog = require('../models/audit/auditlog');

exports.migrateDb = (req, res, next) => {
  Database.updateOne({_id: req.body.db_id}, {$set: {physical_server_name: req.body.hw_id}}).then(result => {
    Notification.updateOne({_id: req.body.request_id}, {$set: {marked_resolved: true}}).then(notiResult => {
      res.status(201).json({
        message: "updated request"
      });
    });
  });
}

exports.deleteDatabase = (req, res, next) => {
  Database.findByIdAndDelete({_id: req.params.id}, {database_instance_name:1}).then(result => {
    if (result) {
      addAudit(result._id, result.database_instance_name);
      res.status(200).json({message: 'db deleted'});
    } else {
      res.status(401).json({message: 'No db found'})
    }
  }).catch(error => {
    res.status(500).json({
      message: 'fetching dbs failed'
    });
  });

  async function addAudit(dbId, database_instance_name) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "database",
      relatedId: dbId,
      relatedString: database_instance_name,
      action: "delete"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.createDatabase = (req, res, next) => {
  database = new Database({
    database_instance_name: req.body.database_instance_name,
    physical_server_name: req.body.physical_server_name,
    virtual_server_name: req.body.virtual_server_name,
    pluggable_databases: req.body.pluggable_databases,
    environment_usage: req.body.environment_usage,
    options_in_use: req.body.options_in_use,
    managements_in_use: req.body.managements_in_use,
    rac_nodes: req.body.rac_nodes,
    fal_server: req.body.fal_server,
    fal_client: req.body.fal_client,
    cpu_count: req.body.cpu_count,
    cpu_count_default: req.body.cpu_count_default,
    installation_date: req.body.installation_date,
    users_defined: req.body.users_defined,
    product_edition: req.body.product_edition,
    product_version: req.body.product_version,
    control_management_pack_access: req.body.control_management_pack_access,
    current_sessions: req.body.current_sessions,
    highwater_sessions: req.body.highwater_sessions,
    database_cloned_from: req.body.database_cloned_from,
    database_cloned_date: req.body.database_cloned_date,
    license_allocated_to_server: req.body.license_allocated_to_server,
    application_name: req.body.application_name,
    application_vendor: req.body.application_vendor,
    application_type: req.body.application_type,
    architecture_type: req.body.architecture_type,
    user_type: req.body.user_type,
    web_or_app_tier_server_name: req.body.web_or_app_tier_server_name,
    ebs_release: req.body.ebs_release,
    end_user: req.body.end_user,
    virtualisation_tech: req.body.virtualisation_tech
  });
  database.save().then(createdDb => {
    addAudit(createdDb._id, createdDb.database_instance_name);
    res.status(201).json({
      message: 'added successfully',
      database: createdDb
    });
  })
  .catch(error => {
    res.status(500).json({
      message: 'Creating a database failed!'
    });
  });

  async function addAudit(dbId, database_instance_name) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "database",
      relatedId: dbId,
      relatedString: database_instance_name,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }
}

exports.getDbById = (req, res, next) => {

  Database.findOne({$and: [{_id: req.params.id}, {end_user: {$in: req.userData.subsidiaries}}]}).then(database => {
    if (database) {
      res.status(200).json(database);
    } else {
      res.status(404).json({message: 'database not found'});
    }
  }).catch(error => {
    res.status(500).json({
      message: error.toString()
    });
  });
}

exports.updateDatabase = (req, res, next) => {

  let migrated_from;
  let migration_date;

  Database.findById({_id: req.body.id}).then(result => {
    console.log(result.control_management_pack_access);
      if (!result.physical_server_name.toString().match(req.body.physical_server_name.toString())) {
        Hardware.findById({_id: result.physical_server_name}).then(outcome => {
          migrated_from = outcome.server_name;
          const now = new Date();
          migration_date = new Date(now.getTime());
          updateData();
        });
      } else {

        updateData();
      }
  }) .catch(error => {
    res.status(500).json({
      message: 'Couldn\'t update Database, Database not found!'
    })
  });

  function updateData() {

    let database;

    database = new Database({
      _id: req.body.id,
      database_instance_name: req.body.database_instance_name,
      physical_server_name: req.body.physical_server_name,
      virtual_server_name: req.body.virtual_server_name,
      pluggable_databases: req.body.pluggable_databases,
      enviroment_usage: req.body.enviroment_usage,
      options_in_use: req.body.options_in_use,
      managements_in_use: req.body.managements_in_use,
      rac_nodes: req.body.rac_nodes,
      fal_server: req.body.fal_server,
      fal_client: req.body.fal_client,
      cpu_count: req.body.cpu_count,
      cpu_count_default: req.body.cpu_count_default,
      installation_date: req.body.installation_date,
      users_defined: req.body.users_defined,
      product_edition: req.body.product_edition,
      product_version: req.body.product_version,
      control_management_pack_access: req.body.control_management_pack_access,
      current_sessions: req.body.current_sessions,
      highwater_sessions: req.body.highwater_sessions,
      database_cloned_from: req.body.database_cloned_from,
      database_cloned_date: req.body.database_cloned_date,
      license_allocated_to_server: req.body.license_allocated_to_server,
      application_name: req.body.application_name,
      application_vendor: req.body.application_vendor,
      application_type: req.body.application_type,
      architecture_type: req.body.architecture_type,
      user_type: req.body.user_type,
      web_or_app_tier_server_name: req.body.web_or_app_tier_server_name,
      ebs_release: req.body.ebs_release,
      end_user: req.body.end_user,
      virtualisation_tech: req.body.virtualisation_tech
    });
    Database.findByIdAndUpdate({_id: database._id}, database).then(result => {
      if (result) {
        addAudit(result._id, result.database_instance_name);
        res.status(200).json(database);
      } else {
        res.status(401).json({message: 'No db found'});
      }
    })
    .catch(error => {
      res.status(500).json({
        message: 'Couldn\'t update Database'
      })
    });
  }

  async function addAudit(dbId, database_instance_name) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "database",
      relatedId: dbId,
      relatedString: database_instance_name,
      action: "edit"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      })
    }
  }

}

exports.searchDatabases = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  const databaseVersion = [11, 2];
  let company;
  let searchParam = '';
  let hardwareId;
  let allDatabases;
  let sortType;
  let fetchedDatabases;
  let pageType;
  let compareDatabase;

  if (req.query.company !== 'undefined') {company = req.query.company};
  if (req.params.searchParam  !== 'undefined') {searchParam = req.params.searchParam};
  if (req.query.hardware !== 'undefined') {hardwareId = req.query.hardware};
  if (req.query.sort !== 'undefined' && req.query.sort !== 'null') { sortType = req.query.sort; }
  if (req.query.pageChosen !== 'null') { pageType = req.query.pageChosen; }

  MainMethod();

  function getDatabases() {
    if (company) {
      if (hardwareId) {
        return Database.find({$and: [
                                    {end_user: company},
                                    {end_user: {$in: req.userData.subsidiaries}},
                                    {physical_server_name: hardwareId},
                                    {database_instance_name: {$regex: searchParam, $options: 'i'}}
                            ]});
      } else {
        return Database.find({$and: [
                                    {end_user: company},
                                    {end_user: {$in: req.userData.subsidiaries}},
                                    {database_instance_name: {$regex: searchParam, $options: 'i'}}
                            ]});
      }
    } else {
      return Database.find({$and: [
                                  {end_user: {$in: req.userData.subsidiaries}},
                                  {database_instance_name: {$regex: searchParam, $options: 'i'}}
                            ]});
    }
  }

  async function MainMethod() {

    if (req.query.compareDatabaseId !== 'null') {
      compareDatabase = await Database.findById(req.query.compareDatabaseId, {database_instance_name: 1, product_edition: 1});
    }
    allDatabases = getDatabases();

    if (pageType === 'FIRST') {
      allDatabases.limit(pageSize);
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Instance Alphabetically':
            allDatabases
            .sort({database_instance_name: 1});
            break;
          case 'Instance Non Alphabetically':
            allDatabases
            .sort({database_instance_name: -1});
            break;
          case 'Edition Alphabetically':
            allDatabases
            .sort({product_edition: 1});
            break;
          case 'Edition Non Alphabetically':
            allDatabases
            .sort({product_edition: -1});
            break;
        }
      }
    }

    if (pageType === 'NEXT') {
      allDatabases.limit(pageSize);
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Instance Alphabetically':
            allDatabases.sort({database_instance_name: 1});
            allDatabases.find({$or: [{$and: [{database_instance_name: compareDatabase.database_instance_name}, {_id: {$gt: compareDatabase._id}}]}, {database_instance_name: {$gt: compareDatabase.database_instance_name}}]});
            break;
          case 'Instance Non Alphabetically':
            allDatabases.sort({database_instance_name: -1});
            allDatabases.find({$or: [{$and: [{database_instance_name: compareDatabase.database_instance_name}, {_id: {$gt: compareDatabase._id}}]}, {database_instance_name: {$lt: compareDatabase.database_instance_name}}]});
            break;
          case 'Edition Alphabetically':
            allDatabases.sort({product_edition: 1});
            allDatabases.find({product_edition: {$gt: compareDatabase.product_edition}});
            break;
          case 'Edition Non Alphabetically':
            allDatabases.sort({product_edition: -1});
            allDatabases.find({product_edition: {$lt: compareDatabase.product_edition}});
            break;
        }
      } else {
        allDatabases.find({_id: {$gt: req.query.compareDatabaseId}});
      }

    }

    if (pageType === 'PREVIOUS') {
      allDatabases.limit(pageSize);
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Instance Alphabetically':
            allDatabases.sort({database_instance_name: -1});
            allDatabases.find({$or: [{$and: [{database_instance_name: compareDatabase.database_instance_name}, {_id: {$lt: compareDatabase._id}}]}, {database_instance_name: {$lt: compareDatabase.database_instance_name}}]});
            break;
          case 'Instance Non Alphabetically':
            allDatabases.sort({database_instance_name: 1});
            allDatabases.find({$or: [{$and: [{database_instance_name: compareDatabase.database_instance_name}, {_id: {$lt: compareDatabase._id}}]}, {database_instance_name: {$gt: compareDatabase.database_instance_name}}]});
            break;
          case 'Edition Alphabetically':
            allDatabases.sort({product_edition: -1});
            allDatabases.find({product_edition: {$lt: compareDatabase.product_edition}});
            break;
          case 'Edition Non Alphabetically':
            allDatabases.sort({product_edition: 1});
            allDatabases.find({product_edition: {$gt: compareDatabase.product_edition}});
            break;
        }
      } else {
        allDatabases.sort({_id: -1});
        allDatabases.find({_id: {$lt: req.query.compareDatabaseId}});
      }
    }

    if (pageType === 'LAST') {
      allDatabases.limit(count - (pageSize * (currentPage -1)));
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Instance Alphabetically':
            allDatabases
            .sort({database_instance_name: -1});
            break;
          case 'Instance Non Alphabetically':
            allDatabases
            .sort({database_instance_name: 1});
            break;
          case 'Edition Alphabetically':
            allDatabases
            .sort({product_edition: -1});
            break;
          case 'Edition Non Alphabetically':
            allDatabases
            .sort({product_edition: 1});
            break;
        }
      } else {
        allDatabases.sort({_id: -1});
      }
    }


    allDatabases.then(documents => {
      getData();

      async function getData() {
        fetchedDatabases = await getWarnings(documents);
        count = await getDatabases().countDocuments();

        res.status(200).json({
          message: 'database search fetched successfully',
          databases: fetchedDatabases,
          maxDatabases: count
        });
      }
    })

    async function getWarnings(dbs) {
      for (db of dbs) {
        if (db.product_version && db.options_in_use) {

          let ver = db.product_version.split('.').map(x => x = parseInt(x));
          if (ver[0] < databaseVersion[0]  || (ver[0] === databaseVersion[0] && ver[1] < databaseVersion[1])) {
            const hw = await Hardware.findById({_id: db.physical_server_name}).lean().populate({path: 'license_allocated_to_server', populate: {path: 'product_licensed'}});
            for (opt of db.options_in_use) {
              let field = opt.option_in_use.replace(/ /g,'_').toLowerCase();
              // to accommodate bad data?
              if (!hw.license_allocated_to_server) { hw.license_allocated_to_server = []; }
              allocatedWithOptionCount = hw.license_allocated_to_server.filter(lic => lic.product_licensed.product_name.match(opt.option_in_use)).length
              if ((field.match('spatial_and_graph') || field.match('advanced_analytics')) && allocatedWithOptionCount === 0){
                db[field] = false;
              }
            }
          }
        }
      }
      return dbs;
    }
  }
}

