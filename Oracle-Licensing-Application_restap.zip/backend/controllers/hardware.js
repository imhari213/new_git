const Hardware = require('../models/hardwares/hardware');
const IBM = require('../models/hardwares/ibmlpar');
const OVM = require('../models/hardwares/ovm');
const KVM = require('../models/hardwares/kvm');
const XEN = require('../models/hardwares/xen');
const Solaris = require('../models/hardwares/solaris');
const VMachine = require('../models/hardwares/virtualmachine');
const HPUX = require('../models/hardwares/hpux');
const LicAllocated = require('../models/hardwares/licensesallocated');
const OracleLic = require('../models/contracts/oracleLicenses');

const AuditLog = require('../models/audit/auditlog');

exports.getServerNameList = (req,res, next) => {
  Hardware.find({company: req.params.compId}, {server_name: true}).lean().then(result => {
    if (result) {
      res.status(201).json({
        serverNameList: result,
        message: "Server Found"
      })

    } else {
      res.status(400).json({
        message : "No server found"
      })
    }
  });
}

exports.getServerName = (req, res, next) => {

  Hardware.findOne({_id: req.params.serverId}, {server_name: true, _id: false}).lean().then(result => {
    if (result) {
      res.status(201).json({
        serverName: result.server_name,
        message: "Server Found"
      });
    } else {
      res.status(400).json({
        message : "No server found"
      })
    }
  })
}

exports.createHardware = (req, res, next) => {
  MainMethod();

  async function MainMethod() {

    let ibm_virt, ovm_virt, kvm_virt, xen_virt, solaris_virt, vmware_virt, hp_ux_virt;

    if (req.body.ibm_virt && req.body.ibm_virt.length > 0) { ibm_virt = await createSchema(req.body.ibm_virt, "ibm"); }
    else if (req.body.ovm_virt && req.body.ovm_virt.length > 0) { ovm_virt = await createSchema(req.body.ovm_virt, "ovm"); }
    else if (req.body.kvm_virt && req.body.kvm_virt.length > 0) { kvm_virt = await createSchema(req.body.kvm_virt, "kvm"); }
    else if (req.body.xen_virt && req.body.xen_virt.length > 0) { xen_virt = await createSchema(req.body.xen_virt, "xen"); }
    else if (req.body.solaris_virt && req.body.solaris_virt.length > 0) {solaris_virt = await createSchema(req.body.solaris_virt, "solaris"); }
    else if (req.body.vmware_virt && req.body.vmware_virt.length > 0) { solaris_virt = await createSchema(req.body.vmware_virt, "vmware"); }
    else if (req.body.hp_ux_virt && req.body.hp_ux_virt.length > 0) {hp_ux_virt = await createSchema(req.body.hp_ux_virt, "hpux"); }
    hardware = new Hardware({
      ...req.body,
      _id: req.body._id,
      company: req.body.company_name,
      ibm_virt: ibm_virt,
      ovm_virt: ovm_virt,
      kvm_virt: kvm_virt,
      xen_virt: xen_virt,
      solaris_virt: solaris_virt,
      vmware_virt: vmware_virt,
      hp_ux_virt: hp_ux_virt
    })

    hardware.save().then(new_hw => {
      addAudit(new_hw._id, new_hw.server_name);
      res.status(201).json({
        message: 'added successfully',
        hardware: new_hw,
        id: new_hw._id
      });
    }).catch(error => {
      res.status(500).json({
        message: error.toString()
      });
    });
  }

  async function addAudit(hwId, serverName) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "hardware",
      relatedId: hwId,
      relatedString: serverName,
      action: "add"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      });
    }
  }

  async function createSchema(object_array, type) {
    objs = object_array;
    ids_list = [];

    for(let i = 0; i < objs.length; ++i) {

      let new_obj;
      const classless_obj = await {...objs[i], _id: undefined, virtual_server_name: objs[i].virtual_server_name};

      if (type === "ibm") { new_obj = new IBM(classless_obj); }
      else if (type === "ovm") { new_obj = new OVM(classless_obj); }
      else if (type === "kvm") { new_obj = new KVM(classless_obj); }
      else if (type === "xen") { new_obj = new XEN(classless_obj); }
      else if (type === "solaris") { new_obj = new Solaris(classless_obj); }
      else if (type === "vmware") { new_obj = new VMachine(classless_obj); }
      else if (type === "hpux") { new_obj = new HPUX(classless_obj); }

      saved = await new_obj.save();
      ids_list.push(saved._id);
    }
    return ids_list;
  }

}

exports.getAllHardware = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;

  hardwareQuery = getHardware();

  if(pageSize && currentPage) {
    hardwareQuery.skip(pageSize * (currentPage - 1)).limit(pageSize);
  }

  hardwareQuery.then(documents => {
    response();
    async function response() {
      res.status(200).json({
        message: 'Hardware Fetched Successfully!',
        hardwares: documents,
        maxHardwares: await getHardware().countDocuments
      });
    }
  }).catch(error => {
    res.status(200).json({
      message: 'Unable to retreive hardwares!',
    });
  })

  function getHardware() {
    let hw;

    if (req.userData.role === 'master') { hw = Hardware.find().lean()
      .populate('ibm_virt').populate('ovm_virt').populate('kvm_virt').populate('xen_virt').populate('solaris_virt').populate('vmware_virt').populate('hp_ux_virt')
      .populate('license_allocated_to_server'); }
    else { hw = Hardware.find( {company: {$in: req.userData.subsidiaries}}).lean()
      .populate('ibm_virt').populate('ovm_virt').populate('kvm_virt').populate('xen_virt').populate('solaris_virt').populate('vmware_virt').populate('hp_ux_virt')
      .populate('license_allocated_to_server'); }

    return hw;
  }
}

exports.getHwById = (req, res, next) => {

  const hardware = Hardware.findOne({$and: [{_id: req.params.id}, {company: {$in: req.userData.subsidiaries}}]}).lean();

  hardware.populate('ibm_virt').populate('ovm_virt').populate('kvm_virt').populate('xen_virt').populate('solaris_virt').populate('vmware_virt').populate('hp_ux_virt');
  hardware.populate('license_allocated_to_server');

  hardware.then(document => {
    res.status(200).json(document);
  }).catch(error => {
    res.status(500).json({ message: 'Unable to retrieve hardware' + error.toString()})
  });

}

exports.searchHardware = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;


  let searchParam = '';
  let company;
  let cluster;
  let contract;
  let sortType;
  let pageType;
  let licIds = [];
  let compareHardware;
  let count;

  main();

  async function main() {
    await queryParamsSort();
    retrieveHw();
  }

  async function queryParamsSort(){
    if (req.query.company !== 'undefined' && req.query.company !== 'null') {company = req.query.company; }
    if (req.params.searchParam !== 'undefined') {searchParam = req.params.searchParam; }
    if (req.query.contract !== 'undefined' && req.query.contract !== 'null') {contract = req.query.contract; }
    if (req.query.cluster !== 'undefined' && req.query.cluster !== 'null') {cluster = req.query.cluster; }
    if (req.query.sort !== 'undefined' && req.query.sort !== 'null') { sortType = req.query.sort; }
    if (req.query.pageChosen !== 'null') { pageType = req.query.pageChosen; }
    if (contract) {
      licList = await LicAllocated.find({contract_linked: contract}).lean();
      licList.forEach(lic => { licIds.push(lic._id); });
    }

  }

  async function retrieveHw() {
    if (req.query.compareHardwareId !== 'null') {
      compareHardware = await Hardware.findById(req.query.compareHardwareId, {server_name: 1, server_purchase_date: 1});
    }

    hardwares = getHardware();
    if (pageType === 'FIRST') {
      hardwares.limit(pageSize);
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Date added (oldest)':
            hardwares
            .sort({server_purchase_date: 1});
            break;
          case 'Date added (newest)':
            hardwares
            .sort({server_purchase_date: -1});
            break;
          case 'Alphabetically':
            hardwares
            .sort({server_name: 1});
            break;
          case 'Non Alphabetically':
            hardwares
            .sort({server_name: -1});
            break;
        }
      }
    }

    if (pageType === 'NEXT') {
      hardwares.limit(pageSize);
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Date added (oldest)':
            hardwares.sort({server_purchase_date: 1});
            hardwares.find({$or: [{$and: [{server_purchase_date: compareHardware.server_purchase_date}, {_id: {$gt: compareHardware._id}}]}, {server_purchase_date: {$gt: compareHardware.server_purchase_date}}]});
            break;
          case 'Date added (newest)':
            hardwares.sort({server_purchase_date: -1});
            hardwares.find({$or: [{$and: [{server_purchase_date: compareHardware.server_purchase_date}, {_id: {$gt: compareHardware._id}}]}, {server_purchase_date: {$lt: compareHardware.server_purchase_date}}]});
            break;
          case 'Alphabetically':
            hardwares.sort({server_name: 1});
            hardwares.find({server_name: {$gt: compareHardware.server_name}});
            break;
          case 'Non Alphabetically':
            hardwares.sort({server_name: -1});
            hardwares.find({server_name: {$lt: compareHardware.server_name}});
            break;
        }
      } else {
        hardwares.find({_id: {$gt: req.query.compareHardwareId}});
      }

    }

    if (pageType === 'PREVIOUS') {
      hardwares.limit(pageSize);
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Date added (oldest)':
            hardwares.sort({server_purchase_date: -1});
            hardwares.find({$or: [{$and: [{server_purchase_date: compareHardware.server_purchase_date}, {_id: {$lt: compareHardware._id}}]}, {server_purchase_date: {$lt: compareHardware.server_purchase_date}}]});
            break;
          case 'Date added (newest)':
            hardwares.sort({server_purchase_date: 1});
            hardwares.find({$or: [{$and: [{server_purchase_date: compareHardware.server_purchase_date}, {_id: {$lt: compareHardware._id}}]}, {server_purchase_date: {$gt: compareHardware.server_purchase_date}}]});
            break;
          case 'Alphabetically':
            hardwares.sort({server_name: -1});
            hardwares.find({server_name: {$lt: compareHardware.server_name}});
            break;
          case 'Non Alphabetically':
            hardwares.sort({server_name: 1});
            hardwares.find({server_name: {$gt: compareHardware.server_name}});
            break;
        }
      } else {
        hardwares.sort({_id: -1});
        hardwares.find({_id: {$lt: req.query.compareHardwareId}});
      }
    }

    if (pageType === 'LAST') {
      count = await getHardware().countDocuments();
      hardwares.limit(count - (pageSize * (currentPage -1)));
      if (sortType && sortType !== 'undefined') {
        switch(sortType) {
          case 'Date added (oldest)':
            hardwares
            .sort({server_purchase_date: -1});
            break;
          case 'Date added (newest)':
            hardwares
            .sort({server_purchase_date: 1});
            break;
          case 'Alphabetically':
            hardwares
            .sort({server_name: -1});
            break;
          case 'Non Alphabetically':
            hardwares
            .sort({server_name: 1});
            break;
        }
      } else {
        hardwares.sort({_id: -1});
      }
    }

    hardwares.populate('ibm_virt ovm_virt kvm_virt xen_virt solaris_virt vmware_virt license_allocated_to_server hp_ux_virt')
    // .populate({path: 'license_allocated_to_server', populate: {path: 'product_licensed contract_linked'}});
    hardwares.then(documents => {
      // to accommodate bad data
      documents.forEach(doc => { if (!doc.license_allocated_to_server) { doc.license_allocated_to_server = []; }})

      response();

      async function response() {
        res.status(200).json({
          message: 'hardwares fetched successfully',
          hardwares: documents,
          maxHardwares: await getHardware().countDocuments()
        })
      }
    })

    function getHardware() {

      let hw;

      if (company) {

        if (contract) {

          hw = Hardware.find({$and: [
                                      {license_allocated_to_server: {$elemMatch: { $in: licIds} }},
                                      {company: {$in: req.userData.subsidiaries}},
                                      {company: company},
                                      {$or: [
                                        {server_name: {$regex: searchParam, $options: 'i'}},
                                        {virtualisation_name: {$regex: searchParam, $options: 'i'}}
                                      ]},
                                    ]}).lean();


        } else if (cluster) {
          hw = Hardware.find({$and: [
                                      {company: company},
                                      {company: {$in: req.userData.subsidiaries}},
                                      {$or: [
                                        {server_name: {$regex: searchParam, $options: 'i'}},
                                        {virtualisation_name: {$regex: searchParam, $options: 'i'}}
                                      ]},
                                      {cluster_id: cluster}
                                    ]}).lean();
        } else {
          hw = Hardware.find({$and: [
                                              {company: company},
                                              {company: {$in: req.userData.subsidiaries}},
                                              {$or: [
                                                {server_name: {$regex: searchParam, $options: 'i'}},
                                                {virtualisation_name: {$regex: searchParam, $options: 'i'}}
                                              ]},
                                            ]}).lean();
        }

      } else {
        hw =  Hardware.find({$and: [
                                        {company: {$in: req.userData.subsidiaries}},
                                        {$or: [
                                          {server_name: {$regex: searchParam, $options: 'i'}},
                                          {virtualisation_name: {$regex: searchParam, $options: 'i'}}
                                          ]},
                                      ]}).lean();
      }

      return hw;
    }

  }
}

exports.updateHardware = (req, res, next) => {

  async function createIdList(array, type) {
    const idList = [];
    if (array) {
      for (let i = 0; i < array.length; ++i) {
        const object = array[i];
        if (object._id) {
          idList.push(object._id);
          if (type === 'lic') {
            og_lic = await LicAllocated.findById(object._id);
            oracle = await OracleLic.findById(og_lic.product_licensed);
            oracle.allocated = oracle.allocated - og_lic.number_of_licenses_in_use + og_lic.number_of_licenses_in_use;
            OracleLic.updateOne({_id: oracle._id}, oracle);
            await LicAllocated.updateOne({_id: object._id}, object);
          }
          else if (type === 'ibm') { await IBM.updateOne({_id: object._id}, object); }
          else if (type === 'ovm') { await OVM.updateOne({_id: object._id}, object); }
          else if (type === 'kvm') { await KVM.updateOne({_id: object._id}, object); }
          else if (type === 'xen') { await XEN.updateOne({_id: object._id}, object); }
          else if (type === 'solaris') { await Solaris.updateOne({_id: object._id}, object); }
          else if (type === 'vmware') { await VMachine.updateOne({_id: object._id}, object); }
          else if (type === 'hp_ux') { await HPUX.updateOne({_id: object._id}, object); }
        } else {
          let new_obj;
          if (type === 'lic') { new_obj = new LicAllocated({...object, _id: undefined}); }
          else if (type === 'ibm') { new_obj = new IBM({...object, _id: undefined}); }
          else if (type === 'ovm') { new_obj = new OVM({...object, _id: undefined}); }
          else if (type === 'kvm') { new_obj = new KVM({...object, _id: undefined}); }
          else if (type === 'xen') { new_obj = new XEN({...object, _id: undefined}); }
          else if (type === 'solaris') { new_obj = new Solaris({...object, _id: undefined}); }
          else if (type === 'vmware') { new_obj = new VMachine({...object, _id: undefined}); }
          else if (type === 'hp_ux') { new_obj = new HPUX({...object, _id: undefined}); }

          saved = await new_obj.save();
          idList.push(saved._id.toString());
      }
    }
    return idList;
  }
  }

  async function compareToDelete(hardware) {
    const og_hw = await Hardware.findById(req.params.id).lean();
    let og_lic = [];
    let og_ibm = [];
    let og_ovm = [];
    let og_kvm = [];
    let og_xen = [];
    let og_sol = [];
    let og_vmw = [];
    let og_hpux = [];

    if (og_hw.license_allocated_to_server) { og_lic = og_hw.license_allocated_to_server.filter(lic => !hardware.license_allocated_to_server.includes(lic)); }
    if (og_hw.ibm_virt) { og_ibm = og_hw.ibm_virt.filter(ibm => !hardware.ibm_virt.includes(ibm)); }
    if (og_hw.ovm_virt) { og_ovm = og_hw.ovm_virt.filter(ovm => !hardware.ibm_virt.includes(ovm)); }
    if (og_hw.kvm_virt) { og_kvm = og_hw.kvm_virt.filter(kvm => !hardware.ibm_virt.includes(kvm)); }
    if (og_hw.xen_virt) { og_xen = og_hw.xen_virt.filter(xen => !hardware.ibm_virt.includes(xen)); }
    if (og_hw.solaris_virt) { og_sol = og_hw.solaris_virt.filter(sol => !hardware.ibm_virt.includes(sol)); }
    if (og_hw.vmware_virt) { og_vmw = og_hw.vmware_virt.filter(vmw => !hardware.ibm_virt.includes(vmw)); }
    if (og_hw.hp_ux_virt) { og_hpux = og_hw.hp_ux_virt.filter(hpux => !hardware.hp_ux_virt.includes(hpux)); }

    for (let i = 0; i < og_lic.length; ++i) {
      try {
        const lic_all = await LicAllocated.findById(og_lic[i]).lean();
        const all_lic = await OracleLic.findById(lic_all.product_licensed);
        all_lic.allocated -= lic_all.number_of_licenses_in_use;
        all_lic.allowed += lic_all.number_of_licenses_in_use;
        await OracleLic.updateOne({_id: all_lic._id}, all_lic);
        await LicAllocated.deleteOne({_id: og_lic[i]});
      } catch (err) {}

    }

    for (let i = 0; i < og_ibm.length; ++i) { await IBM.deleteOne({_id: og_ibm[i]}); }
    for (let i = 0; i < og_ovm.length; ++i) { await OVM.deleteOne({_id: og_ovm[i]}); }
    for (let i = 0; i < og_kvm.length; ++i) { await KVM.deleteOne({_id: og_kvm[i]}); }
    for (let i = 0; i < og_xen.length; ++i) { await XEN.deleteOne({_id: og_xen[i]}); }
    for (let i = 0; i < og_sol.length; ++i) { await Solaris.deleteOne({_id: og_sol[i]}); }
    for (let i = 0; i < og_vmw.length; ++i) { await VMachine.deleteOne({_id: og_vmw[i]}); }
    for (let i = 0; i < og_hpux.length; ++i) { await HPUX.deleteOne({_id: og_hpux[i]}); }

  }

  main();

  async function main() {

    let ibm_virt, ovm_virt, kvm_virt, xen_virt, solaris_virt, vmware_virt, hp_ux_virt, license_allocated_to_server;

    if (req.body.ibm_virt && req.body.ibm_virt.length > 0) { ibm_virt = await createIdList(req.body.ibm_virt, "ibm"); }
    if (req.body.ovm_virt && req.body.ovm_virt.length > 0) { ovm_virt = await createIdList(req.body.ovm_virt, "ovm"); }
    if (req.body.kvm_virt && req.body.kvm_virt.length > 0) { kvm_virt = await createIdList(req.body.kvm_virt, "kvm"); }
    if (req.body.xen_virt && req.body.xen_virt.length > 0) { xen_virt = await createIdList(req.body.xen_virt, "xen"); }
    if (req.body.solaris_virt && req.body.solaris_virt.length > 0) { solaris_virt = await createIdList(req.body.solaris_virt, "solaris"); }
    if (req.body.vmware_virt && req.body.vmware_virt.length > 0) { vmware_virt = await createIdList(req.body.vmware_virt, "vmware"); }
    if (req.body.hp_ux_virt && req.body.hp_ux_virt.length > 0) { hp_ux_virt = await createIdList(req.body.hp_ux_virt, 'hp_ux'); }

    if (req.body.license_allocated_to_server && req.body.license_allocated_to_server.length > 0) {
      license_allocated_to_server = await createIdList(req.body.license_allocated_to_server, "lic");
    }


    updatedHardware = new Hardware({
      ...req.body,
      _id: req.body.id,
      server_name: req.body.server_name,
      server_model: req.body.server_model,
      ibm_virt: ibm_virt,
      ovm_virt: ovm_virt,
      kvm_virt: kvm_virt,
      xen_virt: xen_virt,
      solaris_virt: solaris_virt,
      vmware_virt: vmware_virt,
      hp_ux_virt: hp_ux_virt,
      license_allocated_to_server: license_allocated_to_server
    })

    // await compareToDelete(updatedHardware);

    try {
      const upHardware = await Hardware.findByIdAndUpdate({_id: req.params.id}, updatedHardware);
      addAudit(upHardware._id, upHardware.server_name);
      res.status(201).json({
        message: 'Updated Successfully',
        hardware: {...updatedHardware}
      });
    } catch(error) {
      res.status(500).json({
        message: 'Updating hardware failed' + error.toString()
      })
    }
  }

  async function addAudit(hwId, serverName) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "hardware",
      relatedId: hwId,
      relatedString: serverName,
      action: "edit"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      });
    }
  }

}

exports.deleteHardware = (req, res, next) => {

  main();

  async function main() {
    const hardware = await Hardware.findById(req.params.id).populate({path: 'license_allocated_to_server', populate: {path: 'product_licensed'}});

    if (hardware.ibm_virt) { await IBM.deleteMany({_id: {$in: hardware.ibm_virt}}); }
    if (hardware.ovm_virt) { await OVM.deleteMany({_id: {$in: hardware.ovm_virt}}); }
    if (hardware.kvm_virt) { await KVM.deleteMany({_id: {$in: hardware.kvm_virt}}); }
    if (hardware.xen_virt) { await XEN.deleteMany({_id: {$in: hardware.xen_virt}}); }
    if (hardware.solaris_virt) { await Solaris.deleteMany({_id: hardware.solaris_virt}); }
    if (hardware.vmware_virt) { await VMachine.deleteMany({_id: {$in: hardware.vmware_virt}}); }

    if (hardware.license_allocated_to_server !== null) {
      for(let i = 0; i < hardware.license_allocated_to_server.length; ++i) {
        productLicensed = hardware.license_allocated_to_server[i].product_licensed;

        productLicensed.allocated -= hardware.license_allocated_to_server.number_of_licenses_in_use;
        productLicensed.allowed += hardware.license_allocated_to_server.number_of_licenses_in_use;
        await OracleLic.updateOne({_id: productLicensed._id}, productLicensed);
        await LicAllocated.deleteOne({_id: hardware.license_allocated_to_server[i]._id})

      }
    }

    await Hardware.findByIdAndDelete({_id: hardware._id}).then(result => {
      if (result) {
        addAudit(result._id, result.server_name);
        res.status(200).json({message: 'hardware deleted'});
      } else {
          res.status(400).json({
              message: "hardware not found"
          });
      }
    });

  }

  async function addAudit(hwId, serverName) {

    const object = new AuditLog({
      userId: req.userData.userId,
      email: req.userData.email,
      datetime: new Date(),
      databaseChanged: "hardware",
      relatedId: hwId,
      relatedString: serverName,
      action: "delete"
    })
    try {
      object.save();
    } catch(error) {
      res.status(500).json({
        message: error.toString()
      });
    }
  }

}

exports.migrateAllocatedLicense = (req, res, next) => {

  newLicense = req.body.newLicense;
  oldLicense = req.body.oldLicense;
  newContract = req.body.newContract;

  try {
    LicAllocated.find({product_licensed: oldLicense._id}).lean().then(lics => {
      for (let i = 0; i < lics.length; ++i) {
        updateLicense(lics[i]);
      }

      res.status(201).json({
        message: 'Updating Licenses'
      })

      async function updateLicense(licAllocated) {
        const updateLicense = await LicAllocated.findById(licAllocated);
        updateLicense.contract_linked = newContract;
        updateLicense.product_licensed = newLicense._id;
        updated = await LicAllocated.updateOne({_id: updateLicense._id}, updateLicense);
      }
    })
  } catch (err) {
    res.status(500).json({
      message: 'Failed to update licenses' + err.toString()
    })
  }


}
