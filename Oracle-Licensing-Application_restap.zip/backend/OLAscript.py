import pandas as pd
import json
import pymongo
from numpy import array, nan
from pymongo import MongoClient
from bson.json_util import dumps
from bson import ObjectId
from datetime import datetime
#from mongothon import Schema
#from mongothon import create_model
#pip install pymongo[srv]
#pip install Mongothon

def main():
    print('Start')
    client = MongoClient('mongodb+srv://scmilne:test@applicationdevelopment-o6lnv.mongodb.net/test')
    db = client.demo

    companySchema = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="CompanySchema")
    company_name = companySchema.company_name.iloc[0]
    

    companyJSONGenerator(db, companySchema)
    # run after company is created to pass through the company's oid
    companyCollection = db.comps
    companyCursor = companyCollection.find({"company_name": company_name}, {'_id':1})
    for companyId in companyCursor:
        companyStr = str(companyId)
        companyOid = companyStr[18:len(companyStr)-3]

    #delete(db, company_name, companyOid)
    #contractSubDocumentJSONGenerator(db, company_name)
    #contractJSONGenerator(db, company_name)
    #not used here! hardwareSubDocumentGenerator(db, company_name)
    virtualServerGenerator(db, company_name)
    hardwareGenerator(db, companyOid, company_name)
    databaseGenerator(db, companyOid)
    #declarationGenerator(db, companyOid)
    middlewareGenerator(db, companyOid)

    print('End')

def delete(db, company_name, companyOid):
    #delete oracle licenses
    #oracleLicsCollection = db.oraclelicenses
    #oracleLicsCollection.delete_many({"company": company_name})

    #delete contracts
    #contractCollection  = db.contracts
    #contractCollection.delete_many({"end_user": ObjectId(companyOid)})

    #ovmCollection = db.oraclelicenses
    #ovmCollection.delete_many({"company": company_name})

    #ibmCollection = db.ibmlpars
    #ibmCollection.delete_many({"company": company_name})

    dbCollection = db.dbs
    dbCollection.delete_many({"end_user": ObjectId(companyOid)})

def declarationGenerator(db, companyOid):
    print("Start Declaration Generator")
    declarationData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="DeclarationSchema")
    declarationDataString = declarationData.astype(str)
    updatedDeclarationDataString =  declarationDataString.replace({str(nan): None})
    refList = declarationData['Ref_ID#'].values
    declarationCollection = db.additionaloracleproducts

    for index in refList:
        declarationObject = ({
            "product": updatedDeclarationDataString.iloc[index-1].product,
            "company": ObjectId(companyOid),
            "license_metric": updatedDeclarationDataString.iloc[index-1].license_metric,
            "existing_license_level": updatedDeclarationDataString.iloc[index-1].existing_license_level,
            "customer_support_identifier": updatedDeclarationDataString.iloc[index-1].customer_support_identifier,
            "license_grant": updatedDeclarationDataString.iloc[index-1].license_grant,
            "declared_usage": updatedDeclarationDataString.iloc[index-1].declared_usage,
            "additional_comments": updatedDeclarationDataString.iloc[index-1].additional_comments
        })
        declarationCollection.insert_one(declarationObject)
    print("End Declaration Generator")

def middlewareGenerator (db, companyOid):
    print("Start Middleware Generator")
    middlewareData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="MiddlewareSchema")
    middlewareString = middlewareData.astype(str)
    updatedMiddlewareString = middlewareString.replace({str(nan): None})
    refMiddlewareList = middlewareData['Ref_ID#'].values
    middlewareCollection = db.middlewares
    hardwareCollection = db.hardwares

    for middlewareIndex in refMiddlewareList:
     #check if there are any options or management packs in use or components installed  if there are then to call another functions to get the details
        if (updatedMiddlewareString.iloc[middlewareIndex-1].options_in_use):
            options_in_use = updatedMiddlewareString.iloc[middlewareIndex-1].options_in_use.split(',')
            optionsList = getOptionsList(options_in_use, "middleware")
        else:
            optionsList = None
        if (updatedMiddlewareString.iloc[middlewareIndex-1].managements_in_use):
            managements_in_use = updatedMiddlewareString.iloc[middlewareIndex-1].managements_in_use.split(',')
            managementList = getManagementList(managements_in_use, "middleware")
        else:
            managementList = None
        if (updatedMiddlewareString.iloc[middlewareIndex-1].components_installed):
            components_installed = updatedMiddlewareString.iloc[middlewareIndex-1].components_installed.split(',')
            componentsList = middlewareComponentGenerator(components_installed)

        server_name = middlewareData.iloc[middlewareIndex-1].primary_server_for_failover_dr_backup_testing
        hardwareCursor = hardwareCollection.find({"server_name": server_name}, {"_id":1})
        hardwareOid = getHardwareId(hardwareCursor)
                
        middlewareObj = ({
            "product": updatedMiddlewareString.iloc[middlewareIndex-1]._product,
            "licensable_product": updatedMiddlewareString.iloc[middlewareIndex-1].licensable_product,
            "product_version": updatedMiddlewareString.iloc[middlewareIndex-1].product_version,
            "environment_usage": updatedMiddlewareString.iloc[middlewareIndex-1].environment_usage,
            "physical_server": updatedMiddlewareString.iloc[middlewareIndex-1].physical_server,
            "primary_server_for_failover_dr_backup_testing": ObjectId(hardwareOid),
            "virtual_server_for_failover_dr_backup_testing": updatedMiddlewareString.iloc[middlewareIndex-1].virtual_server_for_failover_dr_backup_testing,
            "company": ObjectId(companyOid),
            "components_installed": componentsList,
            "managements_in_use": managementList,
            "options_in_use": optionsList
        })
        middlewareCollection.insert_one(middlewareObj)
    print("End Middleware Generator")

def middlewareComponentGenerator (components_installed):
    componentData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="ComponentsInstalledSchema")
    componentDataString = componentData.astype(str)
    updatedComponentDataString = componentDataString.replace({str(nan): None})
    refList = componentData['Ref_ID#'].values

    componentsList = []
    for component in components_installed:
        for componentIndex in refList:
            if (int(component) == componentIndex):
                componentsList.append({
                    "_id": ObjectId(),
                    "component_installed": updatedComponentDataString.iloc[componentIndex-1].component_installed,
                    "location_of_evidence": updatedComponentDataString.iloc[componentIndex-1].location_of_evidence
                })
    #print(componentsList)
    print('---------------------------')
    return (componentsList)
    

def virtualServerGenerator (db, company_name):
    # Ovm virt data insert
    ovmData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="OvmSchema")
    ovmDataString = ovmData.astype(str)
    updatedOvmDataString = ovmDataString.replace({str(nan): None})
    refList = ovmData['Ref_ID#'].values
    ovmCollection = db.ovms
    for index in refList:
        ovmObject = ({
            "virtual_server_name": updatedOvmDataString.iloc[index-1].virtual_server_name,
            "uuid": updatedOvmDataString.iloc[index-1].uuid,
            "max_vcpus": updatedOvmDataString.iloc[index-1].max_vcpus,
            "vcpus": updatedOvmDataString.iloc[index-1].vcpus,
            "cpu_affinity": updatedOvmDataString.iloc[index-1].cpu_affinity,
            "total_cpus": updatedOvmDataString.iloc[index-1].total_cpus,
            "live_migration": updatedOvmDataString.iloc[index-1].live_migration,
            "ovm_high_availability": json.loads(updatedOvmDataString.iloc[index-1].ovm_high_availability.lower()),
            "notes": updatedOvmDataString.iloc[index-1].notes,
            "company": company_name
        })
        ovmCollection.insert_one(ovmObject)

    # Ibm virt data insert
    ibmData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="IbmLparSchema")
    ibmDataString = ibmData.astype(str)
    updatedIbmDataString = ibmDataString.replace({str(nan): None})
    ibmRefList = ibmData['Ref_ID#'].values
    ibmCollection = db.ibmlpars

    for ibmIndex in ibmRefList:
        ibmObject = ({
            "virtual_server_name": updatedIbmDataString.iloc[ibmIndex-1].virtual_server_name,
            "machine_serial_number": updatedIbmDataString.iloc[ibmIndex-1].machine_serial_number,
            "partition_name": updatedIbmDataString.iloc[ibmIndex-1].partition_name,
            "partition_number": updatedIbmDataString.iloc[ibmIndex-1].partition_number,
            "partition_type": updatedIbmDataString.iloc[ibmIndex-1].partition_type,
            "mode": updatedIbmDataString.iloc[ibmIndex-1]._mode,
            "entitled_capacity": updatedIbmDataString.iloc[ibmIndex-1].entitled_capacity,
            "shared_pool_id": updatedIbmDataString.iloc[ibmIndex-1].shared_pool_id,
            "online_virtual_cpus": updatedIbmDataString.iloc[ibmIndex-1].online_virtual_cpus,
            "maximum_physical_cpus_in_system": updatedIbmDataString.iloc[ibmIndex-1].maximum_physical_cpus_in_system,
            "active_physical_cpus_in_system": updatedIbmDataString.iloc[ibmIndex-1].active_physical_cpus_in_system,
            "shared_physical_cpus_in_system": updatedIbmDataString.iloc[ibmIndex-1].shared_physical_cpus_in_system,
            "notes": updatedIbmDataString.iloc[ibmIndex-1].notes,
            "company": company_name
        })
        ibmCollection.insert_one(ibmObject)
    
    #vmware data insert
    vmData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="virtualMachineSchema")
    vmDataString = vmData.astype(str)
    updatedVmDataString = vmDataString.replace({str(nan): None})
    vmRefList = vmData['Ref_ID#'].values
    vmCollection = db.vmachines

    for vmIndex in vmRefList:
        vmObject = ({
            "vm_host_name": updatedVmDataString.iloc[vmIndex-1].vm_host_name,
            "virtual_server_name": updatedVmDataString.iloc[vmIndex-1].virtual_server_name,
            "vm_guest_host_name": updatedVmDataString.iloc[vmIndex-1].vm_guest_host_name,
            "vm_guest_os": updatedVmDataString.iloc[vmIndex-1].vm_guest_os,
            "vm_ip_address": updatedVmDataString.iloc[vmIndex-1].vm_ip_address,
            "company": company_name
        })
        vmCollection.insert_one(vmObject)

    
    #check if company has vcenters
    #vcenterData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="vcenterSchema")
    #if not vcenterData.empty:
        #vCenterGenerator(vcenterData)


def vCenterGenerator(vcenterData):
    print('hello')


def getOptionsList(options_in_use, collectionType):
    if(collectionType == "database"):
        optionsData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="optionSchema")
    else:
        optionsData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="MiddlewareOptionsSchema")
    optionsDataString = optionsData.astype(str)
    updatedOptionsDataString = optionsDataString.replace({str(nan): None})
    refList = optionsData['Ref_ID#'].values

    optionsList = []
    for option in options_in_use:
        for optionIndex in refList:
            if (int(option) == optionIndex):
                optionsList.append({
                    "_id": ObjectId(),
                    "option_in_use": updatedOptionsDataString.iloc[optionIndex-1].option_in_use,
                    "start_date": updatedOptionsDataString.iloc[optionIndex-1].start_date,
                    "end_date": updatedOptionsDataString.iloc[optionIndex-1].end_date
                })
    return (optionsList)

def getManagementList(managements_in_use, collectionType):
    if (collectionType == "database"):
        managementData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="managementSchema")
    else:
        managementData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="MiddlewareManagmentSchema")

    managementDataString = managementData.astype(str)
    updatedManagementDataString = managementDataString.replace({str(nan): None})
    refList = managementData['Ref_ID#'].values

    managementsList = []
    for management in managements_in_use:
        for managementIndex in refList:
            if (int(management) == managementIndex):
                managementsList.append({
                    "_id": ObjectId(),
                    "managements_in_use": updatedManagementDataString.iloc[managementIndex-1].managements_in_use,
                    "start_date": updatedManagementDataString.iloc[managementIndex-1].start_date,
                    "end_date": updatedManagementDataString.iloc[managementIndex-1].end_date
                })
    return (managementsList)

def databaseGenerator(db, companyOid):
    print('start database generator')

    databaseCollection = db.dbs
    hardwareCollection = db.hardwares

    databaseData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="DbSchema")
    hardwareData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="HardwareSchema")
    databaseDataString = databaseData.astype(str)
    updatedDatabaseDataString = databaseDataString.replace({str(nan): None})
    finalUpdateDatabaseData = updatedDatabaseDataString.replace({'NaT':None})
    print(updatedDatabaseDataString['installation_date'])
    refDatabaseList = databaseData['Ref_ID#'].values
    refHardwareList = hardwareData['Ref_ID#'].values

    for databaseIndex in refDatabaseList:
        #check if there are any options or management packs in use if there are then to call another functions to get the details
        if (updatedDatabaseDataString.iloc[databaseIndex-1].options_in_use):
            options_in_use = updatedDatabaseDataString.iloc[databaseIndex-1].options_in_use.split(',')
            optionsList = getOptionsList(options_in_use, "database")
        else:
             optionsList = None
        if (updatedDatabaseDataString.iloc[databaseIndex-1].managements_in_use):
            managements_in_use = updatedDatabaseDataString.iloc[databaseIndex-1].managements_in_use.split(',')
            managementList = getManagementList(managements_in_use, "database")
        else:
            managementList = None
        if (finalUpdateDatabaseData.iloc[databaseIndex-1].installation_date != None):
            formatted_installation_date = datetime.strptime(updatedDatabaseDataString.iloc[databaseIndex-1].installation_date, "%Y-%m-%d")
        else:
            formatted_installation_date = None

        for hardwareIndex in refHardwareList:
            if (int(hardwareIndex) == int(updatedDatabaseDataString.iloc[databaseIndex-1].physical_server_name)):
                server_name = hardwareData.iloc[hardwareIndex-1].server_name
                hardwareCursor = hardwareCollection.find({"server_name": server_name}, {"_id":1})
                hardwareOid = getHardwareId(hardwareCursor)
                databaseObj = ({
                    "database_instance_name": updatedDatabaseDataString.iloc[databaseIndex-1].database_instance_name,
                    "physical_server_name": ObjectId(hardwareOid),
                    "virtual_server_name": updatedDatabaseDataString.iloc[databaseIndex-1].virtual_server_name,
                    "pluggable_databases": updatedDatabaseDataString.iloc[databaseIndex-1].pluggable_databases,
                    "environment_usage": updatedDatabaseDataString.iloc[databaseIndex-1].environment_usage,
                    "options_in_use": optionsList,
                    "managements_in_use": managementList,
                    "rac_nodes": updatedDatabaseDataString.iloc[databaseIndex-1].rac_nodes,
                    "fal_server": updatedDatabaseDataString.iloc[databaseIndex-1].fal_server,
                    "fal_client": updatedDatabaseDataString.iloc[databaseIndex-1].fal_client,
                    "cpu_count": updatedDatabaseDataString.iloc[databaseIndex-1].cpu_count,
                    "cpu_count_default": updatedDatabaseDataString.iloc[databaseIndex-1].cpu_count_default,
                    "installation_date": formatted_installation_date,
                    "users_defined": updatedDatabaseDataString.iloc[databaseIndex-1].users_defined,
                    "product_edition": updatedDatabaseDataString.iloc[databaseIndex-1].product_edition,
                    "product_version": updatedDatabaseDataString.iloc[databaseIndex-1].product_version,
                    "control_management_pack_access": updatedDatabaseDataString.iloc[databaseIndex-1].control_management_pack_access,
                    "current_sessions": updatedDatabaseDataString.iloc[databaseIndex-1].current_sessions,
                    "highwater_sessions": updatedDatabaseDataString.iloc[databaseIndex-1].highwater_sessions,
                    "database_cloned_from": updatedDatabaseDataString.iloc[databaseIndex-1].database_cloned_from,
                    "database_cloned_date": updatedDatabaseDataString.iloc[databaseIndex-1].database_cloned_date,
                    "application_name": updatedDatabaseDataString.iloc[databaseIndex-1].application_name,
                    "application_vendor": updatedDatabaseDataString.iloc[databaseIndex-1].application_vendor,
                    "application_type": updatedDatabaseDataString.iloc[databaseIndex-1].application_type,
                    "architecture_type": updatedDatabaseDataString.iloc[databaseIndex-1].architecture_type,
                    "user_type": updatedDatabaseDataString.iloc[databaseIndex-1].user_type,
                    "web_or_app_tier_server_name": updatedDatabaseDataString.iloc[databaseIndex-1].web_or_app_tier_server_name,
                    "ebs_release": updatedDatabaseDataString.iloc[databaseIndex-1].ebs_release,
                    "virtualisation_tech": updatedDatabaseDataString.iloc[databaseIndex-1].virtualisation_tech,
                    "end_user": ObjectId(companyOid),
                })
                databaseCollection.insert_one(databaseObj)
    print('end database generator')

def hardwareGenerator(db, companyOid, company_name):
    print('start hardware generator')
    hardwareCollection = db.hardwares
    hardwareData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="HardwareSchema")
    updatedHardwareData = hardwareData.astype(str)
    updateupdatedHardwareData = updatedHardwareData.replace({str(nan): None})
    refHardwareList = hardwareData['Ref_ID#']
    hardwareList = []

    refIbmList = updateupdatedHardwareData['ibm_virt']
    refOvmList = updateupdatedHardwareData['ovm_virt']
    refVmList = updateupdatedHardwareData['vmware_virt']
    ibmLparOidList = []
    ovmOidList = []
    vmOidList = []

    ibmCollection = db.ibmlpars
    ibmCursor = ibmCollection.find({'company': company_name}, {'_id': 1})
    for ibmlparId in ibmCursor:
        ibmlparStr = str(ibmlparId)
        ibmlparOid = ibmlparStr[18:len(ibmlparStr)-3]
        ibmLparOidList.append(ibmlparOid)

    ovmCollection = db.ovms
    ovmCursor = ovmCollection.find({'company': company_name}, {'_id':1})
    for ovmId in ovmCursor:
        ovmStr = str(ovmId)
        ovmOid = ovmStr[18:len(ovmStr)-3]
        ovmOidList.append(ovmOid)
    
    vmCollection = db.vmachines
    vmCursor = vmCollection.find({'company': company_name}, {'_id':1})
    for vmId in vmCursor:
        vmStr = str(vmId)
        vmOid = vmStr[18:len(vmStr)-3]
        vmOidList.append(vmOid)

    for hardwaresIndex in refHardwareList:
        ibmOidList = []
        ovmHardwareList = []
        vmHardwareList = []
        if (refIbmList[hardwaresIndex-1] != None):
            indexList = refIbmList[hardwaresIndex-1].split(',')
            for index in indexList:
                ibmOidList.append(ObjectId(ibmLparOidList[int(index)-1]))
        if (refOvmList[hardwaresIndex-1] != None):
            ovmIndexList = refOvmList[hardwaresIndex-1].split(',')
            for ovmIndex in ovmIndexList:
                ovmHardwareList.append(ObjectId(ovmOidList[int(ovmIndex)-1]))
        if (refVmList[hardwaresIndex-1] != None):
            vmIndexList = refVmList[hardwaresIndex-1].split(',')
            for vmIndex in vmIndexList:
                vmHardwareList.append(ObjectId(vmOidList[int(vmIndex)-1]))

        hardwareList.append({
            'cluster_id': updateupdatedHardwareData.loc[hardwaresIndex-1].cluster_id,
            'company': ObjectId(companyOid),
            'server_name': updateupdatedHardwareData.loc[hardwaresIndex-1].server_name,
            'server_model': updateupdatedHardwareData.loc[hardwaresIndex-1].server_model,
            'virtualisation_name': updateupdatedHardwareData.loc[hardwaresIndex-1].virtualisation_name,
            'virtualisation_description': updateupdatedHardwareData.loc[hardwaresIndex-1].virtualisation_description,
            'operating_system': updateupdatedHardwareData.loc[hardwaresIndex-1].operating_system,
            'processor_model': updateupdatedHardwareData.loc[hardwaresIndex-1].processor_model,
            'processors': updateupdatedHardwareData.loc[hardwaresIndex-1].processors,
            'cores_per_processor': updateupdatedHardwareData.loc[hardwaresIndex-1].cores_per_processor,
            'total_physical_cores': updateupdatedHardwareData.loc[hardwaresIndex-1].total_physical_cores,
            'cores_enabled': updateupdatedHardwareData.loc[hardwaresIndex-1].cores_enabled,
            'threads_per_core': updateupdatedHardwareData.loc[hardwaresIndex-1].threads_per_core,
            'multi_core_chip_or_multi_chip_model': updateupdatedHardwareData.loc[hardwaresIndex-1].multi_core_chip_or_multi_chip_model,
            'processor_speed': updateupdatedHardwareData.loc[hardwaresIndex-1].processor_speed,
            'server_purchase_date': updateupdatedHardwareData.loc[hardwaresIndex-1].server_purchase_date,
            'server_location': updateupdatedHardwareData.loc[hardwaresIndex-1].server_location,
            'commission_date': updateupdatedHardwareData.loc[hardwaresIndex-1].commission_date,
            'decommission_date': updateupdatedHardwareData.loc[hardwaresIndex-1].decommission_date,
            'hardware_refresh_term_or_date': updateupdatedHardwareData.loc[hardwaresIndex-1].hardware_refresh_term_or_date,
            'license_allocated_to_server': updateupdatedHardwareData.loc[hardwaresIndex-1].license_allocated_to_server,
            'ibm_virt': ibmOidList,
            'ovm_virt': ovmHardwareList,
            'xen_virt': updateupdatedHardwareData.loc[hardwaresIndex-1].xen_virt,
            'vmware_virt': vmHardwareList,
            'solaris_virt': updateupdatedHardwareData.loc[hardwaresIndex-1].solaris_virt,
            'kvm_virt': updateupdatedHardwareData.loc[hardwaresIndex-1].kvm_virt,
            'other_virt': updateupdatedHardwareData.loc[hardwaresIndex-1].other_virt,
            'aws_cloud': updateupdatedHardwareData.loc[hardwaresIndex-1].aws_cloud,
            'azure_cloud': updateupdatedHardwareData.loc[hardwaresIndex-1].azure_cloud,
            'oracle_cloud': updateupdatedHardwareData.loc[hardwaresIndex-1].oracle_cloud,
            'di_cloud': updateupdatedHardwareData.loc[hardwaresIndex-1].di_cloud,
            'other_cloud': updateupdatedHardwareData.loc[hardwaresIndex-1].other_cloud
        })
    hardwareCollection.insert_many(hardwareList)
    #hardwareSubDocumentGenerator(db, companyOid, hardwareList, company_name)
    print('end hardware generator')

def getHardwareId(hardwareCursor):
    for hardware in hardwareCursor:
        hardwareStr = str(hardware)
        hardwareOid = hardwareStr[18:len(hardwareStr)-3]
        return (hardwareOid)

def findContractId(db, contractIndex):
    contractData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="ContractSchema")
    updatedContractData = contractData.astype(str)
    updateUpdatedContractData = updatedContractData.replace({str(nan): None})

    customer_support_identifier = updateUpdatedContractData.iloc[int(contractIndex)-1].customer_support_identifier
    contractCollection = db.contracts
    contractCursor = contractCollection.find({"customer_support_identifier": customer_support_identifier}, {'_id':1})
    for contract in contractCursor:
        contractStr = str(contract)
        contractOid = contractStr[18:len(contractStr)-3]
        return (contractOid)

def findProductLicId(db, productLicIndex, company_name):
    productLicsData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="OracleLicenseSchema")
    updatedLicData = productLicsData.astype(str)
    updatedUpdatedLicData = updatedLicData.replace({str(nan): None})

    product_name = updatedUpdatedLicData.iloc[int(productLicIndex)-1].product_name
    productLicCollection = db.oraclelicenses
    productLicCursor = productLicCollection.find({"$and":[{"company": company_name}, {"product_name": product_name}]}, {'_id':1})

    for productLic in productLicCursor:
        productLicStr = str(productLic)
        productOid = productLicStr[18:len(productLicStr)-3]
        return (productOid)

def hardwareSubDocumentGenerator(db, companyOid, hardwareList, company_name):
    print('Start hardware sub document generator')
    hardwareCollection = db.hardwares
    licsAllCollection = db.licensesallocateds

    licsAllocatedData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="licenseSchema")
    updatedLicsAllocatedData = licsAllocatedData.astype(str)
    updateUpdatedLicsAllocatedData = updatedLicsAllocatedData.replace({str(nan): None})

    for hardwareIndex in hardwareList:
        licsList = hardwareIndex['license_allocated_to_server'].split(',')
        server_name = hardwareIndex['server_name']
        hardwareCursor = hardwareCollection.find({"server_name": server_name}, {'_id':1})
        hardwareOid = getHardwareId(hardwareCursor)

        for licIndex in licsList:
            contractOid = findContractId(db, updateUpdatedLicsAllocatedData.iloc[int(licIndex)-1].contract_linked)
            productOid = findProductLicId(db, updateUpdatedLicsAllocatedData.iloc[int(licIndex)-1].product_licensed, company_name)
            hardwaresLicsList = ({
                "license_metric_allocated": updateUpdatedLicsAllocatedData.iloc[int(licIndex)-1].license_metric_allocated,
                "restricted_use": updateUpdatedLicsAllocatedData.iloc[int(licIndex)-1].restricted_use,
                "number_of_licenses_in_use": updateUpdatedLicsAllocatedData.iloc[int(licIndex)-1].number_of_licenses_in_use,
                "virtualisation_linked": ObjectId(hardwareOid),
                "contract_linked": ObjectId(contractOid),
                "product_licensed": ObjectId(productOid),
                "company": company_name
            })
            licsAllCollection.insert_one(hardwaresLicsList)
            licsAllCursor = licsAllCollection.find({"virtualisation_linked": ObjectId(hardwareOid)}, {'_id':1})
            licsAllOidList = getLicsAllId(licsAllCursor)
            hardwareCollection.update_one({"_id": ObjectId(hardwareOid)}, {"$set":{"license_allocated_to_server": licsAllOidList}})
    print('End hardware sub document generator')

def getLicsAllId(licsAllCursor):
    licsAllList = []
    for licsAll in licsAllCursor:
        licsAllStr = str(licsAll)
        licsAllOid = licsAllStr[18:len(licsAllStr)-3]
        licsAllList.append(ObjectId(licsAllOid))

    return (licsAllList)


def contractJSONGenerator (db, company_name):
    print('Start Contract Generator')

    nstCollection = db.nonstandardterms
    supportCollection = db.supportContracts
    licensesCollection = db.oraclelicenses
    contractCollection = db.contracts
    companyCollection = db.comps

    companyCursor = companyCollection.find({"company_name": company_name}, {'_id':1})
    for companyId in companyCursor:
        companyStr = str(companyId)
        companyOid = companyStr[18:len(companyStr)-3]

    licCursor = licensesCollection.find({"company": company_name}, {'_id':1})
    nstCursor = nstCollection.find({"company": company_name}, {'_id':1})
    supportCursor = supportCollection.find({"company": company_name}, {'_id':1})

    licIdList = []
    nstIdList = []
    supportIdList = []


    contractSchema = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="ContractSchema", dtype={'customer_support_identifier': str})

    refContractList = contractSchema['Ref_ID#'].values
    refContractLicensesList = contractSchema['oracle_licenses']
    refContractNstList = contractSchema['non_standard_terms']
    refContractSupportList = contractSchema['support_contract']

    updatedContractSchema = contractSchema.astype(str)
    updateUpdatedContractSchema = updatedContractSchema.replace({str(nan): None})

    # loop through all the created sub documents to attach the oid to the contract
    for document in licCursor:
        oidStr = str(document)
        oid = oidStr[18:len(oidStr)-3]
        licIdList.append(oid)
    for document in nstCursor:
        oidStr = str(document)
        oid = oidStr[18:len(oidStr)-3]
        nstIdList.append(oid)
    for document in supportCursor:
        oidStr = str(document)
        oid = oidStr[18:len(oidStr)-3]
        supportIdList.append(oid)

    for contractIndex in refContractList:
        licList = []
        nstList = []
        supportList = []
        if (len(licIdList) > 0):
            lics = refContractLicensesList.iloc[contractIndex-1]
            li = str(lics).split(',')
            licOlicIdList = li[0: len(li)]
            for i in licOlicIdList:
                licList.append(ObjectId(licIdList[int(i)-1]))
        if (len(nstIdList) > 0):
            nsts = refContractNstList.iloc[contractIndex-1]
            nst = str(nsts).split(',')
            nstOidList = nst[0: len(nst)]
            for i in nstOidList:
                nstList.append(ObjectId(nstIdList[int(i)-1]))
        if (len(supportIdList) > 0):
            supports = refContractSupportList.iloc[contractIndex-1]
            support = str(supports).split(',')
            supportOidList = support[0: len(support)]
            for i in supportOidList:
                supportList.append(ObjectId(supportIdList[int(i)-1]))
        contractObj = ({
            "order_identifier": updateUpdatedContractSchema.iloc[contractIndex-1].order_identifier,
            "customer_support_identifier": updateUpdatedContractSchema.iloc[contractIndex-1].customer_support_identifier,
            "contract_date": updateUpdatedContractSchema.iloc[contractIndex-1].contract_date,
            "contract_territory": updateUpdatedContractSchema.iloc[contractIndex-1].contract_territory,
            "contract_terminated": json.loads(updateUpdatedContractSchema.iloc[contractIndex-1].contract_terminated.lower()), # json.loads for handling boolean values since we convert everything to string
            "total_capex_cost_of_contract": updateUpdatedContractSchema.iloc[contractIndex-1].total_capex_cost_of_contract,
            "signed_by": updateUpdatedContractSchema.iloc[contractIndex-1].signed_by,
            "signed_by_date": updateUpdatedContractSchema.iloc[contractIndex-1].signed_by_date,
            "contract_upload": updateUpdatedContractSchema.iloc[contractIndex-1].contract_upload,
            "contract_type": updateUpdatedContractSchema.iloc[contractIndex-1].contract_type,
            "contract_imagepath": updateUpdatedContractSchema.iloc[contractIndex-1].contract_imagepath,
            "oracle_licenses": licList,
            "end_user": ObjectId(companyOid)
        })
        contractCollection.insert_one(contractObj)
    print('End Contract Generator')


def contractSubDocumentJSONGenerator(db, company_name):
    print('Start Sub Contract Document Generator')

    nstCollection = db.nonstandardterms
    supportContractCollection = db.supportContracts
    oracleLicsCollection = db.oraclelicenses

    nonStandardTermsSchema = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="NonStandardTermsSchema")
    oracleLicenseSchema = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="OracleLicenseSchema")
    supportContractSchema = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="SupportContractSchema")

    refSupportList = supportContractSchema['Ref_ID#']
    refLicList = oracleLicenseSchema['Ref_ID#']
    refNonStList = nonStandardTermsSchema['Ref_ID#']

    updatedNonSTSchema = nonStandardTermsSchema.set_index("Ref_ID#")
    updatedNonSTSchema = updatedNonSTSchema.astype(str)
    updateUpdatedNonSTSchema = updatedNonSTSchema.replace({str(nan): None})

    updatedSupSchema = supportContractSchema.set_index("Ref_ID#")
    updatedSupSchema = updatedSupSchema.astype(str)
    updateUpdatedSupSchema = updatedSupSchema.replace({str(nan): None})

    updatedLicSchema = oracleLicenseSchema.set_index("Ref_ID#")
    updatedLicSchema = updatedLicSchema.astype(str)
    updatedUpdatedLicSchema = updatedLicSchema.replace({str(nan): None})
    finalUpdateLicData = updatedUpdatedLicSchema.replace({'NaT':None})



    for k in refNonStList:
        nonSTObj = ({
            "term_name": updateUpdatedNonSTSchema.loc[k].term_name,
            "term_description": updateUpdatedNonSTSchema.loc[k].term_description,
            "term_filepaths": updateUpdatedNonSTSchema.loc[k].term_filepaths,
            "company": company_name
        })
        nstCollection.insert_one(nonSTObj)

    for j in refSupportList:
        supportObj = ({
          "support_contract_number": updateUpdatedSupSchema.loc[j].support_contract_number,
          "support_start_date": updateUpdatedSupSchema.loc[j].support_start_date,
          "support_end_date": updateUpdatedSupSchema.loc[j].support_end_date,
          "support_term": updateUpdatedSupSchema.loc[j].support_term,
          "support_offer_expiration": updateUpdatedSupSchema.loc[j].support_offer_expiration,
          "support_representive": updateUpdatedSupSchema.loc[j].support_representive,
          "support_service_number": updateUpdatedSupSchema.loc[j].support_service_number,
          "total_price": updateUpdatedSupSchema.loc[j].total_price,
          "currency": updateUpdatedSupSchema.loc[j].currency,
          "line_price": updateUpdatedSupSchema.loc[j].line_price,
          "support_filepaths": updateUpdatedSupSchema.loc[j].support_filepaths,
          "company": company_name
        })
        supportContractCollection.insert_one(supportObj)

    for i in refLicList:
        if (finalUpdateLicData.loc[i].support_end_date != None):
            support_end_date = datetime.strptime(finalUpdateLicData.loc[i].support_end_date, "%Y-%m-%d")
        else:
            support_end_date = None
        licensesObj = ({
            "product_name": finalUpdateLicData.loc[i].product_name,
            "quantity": finalUpdateLicData.loc[i].quantity,
            "metric": finalUpdateLicData.loc[i].metric,
            "term": finalUpdateLicData.loc[i].term,
            "license_type": finalUpdateLicData.loc[i].license_type,
            "restrictions": finalUpdateLicData.loc[i].restrictions,
            "license_notes": finalUpdateLicData.loc[i].license_notes,
            "support_status": finalUpdateLicData.loc[i].support_status,
            "support_end_date": support_end_date,
            "unit_price": finalUpdateLicData.loc[i].unit_price,
            "total_cost": finalUpdateLicData.loc[i].total_cost,
            "discount": finalUpdateLicData.loc[i].discount,
            "allowed": finalUpdateLicData.loc[i].allowed,
            "allocated": finalUpdateLicData.loc[i].allocated,
            "company": company_name
        })
        oracleLicsCollection.insert_one(licensesObj)
    print('End Sub Contract Document Generator')


def companyJSONGenerator (db, companySchema):
    print('Start Company Generator')
    companyCollection = db.comps

    endUserData = pd.read_excel (r'C:\Users\scmilne\Documents\OLA Dataset for Chubb.xlsx', sheet_name="EndUserContactSchema")
    endUserDataStr = endUserData.astype(str)
    updatedEndUserData = endUserDataStr.replace({str(nan): None})
    #iloc function for rows by numerical index
    #loc function for rows by label

    companySchema2str = companySchema.astype(str)
    convertedCompanySchema = companySchema2str.replace({str(nan): None})
    companyObj = {
        "company_name": convertedCompanySchema.company_name.iloc[0],
        "hq_location": convertedCompanySchema.hq_location.iloc[0],
        "end_user_contacts": [],
        "end_user_subsidiaries": [],
        "oma_reference_number": convertedCompanySchema.oma_reference_number.iloc[0],
        "vad_name": convertedCompanySchema.vad_name.iloc[0],
        "vad_contact":convertedCompanySchema.vad_contact.iloc[0]
    }
    for endUserIndex in updatedEndUserData['Ref_ID#']:
        companyObj.get('end_user_contacts').append({
            '_id': ObjectId(),
            'end_user_name': updatedEndUserData.iloc[int(endUserIndex)-1].end_user_name,
            'end_user_role': updatedEndUserData.iloc[int(endUserIndex)-1].end_user_role,
            'end_user_type': updatedEndUserData.iloc[int(endUserIndex)-1].end_user_type,
            'end_user_pnumber': updatedEndUserData.iloc[int(endUserIndex)-1].end_user_pnumber,
            'end_user_email': updatedEndUserData.iloc[int(endUserIndex)-1].end_user_email,
            'end_user_location': updatedEndUserData.iloc[int(endUserIndex)-1].end_user_location
        })
    companyCollection.insert_one(companyObj)
    print('End Company Generator')

main() 
