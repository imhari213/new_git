export const environment = {
  production: true,
 // apiUrl: 'http://localhost:3000/'
  apiUrl: ' http://35.239.86.112:3000/'
  
 
};
