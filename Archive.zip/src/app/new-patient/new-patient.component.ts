import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common'
import { PatientService } from '../services/patients.service'
import { Router } from '@angular/router';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-new-patient',
  templateUrl: './new-patient.component.html',
  styleUrls: ['./new-patient.component.css']
})
export class NewPatientComponent implements OnInit {

  model: NgbDateStruct;
  newPatientForm: FormGroup;
  date = new Date;
  constructor(private formBuilder: FormBuilder,
    private _location: Location,
    private patientService: PatientService,
    private router: Router) {

    this.newPatientForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      gender: ['', Validators.required],
      age: ['', Validators.required],
      date: ['', Validators.required],
      occupation: ['', Validators.required],
      address: ['', Validators.required],
      contact: ['', Validators.required],
      kco: ['', Validators.required],
      payment: ['', Validators.required],
      pastHistory: ['', Validators.required],
      appetite: ['', Validators.required],
      thirst: ['', Validators.required],
      desires: ['', Validators.required],
      aversion: ['', Validators.required],
      micturation: ['', Validators.required],
      bowels: ['', Validators.required],
      sleep: ['', Validators.required],
      thermals: ['', Validators.required],
      menses: ['', Validators.required],
      mentalGenerals: ['', Validators.required],
      familyHistory: ['', Validators.required],
      reports: ['', Validators.required],
      diagnosis: ['', Validators.required],
      co: ['', Validators.required],
      vitals: ['', Validators.required],
      rx: ['', Validators.required]
    })

  }



  ngOnInit(): void {
  }

  get f() { return this.newPatientForm.controls; }


  createPatient() {

  

  

    let patientData = {
      "firstName": this.f.firstName.value,
      "lastName": this.f.lastName.value,
      "gender": this.f.gender.value,
      "age": this.f.age.value,
      "date": new Date(),
      "occupation": this.f.occupation.value,
      "address": this.f.address.value,
      "contact": this.f.contact.value,
      "kco": this.f.kco.value,
      "payment": this.f.payment.value,
      "pastHistory": this.f.pastHistory.value,
      "appetite": this.f.appetite.value,
      "thirst": this.f.thirst.value,
      "desires": this.f.desires.value,
      "aversion": this.f.aversion.value,
      "micturation": this.f.micturation.value,
      "bowels": this.f.bowels.value,
      "sleep": this.f.sleep.value,
      "thermals": this.f.thermals.value,
      "menses": this.f.menses.value,
      "mentalGenerals": this.f.mentalGenerals.value,
      "familyHistory": this.f.familyHistory.value,
      "reports": this.f.reports.value,
      "diagnosis": this.f.diagnosis.value,
      "co": this.f.co.value,
      "vitals": this.f.vitals.value,
      "rx": this.f.rx.value
    }

   

    this.patientService.createPatient(patientData).subscribe(response => {
      console.log(response);
      this.router.navigate(['/dashboard'])
    }, error => {
      console.log(error);
    })

  }


  goBack() {
    this._location.back();
  }



}
