import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  closeResult = '';
  loggedIn: boolean;
  modalStatus: boolean;

  constructor(private modalService: NgbModal,
    private router: Router,) {}

ngOnInit(): void {

  this.modalStatus = false;
  if (localStorage.getItem('user') == null) {
    this.loggedIn = false;
  } else {
    this.loggedIn = true;
  }

}

home(){
  console.log("in");
  debugger;
  this.router.navigate(['/dashboard'])
}

goToAdmin(){
  this.modalService.dismissAll();
  this.router.navigate(['/admin'])
}


logout(){
  this.modalService.dismissAll();
  localStorage.clear();
  window.location.href = '/login';
 // this.router.navigate(['/login'])
}


open(content) {
  this.modalStatus = true;
  console.log("modal open");
  this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
      console.log(reason);
      this.modalStatus = false;
  });
}

 

}
