import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ErrorHandlingComponent } from './error-handling/error-handling.component';
import { NewPatientComponent } from './new-patient/new-patient.component';
import { EditPatientComponent } from './edit-patient/edit-patient.component'
import { AuthGuardService as AuthGuard  } from './services/authguard.service';
import { AdminComponent } from '../app/admin/admin.component'

const routes: Routes = [

  {path:'login',component:LoginComponent},
  // {path: '**', redirectTo: 'login'},
  {path:'', redirectTo: 'login', pathMatch: 'full' },
  {path:'dashboard',component:DashboardComponent, canActivate: [AuthGuard]},
  {path:'error',component:ErrorHandlingComponent},
  {path: 'newPatient', component:NewPatientComponent, canActivate: [AuthGuard]},
  {path: 'editPatient', component:EditPatientComponent, canActivate: [AuthGuard]},
  {path: 'admin', component:AdminComponent, canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

  
}
