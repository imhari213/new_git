import { Component, OnInit } from '@angular/core';
import { PatientService } from '../services/patients.service'
import { SharedDataService } from '../services/shared.data.service'
import {Router} from '@angular/router';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  patientsData : any;
 
  constructor(private patients: PatientService,
              private sharedData: SharedDataService,
              private router: Router)
               { }

  search(e){
     console.log(e.target.value);
  }

  ngOnInit(): void {
    this.getPatients();
  }

  newPatient(){
    this.router.navigate(['/newPatient'])
  }

  editPatient(patient){
    this.sharedData.setPatientData(patient)
    this.router.navigate(['/editPatient'])
   

  }




  getPatients() {
    this.patients.getPatients().subscribe(res => {
      this.patientsData = res.result;
      console.log(this.patientsData);
    }, err => {
      console.log(err);
    })

  }

}
