import { Component, OnInit } from '@angular/core';
import { PatientService } from '../services/patients.service'
import { SharedDataService } from '../services/shared.data.service'
import {Router} from '@angular/router';
import {Observable} from 'rxjs';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner";

const states = ['Alabama', 'Alaska', 'American Samoa', 'Arizona', 'Arkansas', 'California', 'Colorado',
  'Connecticut', 'Delaware', 'District Of Columbia', 'Federated States Of Micronesia', 'Florida', 'Georgia',
  'Guam', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine',
  'Marshall Islands', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana',
  'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
  'Northern Mariana Islands', 'Ohio', 'Oklahoma', 'Oregon', 'Palau', 'Pennsylvania', 'Puerto Rico', 'Rhode Island',
  'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virgin Islands', 'Virginia',
  'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  patientsData : any;
  public model: any;
  searchResults: any;
  constructor(private patients: PatientService,
              private sharedData: SharedDataService,
              private spinner: NgxSpinnerService,
              private router: Router)
               { }

  search(e){
     console.log(e,"***");
    if(e.target.value !== ''){
     let keyword = {
           keyWord : e.target.value
         }
     this.patients.searchPatient(keyword).subscribe(res => {
      this.searchResults = res.result;
      console.log(res);
      console.log(this.searchResults);
    }, err => {
      console.log(err);
    })
  }else{
    this.searchResults = [];
  }

  }

  // search = (text$: Observable<string>) =>

  // text$.pipe(
  //   debounceTime(200),
  //   distinctUntilChanged(),
  //   map(term => term.length < 2 ? []
  //     : states.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
  // )

  ngOnInit(): void {
    this.getPatients();
  }

  newPatient(){
    this.router.navigate(['/newPatient'])
  }

  editPatient(patient){
    this.sharedData.setPatientData(patient)
    this.router.navigate(['/editPatient'])
   

  }

 

  checkPayementtype(data){

    if(data == 'paid'){
      return true;
    }else{
      return false;
    }

  }



  getPatients() {
    this.spinner.show();
    this.patients.getPatients().subscribe(res => {
      this.spinner.hide();
      this.patientsData = res.result;
      console.log(this.patientsData);
    }, err => {
      this.spinner.hide();
      console.log(err);
    })

  }

}
