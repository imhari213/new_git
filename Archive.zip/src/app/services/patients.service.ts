import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment'

@Injectable({
    providedIn: 'root',
})

export class PatientService {

    constructor(private http: HttpClient) { }

    getPatients() {
        return this.http.get<any>(environment.apiUrl + 'users/getAllPatients')
    }

    getCount() {
        return this.http.get<any>(environment.apiUrl + 'users/patientsCount')
    }

    getDayCount(day){
        return this.http.post<any>(environment.apiUrl + 'users/findAllVisits',day)
    }

    searchPatient(key) {
        return this.http.post<any>(environment.apiUrl + 'users/findPatients',key)
    }

    getPatientDetails(patientId) {
        return this.http.post<any>(environment.apiUrl + 'users/getPatient',patientId)
    }

    createPatient(patientData){
        return this.http.post<any>(environment.apiUrl + 'users/createPatient',patientData)
    }

    updatePatient(patientData){
        return this.http.post<any>(environment.apiUrl + 'users/updatePatient',patientData)
    }

    deletePatient(patientData){
        return this.http.post<any>(environment.apiUrl + 'users/deletePatient',patientData)
    }

    deleteVisit(visitData){
        return this.http.post<any>(environment.apiUrl + 'users/deleteVisit',visitData)
    }

    addVisit(visitData){
        return this.http.post<any>(environment.apiUrl + 'users/addVisit',visitData)
    }
} 