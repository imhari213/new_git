import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from "rxjs";  

@Injectable({
    providedIn: 'root',
})

export class SharedDataService {


    private details = new BehaviorSubject('test');
    detailsToReturn:any;

    setPatientData(patient) {
        this.details.next(patient)
    }

    getPatients(){
            return<any> this.details.asObservable();
} 

   

}