import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import {Router} from '@angular/router'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  loginForm: FormGroup;
  message : any;

  constructor(private formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private authService: AuthenticationService,
    private router: Router
  ) { 
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })
  }

  ngOnInit() {
    //this.spinner.show();
  }



  get f() { return this.loginForm.controls; }

  

  login() {
    
    console.log(this.f.username.value);
    console.log(this.f.password.value);
    
  if(this.loginForm.valid){
  this.spinner.show();
    let userData = {
      "userName": this.f.username.value,
      "password": this.f.password.value
    }

    console.log(userData)

    this.authService.authenticate(userData).subscribe(res => {
      console.log(res.result);
      localStorage.setItem('user', JSON.stringify(res.result));
      debugger;
      this.spinner.hide();
      window.location.href = "/dashboard";
     // this.router.navigate(['/dashboard'])
    }, err => {
      console.log(err);
    })

  }else{
    this.message = "Please add correct credentials."
  }
}
}