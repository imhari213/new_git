import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common'
import { PatientService } from '../services/patients.service'
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  counts = {
    patients: '',
    visits: ''
  };
  day : any;
  searcDetails : any;
  model: NgbDateStruct;
  showSearchTable : boolean;
  constructor( private _location: Location,
    private patientService: PatientService,
    private spinner: NgxSpinnerService,
    private calendar: NgbCalendar) { }

  ngOnInit(): void {
    this.getCount()
    this.showSearchTable = false;
  }

  goBack() {
    this._location.back();
  }

  getDayDetails(){
    this.spinner.show();
    let selectedDate = this.day.day + "-" + this.day.month + "-" + this.day.year
    console.log(this.day);
    let day = {
      date:selectedDate
    }
    this.patientService.getDayCount(day).subscribe(response => {
      this.spinner.hide();
      console.log(response);
      this.showSearchTable = true;
      this.searcDetails = response.result.length;
    }, error => {
      this.spinner.hide();
      console.log(error);
    })
  }

  getCount(){
    this.spinner.show();
    this.patientService.getCount().subscribe(response => {
      this.spinner.hide();
      this.counts.patients = response.patientsCount;
      this.counts.visits = response.visitCount;
      console.log(this.counts);
    }, error => {
      this.spinner.hide();
      console.log(error);
    })
  }

}
