import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common'
import { SharedDataService } from '../services/shared.data.service'
import { PatientService } from '../services/patients.service'
import { Router } from '@angular/router';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-edit-patient',
  templateUrl: './edit-patient.component.html',
  styleUrls: ['./edit-patient.component.css']
})
export class EditPatientComponent implements OnInit {

  model: NgbDateStruct;
  newPatientForm: FormGroup;
  //date: {year: number, month: number};
  today = this.calendar.getToday();
  editPatientForm: FormGroup;
  visitForm: FormGroup;
  patientDetails: any;
  patientVisits: any;
  addVisitForm = false;
  visitData: any;

  constructor(private formBuilder: FormBuilder,
    private _location: Location,
    private sharedData: SharedDataService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private patientService: PatientService,
    private calendar: NgbCalendar) {

    this.visitForm = this.formBuilder.group({
      co: ['', Validators.required],
      vitals: ['', Validators.required],
      rx: ['', Validators.required],
      visitDate: ['', Validators.required]
    })

    this.editPatientForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      gender: ['', Validators.required],
      age: ['', Validators.required],
      date: ['', Validators.required],
      occupation: ['', Validators.required],
      address: ['', Validators.required],
      contact: ['', Validators.required],
      kco: ['', Validators.required],
      payment: ['', Validators.required],
      pastHistory: ['', Validators.required],
      appetite: ['', Validators.required],
      thirst: ['', Validators.required],
      desires: ['', Validators.required],
      aversion: ['', Validators.required],
      micturation: ['', Validators.required],
      bowels: ['', Validators.required],
      sleep: ['', Validators.required],
      thermals: ['', Validators.required],
      menses: ['', Validators.required],
      mentalGenerals: ['', Validators.required],
      familyHistory: ['', Validators.required],
      reports: ['', Validators.required],
      diagnosis: ['', Validators.required]
      // co: ['', Validators.required],
      // vitals: ['', Validators.required],
      // rx: ['', Validators.required]
    })

  }

  ngOnInit(): void {


    this.sharedData.getPatients().subscribe(res => {
     
      let patientDetails = {
        "patientId": res.patientId
      }
      console.log(res, "******");
      if (res == false) {
        this.router.navigate(['/dashboard'])
      } else {
        this.spinner.show();
        this.patientService.getPatientDetails(patientDetails).subscribe(patient => {

          this.spinner.hide();

          this.patientDetails = patient.result;
          this.patientVisits = patient.result.visits;
          console.log(this.patientVisits, "*****");
          let transFormDate = this.patientDetails.date.split("-")
          let convertedDate = { 'year': parseInt(transFormDate[2]), 'month': parseInt(transFormDate[1]), 'day': parseInt(transFormDate[0]) }

          console.log(convertedDate);
          this.editPatientForm.patchValue({
            firstName: this.patientDetails.firstName,
            lastName: this.patientDetails.lastName,
            gender: this.patientDetails.gender,
            age: this.patientDetails.age,
            date: convertedDate,
            occupation: this.patientDetails.occupation,
            address: this.patientDetails.address,
            contact: this.patientDetails.contact,
            kco: this.patientDetails.kco,
            payment: this.patientDetails.payment,
            pastHistory: this.patientDetails.pastHistory,
            appetite: this.patientDetails.appetite,
            thirst: this.patientDetails.thirst,
            desires: this.patientDetails.desires,
            aversion: this.patientDetails.aversion,
            micturation: this.patientDetails.micturation,
            bowels: this.patientDetails.bowels,
            sleep: this.patientDetails.sleep,
            thermals: this.patientDetails.thermals,
            menses: this.patientDetails.menses,
            mentalGenerals: this.patientDetails.mentalGenerals,
            familyHistory: this.patientDetails.familyHistory,
            reports: this.patientDetails.reports,
            diagnosis: this.patientDetails.diagnosis
          })

          console.log(this.editPatientForm);
        }, err => {
          this.spinner.hide();
          console.log(err);
        })
      }
    })
  }

  get f() { return this.editPatientForm.controls; }

  get v() { return this.visitForm.controls; }

  goBack() {
    this._location.back();
  }

  updatePatient() {
    this.spinner.show();
    let selectedDate = this.f.date.value.day + "-" + this.f.date.value.month + "-" + this.f.date.value.year
    console.log(selectedDate);
    let patientData = {
      "patientId": this.patientDetails.patientId,
      "firstName": this.f.firstName.value,
      "lastName": this.f.lastName.value,
      "gender": this.f.gender.value,
      "age": this.f.age.value,
      "date": selectedDate,
      "occupation": this.f.occupation.value,
      "address": this.f.address.value,
      "contact": this.f.contact.value,
      "kco": this.f.kco.value,
      "payment": this.f.payment.value,
      "pastHistory": this.f.pastHistory.value,
      "appetite": this.f.appetite.value,
      "thirst": this.f.thirst.value,
      "desires": this.f.desires.value,
      "aversion": this.f.aversion.value,
      "micturation": this.f.micturation.value,
      "bowels": this.f.bowels.value,
      "sleep": this.f.sleep.value,
      "thermals": this.f.thermals.value,
      "menses": this.f.menses.value,
      "mentalGenerals": this.f.mentalGenerals.value,
      "familyHistory": this.f.familyHistory.value,
      "reports": this.f.reports.value,
      "diagnosis": this.f.diagnosis.value
    }

    console.log(patientData);

    this.patientService.updatePatient(patientData).subscribe(response => {
      console.log(response);
      this.spinner.hide();
      this.router.navigate(['/dashboard'])
    }, error => {
      this.spinner.hide();
      console.log(error);
    })

  }


  showVisitForm() {
    this.addVisitForm = true;
  }

  deleteVisit(visitData){

    this.spinner.show();
    let visit = {
      "id": visitData._id,
    }
    console.log(visit);
    this.patientService.deleteVisit(visit).subscribe(response => {
      this.spinner.hide();
        this.router.navigate(['/dashboard'])
    }, error => {
      this.spinner.hide();
      console.log(error);
    })

  }

  deletPatient() {
    this.spinner.show();
    let patient = {
      "patientId": this.patientDetails.patientId,
    }

    this.patientService.deletePatient(patient).subscribe(response => {
      for (let i = 0; i < this.patientVisits.length; i++) {
        let visit = {
          "id": this.patientVisits[i]._id,
        }
        this.patientService.deleteVisit(visit).subscribe(response => {
          if (i == this.patientVisits.length - 1) {
            this.spinner.hide();
            this.router.navigate(['/dashboard'])
          }
        }, error => {
          this.spinner.hide();
          console.log(error);
        })
      }
    }, error => {
      this.spinner.hide();
      console.log(error);
    })
  }

  saveVisit() {
    this.spinner.show();
    let selectedDate = this.v.visitDate.value.day + "-" + this.v.visitDate.value.month + "-" + this.v.visitDate.value.year
    let visitdata = {
      "patientId": this.patientDetails.patientId,
      "co": this.v.co.value,
      "vitals": this.v.vitals.value,
      "rx": this.v.rx.value,
      "date": selectedDate
    }

    this.patientService.addVisit(visitdata).subscribe(response => {
      this.spinner.hide();
      this.router.navigate(['/dashboard'])
    }, error => {
      this.spinner.hide();
      console.log(error);
    })



  }

}
