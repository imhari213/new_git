import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common'
import { SharedDataService } from '../services/shared.data.service'
import { PatientService } from '../services/patients.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-patient',
  templateUrl: './edit-patient.component.html',
  styleUrls: ['./edit-patient.component.css']
})
export class EditPatientComponent implements OnInit {

  editPatientForm: FormGroup;
  patientDetails: any;
  patientVisits: any;

  constructor(private formBuilder: FormBuilder,
    private _location: Location,
    private sharedData: SharedDataService,
    private router: Router,
    private patientService: PatientService) {

    this.editPatientForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      gender: ['', Validators.required],
      age: ['', Validators.required],
      occupation: ['', Validators.required],
      address: ['', Validators.required],
      contact: ['', Validators.required],
      kco: ['', Validators.required],
      payment: ['', Validators.required],
      pastHistory: ['', Validators.required],
      appetite: ['', Validators.required],
      thirst: ['', Validators.required],
      desires: ['', Validators.required],
      aversion: ['', Validators.required],
      micturation: ['', Validators.required],
      bowels: ['', Validators.required],
      sleep: ['', Validators.required],
      thermals: ['', Validators.required],
      menses: ['', Validators.required],
      mentalGenerals: ['', Validators.required],
      familyHistory: ['', Validators.required],
      reports: ['', Validators.required],
      diagnosis: ['', Validators.required],
      co: ['', Validators.required],
      vitals: ['', Validators.required],
      rx: ['', Validators.required]
    })
    
  }

  ngOnInit(): void {
  

    this.sharedData.getPatients().subscribe(res => {
      let patientDetails = {
        "patientId": res.patientId
      }
      this.patientService.getPatientDetails(patientDetails).subscribe(patient => {
      
        this.patientDetails = patient.result;
        this.patientVisits = patient.result.visits;

        this.editPatientForm.patchValue({
          firstName: this.patientDetails.firstName,
          lastName: this.patientDetails.lastName,
          gender: this.patientDetails.gender,
          age: this.patientDetails.age,
          occupation: this.patientDetails.occupation,
          address: this.patientDetails.address,
          contact: this.patientDetails.contact,
          kco: this.patientDetails.kco,
          payment: this.patientDetails.payment,
          pastHistory: this.patientDetails.pastHistory,
          appetite: this.patientDetails.appetite,
          thirst: this.patientDetails.thirst,
          desires: this.patientDetails.desires,
          aversion: this.patientDetails.aversion,
          micturation: this.patientDetails.micturation,
          bowels: this.patientDetails.bowels,
          sleep: this.patientDetails.sleep,
          thermals: this.patientDetails.thermals,
          menses: this.patientDetails.menses,
          mentalGenerals: this.patientDetails.mentalGenerals,
          familyHistory: this.patientDetails.familyHistory,
          reports: this.patientDetails.reports,
          diagnosis: this.patientDetails.diagnosis
        })

        console.log(this.patientVisits);
      })
    })
  }

  get f() { return this.editPatientForm.controls; }

  goBack() {
    this._location.back();
  }

  updatePatient(){

    let patientData = {
      "firstName": this.f.firstName.value,
      "lastName": this.f.lastName.value,
      "gender": this.f.gender.value,
      "age": this.f.age.value,
      "occupation": this.f.occupation.value,
      "address": this.f.address.value,
      "contact": this.f.contact.value,
      "kco": this.f.kco.value,
      "payment": this.f.payment.value,
      "pastHistory": this.f.pastHistory.value,
      "appetite": this.f.appetite.value,
      "thirst": this.f.thirst.value,
      "desires": this.f.desires.value,
      "aversion": this.f.aversion.value,
      "micturation": this.f.micturation.value,
      "bowels": this.f.bowels.value,
      "sleep": this.f.sleep.value,
      "thermals": this.f.thermals.value,
      "menses": this.f.menses.value,
      "mentalGenerals": this.f.mentalGenerals.value,
      "familyHistory": this.f.familyHistory.value,
      "reports": this.f.reports.value,
      "diagnosis": this.f.diagnosis.value,
      "co": this.f.co.value,
      "vitals": this.f.vitals.value,
      "rx": this.f.rx.value
    }

    console.log(patientData);

    this.patientService.createPatient(patientData).subscribe(response => {
      console.log(response);
      this.router.navigate(['/dashboard'])
    }, error => {
      console.log(error);
    })

  }
}
