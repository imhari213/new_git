var mongoose = require('mongoose');
const PASSWORD = 'H@ri3296!'; 
console.log(PASSWORD);
const url = "mongodb://hhcHarika:Hari3296!#@35.239.86.112:27017/weShare";

var _db;

module.exports = {

   connect : async function() {
    _db = await mongoose.connect(url, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    }, (err, client) => {
      (err) ?
      console.log("error whiel connecting to DB",err): console.log("connection successfull");
      return client;
    });
  },

  getDb : function() {
    return _db;
  }
};