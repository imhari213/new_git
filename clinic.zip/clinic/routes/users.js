const { response } = require('express');
var express = require('express');
const Patient = require('../models/patients.model');
var router = express.Router();
var autoIncrement = require('mongoose-auto-increment');
var PatientModel = require('../models/patients.model')
var patientVisitModel = require('../models/patientVisit.model')
var counterModel = require('../models/counters.model')


/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

router.get('/getAllPatients', function (req, res, next) {
  PatientModel.find({}, (err, response) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      res.send({ "status": 1, "result": response });
    }
  })
});



router.post('/findPatients', (req, res) => {
  console.log(req.body.keyWord)
  PatientModel.find({ 'patientId': { '$regex': req.body.keyWord, '$options': 'i' } }, (err, response) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      res.send({ "status": 1, "result": response });
    }
  })

})

router.post('/getPatient', (req, res, next) => {

  PatientModel.findOne({ patientId: req.body.patientId })
    .populate('visits')
    .exec((err, result) => {
      if (err) {
        res.send({ "status": 0, "err": err });
      } else {
        res.send({ "status": 1, "result": result });
      }
    });

});

router.get('/patientsCount', function (req, res, next) {
  PatientModel.countDocuments((err, patientsCount) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      patientVisitModel.countDocuments((err, visitCount) => {
        if (err) {
          res.send({ "status": 0, "err": err });
        } else {
          res.send({ "status": 1, "patientsCount": patientsCount, "visitCount": visitCount });
        }
      })
    }
  })
});

router.post('/findAllVisits', (req, res, next) => {

  patientVisitModel.find({ date: req.body.date }, (err, result) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      res.send({ "status": 1, "result": result });
    }
  });

});


router.post('/deleteVisit', (req, res, next) => {

  patientVisitModel.findByIdAndDelete({ _id: req.body.id }, (err, result) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      res.send({ "status": 1, "result": result });
    }
  });

});



router.post('/deletePatient', (req, res, next) => {

  PatientModel.findOneAndRemove({ patientId: req.body.patientId }, (err, result) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      res.send({ "status": 1, "result": result });
    }
  });

});


router.post('/updatePatient', (req, res) => {

  PatientModel.findOneAndUpdate(
    { patientId: req.body.patientId },
    {
      "$set":
      {
        "firstName": req.body.firstName,
        "lastName": req.body.lastName,
        "contact": req.body.contact,
        "gender": req.body.gender,
        "age": req.body.age,
        "date": req.body.date,
        "occupation": req.body.occupation,
        "address": req.body.address,
        "kco": req.body.kco,
        "payment": req.body.payment,
        "pastHistory": req.body.pastHistory,
        "appetite": req.body.appetite,
        "thirst": req.body.thirst,
        "desires": req.body.desires,
        "aversion": req.body.aversion,
        "micturation": req.body.micturation,
        "bowels": req.body.bowels,
        "sleep": req.body.sleep,
        "thermals": req.body.thermals,
        "menses": req.body.menses,
        "mentalGenerals": req.body.mentalGenerals,
        "familyHistory": req.body.familyHistory,
        "reports": req.body.reports,
        "diagnosis": req.body.diagnosis,
      }
    }, (err, result) => {

      if (err) {
        res.send({ "status": 0, "err": err });
      } else {
        res.send({ "status": 1, "result": result });
      }

    })

});


router.post('/addVisit', (req, res) => {

  var patientVisit = new patientVisitModel({
    co: req.body.co,
    vitals: req.body.vitals,
    rx: req.body.rx,
    date: req.body.date

  })

  patientVisit.save((err, result) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {

      PatientModel.findOneAndUpdate(
        { patientId: req.body.patientId },
        {
          "$push":
          {
            "visits": result._id
          }
        }
        , (err, response) => {
          if (err) {
            res.send({ "status": 0, "err": err });
          } else {
            res.send({ "status": 1, "result": response });
          }

        })
    }
  })
})



router.post('/createPatient', async (req, res) => {

  var opId;

  getNextSequenceValue("productid", (counter, err) => {

    opId = "HHC" + counter;

    var patientVisit = new patientVisitModel({
      co: req.body.co,
      vitals: req.body.vitals,
      rx: req.body.rx,
      date: req.body.date

    })

    patientVisit.save((err, result) => {
      if (err) {
        res.send({ "status": 0, "err": err });
      } else {
        var newPatient = new PatientModel({
          patientId: opId,
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          contact: req.body.contact,
          gender: req.body.gender,
          age: req.body.age,
          date: req.body.date,
          occupation: req.body.occupation,
          address: req.body.address,
          kco: req.body.kco,
          payment: req.body.payment,
          pastHistory: req.body.pastHistory,
          appetite: req.body.appetite,
          thirst: req.body.thirst,
          desires: req.body.desires,
          aversion: req.body.aversion,
          micturation: req.body.micturation,
          bowels: req.body.bowels,
          sleep: req.body.sleep,
          thermals: req.body.thermals,
          menses: req.body.menses,
          mentalGenerals: req.body.mentalGenerals,
          familyHistory: req.body.familyHistory,
          reports: req.body.reports,
          diagnosis: req.body.diagnosis,
          visits: result._id
        })
        newPatient.save((err, response) => {
          if (err) {
            res.send({ "status": 0, "err": err });
          } else {
            res.send({ "status": 1, "result": response });
          }
        })
      }

    })

  })
})


function getNextSequenceValue(sequenceName, callback) {

  counterModel.findByIdAndUpdate(
    { _id: sequenceName },
    { $inc: { sequence_value: 1 } },
    function (error, counter) {
      if (error) {
        console.log(err);
      } else {
        callback(counter.sequence_value);
      }
    }
  )



}

module.exports = router;
