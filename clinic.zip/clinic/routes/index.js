var express = require('express');
var router = express.Router();
var userModel = require('../models/user.model')

/* GET home page. */
router.get('/', function(req, res, next) {
  res.send("test")
});

router.post('/login', function(req, res, next) {

 console.log(req.body.userName, req.body.password)
 //res.send("test")
  userModel.findOne({"userName":req.body.userName}, (err, response) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      var result = response;
      if(req.body.password == result.password){
       res.send({ "status": 1, "result": response });
      }else {
       res.send({ "status": 0, "result": "invalid password" });
     }
     
    }
  })

});



router.post('/createUser', function(req, res, next) {
  var newUser = new userModel({
    userName : req.body.userName,
    email : req.body.email,
    password : req.body.password
  })

  newUser.save((err, response) => {
    if (err) {
      res.send({ "status": 0, "err": err });
    } else {
      res.send({ "status": 1, "result": response });
    }
  })

});

module.exports = router;
