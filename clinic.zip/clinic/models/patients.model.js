var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var patientSchema = new Schema({
    patientId:{
       type: String
    },
    firstName: {
        type: String
    },
    lastName: {
        type: String
    },
    contact: {
        type: Number
    },
    gender: {
        type: String
    },
    age: {
        type: String
    },
    date: {
        type: String
    },
    occupation: {
        type: String
    },
    address:{
        type: String
    },
    kco: {
        type: String
    },
    pastHistory: {
        type: String
    },
    appetite: {
        type: String
    },
    thirst: {
        type: String
    },
    desires: {
        type: String
    },
    aversion: {
        type: String
    },
    micturation: {
        type: String
    },
    bowels: {
        type: String
    },
    sleep: {
        type: String
    },
    payment: {
        type: String
    },
    thermals: {
        type: String
    },
    menses: {
        type: String
    },
    mentalGenerals: {
        type: String
    },
    familyHistory: {
        type: String
    },
    reports: {
        type: String
    },
    diagnosis: {
        type: String
    },
    visits: [{type: mongoose.Schema.Types.ObjectId, ref: "patientVisit"}],
    
});

var Patient = mongoose.model('Patients', patientSchema);


module.exports  = Patient;