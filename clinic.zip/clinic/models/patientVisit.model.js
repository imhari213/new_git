var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var patientVisitSchema = new Schema({

    co: {
        type: String
    },
    vitals: {
        type: String
    },
    rx: {
        type: String
    },
    date: {
        type: String
    },
    date: {
        type: String
    }
}, { timestamps: { createdAt: 'created_at' } });
var Visit = mongoose.model('patientVisit', patientVisitSchema);

module.exports = Visit;