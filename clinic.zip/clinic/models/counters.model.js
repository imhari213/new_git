var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var counterSchema = new Schema({
    _id:{
       type: String
    },
    sequence_value: {
        type: Number,default : 0
    },
   
});

var Counter = mongoose.model('counters', counterSchema);


module.exports  = Counter;